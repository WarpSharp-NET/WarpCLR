using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpCompiledSourceSchedulerTests
{
    [TestMethod]
    public async Task ActualOrdinaryChildCallHistoryJoinsOriginalCilOnlyWithFullSourceCheckpointAndCompilerSeal()
    {
        var captured = CaptureSource(nameof(Kernels.Recursive));
        var plan = new WarpCompiledSourcePlan(captured.Graph, captured.Schema, captured.Program, 1, 1, 16, 100000, 4096, Services.Value);
        WarpCompiledSourceContext context = Bind(plan, [[4]]);
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(plan.Layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        CoreCLRResumableKernel reference = CoreCLRResumableKernel.Compile(plan.Layout);
        WarpCompiledSourceContext.SourceCompletionReceipt? firstCalls = null;
        WarpCompiledWorkerTicket? firstTicket = null;
        WarpCompiledSourceContext.SourceCheckpoint? firstCheckpoint = null;
        int originalCalls = 0, wrapperCalls = 0;
        for (int attempt = 0; context.State != WarpPortableSchedulerLayout.CompletedContext && attempt < 10000; attempt++)
        {
            WarpCompiledWorkerTicket ticket = context.Claim(0)!;
            Assert.IsNotNull(ticket);
            WarpCompiledPausedCensus census = context.PrepareRemoteSource(ticket, null);
            context.BeginRemoteSource(census, ticket);
            uint[] state = context.RemoteSourceState(ticket);
            uint[] expected = (uint[])state.Clone(), expectedArena = (uint[])context.Arena.Clone();
            // Ordinary unheld kind16 only. No private Source purpose, grant,
            // controller RPC, nonce or entry-origin issuer is introduced.
            await lease.ExecuteObservedManagedQuantumAsync(context.RemoteSourceInputs, [], 0, state,
                plan.MaximumDepth, plan.Quantum, context.Arena).ConfigureAwait(false);
            reference.ExecuteManagedQuantum(context.RemoteSourceInputs, [], 0, expected, plan.MaximumDepth, plan.Quantum, expectedArena);
            CollectionAssert.AreEqual(expected, state); CollectionAssert.AreEqual(expectedArena, context.Arena);
            context.FinishRemoteSource(census, ticket, lease);
            WarpCompiledSourceContext.SourceCheckpoint checkpoint = context.RequireCommittedSourceCheckpoint(ticket, lease);
            WarpCompiledSourceContext.SourceCompletionReceipt receipt = checkpoint.Completion!;
            Assert.IsNotNull(receipt); Assert.IsTrue(receipt.HasObservedCallHistory);
            var calls = receipt.CopyHistoricalCallUses();
            foreach (WarpCompiledObservedCall call in calls)
            {
                receipt.ValidateHistoricalCallUse(context, ticket, lease, checkpoint, call);
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalCallUse(context, ticket, lease, checkpoint, call with { }));
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalCallUse(null!, ticket, lease, checkpoint, null!));
                Assert.AreSame(plan.Layout.Nodes[call.Transport.ProgramCounter], call.Node);
                Assert.AreEqual(call.Node.Function, call.Transport.Function);
                Assert.AreEqual(call.Node.Call!.Callee + 1, call.Transport.Callee);
                Assert.AreEqual(call.Node.Continuation, call.Transport.Continuation);
                if (call.Kind == WarpCompiledObservedCallKind.OriginalCilCall)
                {
                    originalCalls++;
                    Assert.IsNotNull(call.CapturedCall); Assert.IsNotNull(call.SourceBlock); Assert.IsNotNull(call.Body); Assert.IsNotNull(call.CalleeBody);
                    Assert.AreEqual(call.CapturedCall.Method, call.CalleeBody.MethodIdentity, StringComparer.Ordinal);
                    Assert.AreEqual(call.CapturedCall.Offset, call.SourceBlock.Instruction.Offset);
                    WarpPortableMethodGraphMethod method = captured.Graph.Methods.Single(candidate => candidate.Identity == call.Body.MethodIdentity);
                    Assert.AreSame(method.Instructions.Single(instruction => instruction.Offset == call.CapturedCall.Offset), call.CapturedCall);
                    Assert.IsTrue(call.SourceBlock.GeneratedBlocks.Contains(call.Node.Block));
                    Assert.IsNull(call.InvocationPrelude);
                    firstCalls ??= receipt; firstTicket ??= ticket; firstCheckpoint ??= checkpoint;
                }
                else if (call.Kind == WarpCompiledObservedCallKind.EntryWrapperCall)
                {
                    wrapperCalls++; Assert.IsNull(call.CapturedCall); Assert.IsNull(call.SourceBlock); Assert.IsNull(call.CallEffectIndex);
                }
            }
            Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistorical(context,
                new(context, ticket.Worker, ticket.Physical, ticket.Generation, ticket.Dispatch), lease, checkpoint));
            context.Commit(ticket);
            Assert.ThrowsExactly<InvalidOperationException>(() => checkpoint.Validate(context, ticket, lease));
            receipt.ValidateHistorical(context, ticket, lease, checkpoint);
        }
        Assert.AreEqual(WarpPortableSchedulerLayout.CompletedContext, context.State);
        Assert.AreEqual(10u, context.Result(0, context.Dispatch)[0]);
        Assert.IsGreaterThan(0, originalCalls); Assert.IsGreaterThan(0, wrapperCalls);
        Assert.IsNotNull(firstCalls); Assert.IsNotNull(firstTicket); Assert.IsNotNull(firstCheckpoint);
        firstCalls.ValidateHistorical(context, firstTicket, lease, firstCheckpoint);
        var firstRows = firstCalls.CopyHistoricalCallUses();
        Assert.IsGreaterThan(0, firstRows.Length);
        firstCalls.ValidateHistoricalCallUse(context, firstTicket, lease, firstCheckpoint, firstRows[0]);
        Assert.ThrowsExactly<WarpVerificationException>(() => new WarpCompiledSourcePlan(captured.Graph, captured.Schema,
            captured.Program with { }, 1, 1, 16, 100000, 4096, Services.Value));
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void ObservedCompletionRequiresContextSecretBeforeCandidateHistoryOrBanks(bool corruptDescriptor)
    {
        WarpCompiledSourceContext context = Create(nameof(Kernels.Recursive), 1, 1, [[4]]);
        uint offset = WarpPortableSchedulerLayout.HeapDescriptor, original = context.Arena[offset];
        if (corruptDescriptor) { context.Arena[offset] = uint.MaxValue; }
        try
        {
            Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCompiledSourceContext.SourceCompletionReceipt(
                context, null!, null!, null!, null!, new object()));
        }
        finally { context.Arena[offset] = original; }
        // A static source map or returned PC supplies no completed child command.
        WarpCompiledWorkerTicket ticket = context.Claim(0)!;
        Assert.ThrowsExactly<InvalidOperationException>(() => context.RequireCommittedSourceCheckpoint(ticket, null!));
    }

    [TestMethod]
    public async Task ActualOrdinarySourceMathHistoryLabelsGeneratedServicesWithoutInventingCapturedCilCalls()
    {
        var captured = CaptureSource(nameof(Kernels.Single));
        var plan = new WarpCompiledSourcePlan(captured.Graph, captured.Schema, captured.Program, 1, 1, 16, 100000, 4096, Services.Value);
        WarpCompiledSourceContext context = Bind(plan, [[BitConverter.SingleToUInt32Bits(1.5f)], [BitConverter.SingleToUInt32Bits(2.25f)]]);
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(plan.Layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        int services = 0;
        for (int attempt = 0; context.State != WarpPortableSchedulerLayout.CompletedContext && attempt < 10000; attempt++)
        {
            WarpCompiledWorkerTicket ticket = context.Claim(0)!;
            Assert.IsNotNull(ticket);
            WarpCompiledPausedCensus census = context.PrepareRemoteSource(ticket, null);
            context.BeginRemoteSource(census, ticket);
            await lease.ExecuteObservedManagedQuantumAsync(context.RemoteSourceInputs, [], 0, context.RemoteSourceState(ticket),
                plan.MaximumDepth, plan.Quantum, context.Arena).ConfigureAwait(false);
            context.FinishRemoteSource(census, ticket, lease);
            var calls = context.RequireCommittedSourceCheckpoint(ticket, lease).Completion!.CopyHistoricalCallUses();
            foreach (WarpCompiledObservedCall call in calls)
            {
                Assert.IsNull(call.CapturedCall); Assert.IsNull(call.CallEffectIndex);
                Assert.AreNotEqual(WarpCompiledObservedCallKind.OriginalCilCall, call.Kind);
                if (call.Kind == WarpCompiledObservedCallKind.SourceServiceCall)
                {
                    services++; Assert.IsNotNull(call.SourceBlock); Assert.IsNull(call.CalleeBody);
                    Assert.IsTrue(plan.Layout.IsRuntimeHelper(call.Transport.Callee));
                }
            }
            context.Commit(ticket);
        }
        Assert.AreEqual(WarpPortableSchedulerLayout.CompletedContext, context.State);
        Assert.AreEqual(BitConverter.SingleToUInt32Bits(Kernels.Single(1.5f, 2.25f)), context.Result(0, context.Dispatch)[0]);
        Assert.IsGreaterThan(0, services);
        Assert.IsFalse(plan.HasLocalSourceKernel);
    }
}
