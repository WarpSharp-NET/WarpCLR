using System.Security.Cryptography;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;
using WarpCLR.Verifier;

namespace WarpCLR.Tests;

internal sealed partial class WarpCoreCLRWorkerTests
{
    [TestMethod]
    [DataRow(false, 0u)]
    [DataRow(true, 0u)]
    [DataRow(true, 0x13579BDFu)]
    public async Task ActualObservedWordHistoryPreservesEveryBankRawCarrierAndRegisteredKinds(bool hasScalar, uint carrier)
    {
        WarpControlFlowKernel original = RichKernel();
        var kernel = new WarpControlFlowKernel("observed-child-raw-carrier", 1, hasScalar ? 1 : 0,
            original.Blocks, original.Reduction, original.Functions, original.Execution);
        var layout = new WarpLogicalMachineLayout(kernel);
        CoreCLRResumableKernel reference = CoreCLRResumableKernel.Compile(layout);
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        Assert.AreNotEqual(Environment.ProcessId, lease.ProcessId);
        Assert.IsTrue(lease.IsCollectible);
        uint[][] inputs = [[17]]; uint[] scalars = hasScalar ? [carrier] : [];
        int totalCalls = 0;
        foreach (int quantum in new[] { layout.MaximumBlockCost, Math.Max(4096, layout.MaximumBlockCost) })
        {
            uint[] state = layout.CreateInitialState(8, 100);
            uint[] arena = [0x01020304, 0xABCDEF12, 0xDEADBEEF];
            uint[] expected = (uint[])state.Clone(), expectedArena = (uint[])arena.Clone();
            for (int attempt = 0; state[0] == WarpLogicalMachineLayout.Runnable && attempt < 10000; attempt++)
            {
                uint[] before = (uint[])state.Clone(), arenaBefore = (uint[])arena.Clone();
                await lease.ExecuteObservedManagedQuantumAsync(inputs, scalars, 0, state, 8, quantum, arena).ConfigureAwait(false);
                reference.ExecuteManagedQuantum(inputs, scalars, 0, expected, 8, quantum, expectedArena);
                CollectionAssert.AreEqual(expected, state); CollectionAssert.AreEqual(expectedArena, arena);
                WarpCoreCLRWorkerProcess.WordCheckpoint receipt = lease.RequireCommittedWordCheckpoint(state, arena);
                Assert.AreEqual(WarpCoreCLRWorkerCallObservations.ExecuteObserved, receipt.RequestKind);
                Assert.AreEqual(WarpCoreCLRWorkerCallObservations.Observed, receipt.ResponseKind);
                Assert.IsTrue(receipt.HasObservedCallHistory);
                receipt.ValidateHistoricalStorage(inputs, scalars, state, arena);
                WarpCoreCLRWorkerWords.Invocation request = receipt.CopyHistoricalRequest();
                CollectionAssert.AreEqual(scalars, request.Scalars);
                CollectionAssert.AreEqual(before, request.State); CollectionAssert.AreEqual(arenaBefore, request.Arena);
                CollectionAssert.AreEqual(inputs[0], request.Inputs[0]);
                var returned = receipt.CopyHistoricalResult();
                CollectionAssert.AreEqual(state, returned.State); CollectionAssert.AreEqual(arena, returned.Arena);
                byte[] payload = receipt.CopyHistoricalResponsePayload();
                Assert.AreEqual(Convert.ToHexString(SHA256.HashData(payload)), receipt.ResponseHash, StringComparer.Ordinal);
                byte[] serialized = WarpCoreCLRWorkerWords.Request(request.Inputs, request.Scalars, request.Worker,
                    request.State, request.Depth, request.Quantum, request.Arena);
                Assert.Throws<InvalidDataException>(() => WarpCoreCLRWorkerWords.ReadResponse(payload, serialized, state.Length, arena.Length));
                var parsed = WarpCoreCLRWorkerCallObservations.ReadResponse(payload, serialized, state.Length, arena.Length, lease.CompiledModule);
                CollectionAssert.AreEqual(state, parsed.State); CollectionAssert.AreEqual(arena, parsed.Arena);
                Assert.Throws<InvalidDataException>(() => WarpCoreCLRWorkerCallObservations.ReadResponse(payload, serialized,
                    state.Length, arena.Length, Guid.NewGuid()));
                byte[] changedRequest = (byte[])serialized.Clone(); changedRequest[^1] ^= 1;
                Assert.Throws<InvalidDataException>(() => WarpCoreCLRWorkerCallObservations.ReadResponse(payload, changedRequest,
                    state.Length, arena.Length, lease.CompiledModule));
                foreach (WarpCoreCLRWorkerCallObservations.CallUse call in receipt.CopyHistoricalCallUses())
                {
                    WarpLogicalMachineNode node = layout.Nodes[call.ProgramCounter];
                    Assert.AreEqual(node.Function, call.Function); Assert.AreEqual(node.Call!.Callee + 1, call.Callee);
                    Assert.AreEqual(node.Continuation, call.Continuation); Assert.AreNotEqual(0u, call.Activation);
                }
                totalCalls += parsed.Calls.Length;
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalStorage(inputs, (uint[])scalars.Clone(), state, arena));
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalStorage((uint[][])inputs.Clone(), scalars, state, arena));
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalStorage(inputs, scalars, (uint[])state.Clone(), arena));
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalStorage(inputs, scalars, state, (uint[])arena.Clone()));
                uint[] originalInput = inputs[0]; inputs[0] = (uint[])originalInput.Clone();
                Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateHistoricalStorage(inputs, scalars, state, arena));
                inputs[0] = originalInput;
                payload[^1] ^= 1; returned.State[^1] ^= 1;
                Assert.AreEqual(receipt.ResponseHash, Convert.ToHexString(SHA256.HashData(receipt.CopyHistoricalResponsePayload())), StringComparer.Ordinal);
                CollectionAssert.AreEqual(state, receipt.CopyHistoricalResult().State);
            }
            Assert.AreEqual(WarpLogicalMachineLayout.Completed, state[0]);
            Assert.AreEqual(17u, state[WarpLogicalMachineLayout.ResultOffset]);
            Assert.AreEqual(24u, state[WarpLogicalMachineLayout.ResultHighOffset]);
        }
        Assert.IsGreaterThan(0, totalCalls);
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task ActualObservedChildMathPreservesEveryQuantumWordAndDeclaredPrecision(bool binary64)
    {
        string name = binary64 ? nameof(ObservedMath.Double) : nameof(ObservedMath.Single);
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(typeof(ObservedMath).GetMethod(name)!);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableWordLoweredProgram program = WarpPortableWordLowerer.Lower(graph, typed);
        var layout = new WarpLogicalMachineLayout(program.Kernel);
        CoreCLRResumableKernel reference = CoreCLRResumableKernel.Compile(layout);
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        ulong left = BitConverter.DoubleToUInt64Bits(1.5), right = BitConverter.DoubleToUInt64Bits(2.25);
        uint[][] inputs = binary64 ? [[(uint)left], [(uint)(left >> 32)], [(uint)right], [(uint)(right >> 32)]] :
            [[BitConverter.SingleToUInt32Bits(1.5f)], [BitConverter.SingleToUInt32Bits(2.25f)]];
        int calls = 0;
        foreach (int quantum in new[] { layout.MaximumBlockCost, Math.Max(4096, layout.MaximumBlockCost) })
        {
            uint[] state = layout.CreateInitialState(16, 100000), arena = [0x12345678, 0x87654321];
            uint[] expected = (uint[])state.Clone(), expectedArena = (uint[])arena.Clone();
            for (int attempt = 0; state[0] == WarpLogicalMachineLayout.Runnable && attempt < 10000; attempt++)
            {
                await lease.ExecuteObservedManagedQuantumAsync(inputs, [], 0, state, 16, quantum, arena).ConfigureAwait(false);
                reference.ExecuteManagedQuantum(inputs, [], 0, expected, 16, quantum, expectedArena);
                CollectionAssert.AreEqual(expected, state); CollectionAssert.AreEqual(expectedArena, arena);
                calls += lease.RequireCommittedWordCheckpoint(state, arena).CopyHistoricalCallUses().Length;
            }
            Assert.AreEqual(WarpLogicalMachineLayout.Completed, state[0]);
            if (binary64)
            {
                ulong actual = state[layout.GetResultWordOffset(0, 16)] | ((ulong)state[layout.GetResultWordOffset(1, 16)] << 32);
                Assert.AreEqual(BitConverter.DoubleToUInt64Bits(ObservedMath.Double(1.5, 2.25)), actual);
            }
            else { Assert.AreEqual(BitConverter.SingleToUInt32Bits(ObservedMath.Single(1.5f, 2.25f)), state[layout.GetResultWordOffset(0, 16)]); }
        }
        Assert.IsGreaterThan(0, calls);
    }

    [TestMethod]
    [DataRow("constructed")]
    [DataRow("clone")]
    [DataRow("key-copy")]
    [DataRow("sequence")]
    [DataRow("kind5")]
    [DataRow("payload")]
    public async Task ObservedTransportHolderRejectsForgerySessionKindSequenceAndPayload(string alteration)
    {
        byte[] key = RandomNumberGenerator.GetBytes(32);
        byte[] payload = WarpCoreCLRWorkerCallObservations.Response([1, 2, 3], [7, 8], [9], Guid.NewGuid(), []);
        using var stream = new MemoryStream();
        await WarpCoreCLRWorkerProtocol.WriteAsync(stream, key, WarpCoreCLRWorkerCallObservations.Observed, 11, payload, CancellationToken.None).ConfigureAwait(false);
        stream.Position = 0;
        WarpCoreCLRWorkerProtocol.Frame frame = await WarpCoreCLRWorkerProtocol.ReadAsync(stream, key, 11, CancellationToken.None).ConfigureAwait(false);
        if (alteration == "constructed") { frame = new(frame.Kind, (byte[])frame.Payload.Clone()); }
        if (alteration == "clone") { frame = frame with { }; }
        if (alteration == "key-copy") { key = (byte[])key.Clone(); }
        if (alteration == "payload") { frame.Payload[^1] ^= 1; }
        byte[] exactKey = key; WarpCoreCLRWorkerProtocol.Frame exactFrame = frame;
        ushort kind = alteration == "kind5" ? WarpCoreCLRWorkerProtocol.Executed : WarpCoreCLRWorkerCallObservations.Observed;
        Assert.Throws<InvalidDataException>(() => WarpCoreCLRAuthenticatedResponse.Capture(exactFrame, exactKey, kind,
            alteration == "sequence" ? 12u : 11u, out _));
    }

    [TestMethod]
    public void ObservedWorstCaseCapacityIsAdmittedBeforeAnyWorkerOrBankAllocation()
    {
        int largest = checked((int)((WarpCoreCLRWorkerWords.MaximumBytes - 40L - 24 -
            WarpCoreCLRWorkerCallObservations.MaximumCalls * (long)WarpCoreCLRWorkerCallObservations.CallBytes) / 4));
        long reserved = WarpCoreCLRWorkerProcess.ObservedTransferBytes(WarpCoreCLRWorkerWords.MaximumBytes, largest, 0);
        Assert.IsLessThan(WarpCoreCLRTransferAdmission.MaximumBytes, reserved);
        Assert.IsGreaterThan(WarpCoreCLRWorkerWords.MaximumBytes * 8L + 4096, reserved);
        Assert.Throws<InvalidDataException>(() => WarpCoreCLRWorkerProcess.ObservedTransferBytes(64, largest + 1, 0));
        Assert.Throws<ArgumentOutOfRangeException>(() => WarpCoreCLRWorkerProcess.ObservedTransferBytes(64, -1, 0));
        Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCoreCLRWorkerProcess.WordCheckpoint(null!, null!, null!, null!, new object()));
    }

    [TestMethod]
    public async Task ObservedPublicationFailureCommitsNoBanksOrHistoryAndKeepsQuarantine()
    {
        var layout = new WarpLogicalMachineLayout(RichKernel());
        var hooks = new WarpCoreCLRWorkerTestHooks { BeforeResultPublication = () => throw new InvalidOperationException("observed-publication-denial") };
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None, hooks).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        uint[] state = layout.CreateInitialState(8, 100), arena = [91, 92];
        uint[] before = (uint[])state.Clone(), arenaBefore = (uint[])arena.Clone();
        WarpHostException failure = await Assert.ThrowsExactlyAsync<WarpHostException>(() => lease.ExecuteObservedManagedQuantumAsync(
            [[17]], [], 0, state, 8, 4096, arena)).ConfigureAwait(false);
        Assert.AreEqual("WRPCORECLR3002", failure.Code, StringComparer.Ordinal);
        CollectionAssert.AreEqual(before, state); CollectionAssert.AreEqual(arenaBefore, arena);
        Assert.ThrowsExactly<InvalidOperationException>(() => lease.RequireCommittedWordCheckpoint(state, arena));
        Assert.IsTrue(lease.IsFaulted);
    }

    [TestMethod]
    public async Task OldKind5CannotAcquireCallHistoryAndHistoricalKind17SurvivesReplacementAndChildDisposal()
    {
        var layout = new WarpLogicalMachineLayout(RichKernel());
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        uint[][] inputs = [[17]]; uint[] scalars = [], arena = [91, 92];
        uint[] state = layout.CreateInitialState(8, 100);
        await lease.ExecuteObservedManagedQuantumAsync(inputs, scalars, 0, state, 8, 4096, arena).ConfigureAwait(false);
        WarpCoreCLRWorkerProcess.WordCheckpoint historical = lease.RequireCommittedWordCheckpoint(state, arena);
        byte[] historicalPayload = historical.CopyHistoricalResponsePayload();
        var calls = historical.CopyHistoricalCallUses();
        Assert.IsGreaterThan(0, calls.Length);
        uint[] replacement = layout.CreateInitialState(8, 100); replacement.CopyTo(state, 0);
        await lease.ExecuteManagedQuantumAsync(inputs, scalars, 0, state, 8, 4096, arena, CancellationToken.None).ConfigureAwait(false);
        WarpCoreCLRWorkerProcess.WordCheckpoint ordinary = lease.RequireCommittedWordCheckpoint(state, arena);
        Assert.AreEqual(WarpCoreCLRWorkerProtocol.Execute, ordinary.RequestKind);
        Assert.AreEqual(WarpCoreCLRWorkerProtocol.Executed, ordinary.ResponseKind);
        Assert.IsFalse(ordinary.HasObservedCallHistory);
        Assert.ThrowsExactly<InvalidOperationException>(() => ordinary.CopyHistoricalCallUses());
        Assert.ThrowsExactly<InvalidOperationException>(() => lease.ValidateCommittedWordCheckpoint(historical, state, arena));
        historical.ValidateHistoricalStorage(inputs, scalars, state, arena);
        CollectionAssert.AreEqual(historicalPayload, historical.CopyHistoricalResponsePayload());
        await compiled.DisposeAsync().ConfigureAwait(false);
        Assert.ThrowsExactly<InvalidOperationException>(() => lease.ValidateCommittedWordCheckpoint(ordinary, state, arena));
        CollectionAssert.AreEqual(historicalPayload, historical.CopyHistoricalResponsePayload());
        CollectionAssert.AreEqual(calls.ToArray(), historical.CopyHistoricalCallUses().ToArray());
    }

    private static class ObservedMath
    {
        public static float Single(float left, float right) => left + right * right;
        public static double Double(double left, double right) => left + right * right;
    }
}
