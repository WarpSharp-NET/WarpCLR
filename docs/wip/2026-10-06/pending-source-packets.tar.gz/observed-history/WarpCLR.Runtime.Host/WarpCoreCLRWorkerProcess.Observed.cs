using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCoreCLRWorkerProcess
{
    internal const string ObservedWordSemantics =
        "warp.coreclr.host/ordinary-unheld-observed-command-full-kind17-authenticated-history-no-source-purpose/0.1";

    internal Task ExecuteObservedManagedQuantumAsync(WarpLogicalMachineLayout layout, uint[][] inputs, uint[] scalars, int worker,
        uint[] state, int depth, int quantum, uint[] arena, CancellationToken cancellationToken) =>
        ExecuteCoreAsync(layout, inputs, scalars, worker, state, depth, quantum, arena, null, null, null, false, cancellationToken, observed: true);

    internal static long ObservedTransferBytes(long requestBytes, int stateWords, int arenaWords)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(requestBytes);
        ArgumentOutOfRangeException.ThrowIfNegative(stateWords);
        ArgumentOutOfRangeException.ThrowIfNegative(arenaWords);
        WarpCoreCLRWorkerCallObservations.RequireResponseCapacity(stateWords, arenaWords);
        // Include every maximum inventory record even when this quantum records
        // none. The old eight-copy allowance still covers the complete word banks;
        // another eight-copy allowance covers trailer, records and parse workspace.
        return checked(requestBytes * 8 + 4096 +
            (24L + WarpCoreCLRWorkerCallObservations.MaximumCalls * (long)WarpCoreCLRWorkerCallObservations.CallBytes) * 8);
    }

    private static (uint[] State, uint[] Arena) ReadRegisteredWordResponse(WarpCoreCLRStoppedCommands.Command command,
        byte[] completePayload, byte[] request, int stateWords, int arenaWords)
    {
        if (command.ResponseKind == WarpCoreCLRWorkerProtocol.Executed)
        { return WarpCoreCLRWorkerWords.ReadResponse(completePayload, request, stateWords, arenaWords); }
        if (command.RequestKind != WarpCoreCLRWorkerCallObservations.ExecuteObserved ||
            command.ResponseKind != WarpCoreCLRWorkerCallObservations.Observed)
        { throw new InvalidDataException("No ordinary word parser exists for this registered command purpose."); }
        WarpCoreCLRWorkerCallObservations.Result result = WarpCoreCLRWorkerCallObservations.ReadResponse(
            completePayload, request, stateWords, arenaWords, command.Process.CompiledModule);
        return (result.State, result.Arena);
    }
}
