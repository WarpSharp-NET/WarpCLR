using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Runtime.Host;

// These joined immutable values describe historical ordinary execution. They
// are not an issuer, Source origin, controller grant or replay capability.
internal sealed record WarpCompiledObservedCall(WarpCoreCLRWorkerCallObservations.CallUse Transport,
    WarpCompiledObservedCallKind Kind, WarpLogicalMachineNode Node, WarpPortableWordBody? Body,
    WarpPortableWordSourceBlock? SourceBlock, WarpPortableMethodGraphInstruction? CapturedCall,
    WarpPortableWordBody? CalleeBody, WarpPortableWordInvocationPrelude? InvocationPrelude, int? CallEffectIndex);

internal enum WarpCompiledObservedCallKind
{
    OriginalCilCall,
    FilterCilCall,
    SourceServiceCall,
    FilterServiceCall,
    SourceUnjoinedGuestCall,
    FilterUnjoinedGuestCall,
    InvocationPreludeCall,
    EntryWrapperCall,
    RuntimeHelperCall,
    UnmappedGeneratedCall,
}
