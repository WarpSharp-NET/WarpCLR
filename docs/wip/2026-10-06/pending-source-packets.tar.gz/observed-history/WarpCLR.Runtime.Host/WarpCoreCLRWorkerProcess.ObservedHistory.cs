using System.Collections.Immutable;
using WarpCLR.Backend.CoreCLR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCoreCLRWorkerProcess
{
    internal sealed partial class WordCheckpoint
    {
        // This is an exact transport kind, never a Source purpose or permission.
        internal bool HasObservedCallHistory => command.RequestKind == WarpCoreCLRWorkerCallObservations.ExecuteObserved &&
            command.ResponseKind == WarpCoreCLRWorkerCallObservations.Observed;

        internal ImmutableArray<WarpCoreCLRWorkerCallObservations.CallUse> CopyHistoricalCallUses()
        {
            if (!HasObservedCallHistory)
            { throw new InvalidOperationException("An ordinary kind5 checkpoint has no executed call inventory."); }
            WarpCoreCLRWorkerCallObservations.Result parsed = WarpCoreCLRWorkerCallObservations.ReadResponse(
                RequireHistoricalResponse(), historicalRequest, command.State.Length, command.Arena.Length, Module);
            return ImmutableArray.CreateRange(parsed.Calls);
        }

        // Return the complete authenticated snapshot as data; no caller-created
        // Frame or peeled prefix can acquire its actual ReadAsync receipt.
        internal byte[] CopyHistoricalResponsePayload() => RequireHistoricalResponse();
    }
}
