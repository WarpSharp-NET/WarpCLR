using System.Collections.Immutable;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    internal sealed partial class SourceCompletionReceipt
    {
        private readonly Lock callHistoryGate = new();
        private ImmutableArray<WarpCompiledObservedCall> historicalCalls;

        internal bool HasObservedCallHistory => words.HasObservedCallHistory;

        internal ImmutableArray<WarpCompiledObservedCall> CopyHistoricalCallUses()
        {
            // This always requires the original complete SourceCheckpoint and
            // the exact Context/ticket/lease/history objects. Data from a static
            // source inventory, returned PC or caller-created event is insufficient.
            ValidateHistorical(context, ticket, source, checkpoint);
            lock (callHistoryGate)
            {
                if (historicalCalls.IsDefault) { historicalCalls = context.Plan.JoinHistoricalCallUses(words); }
                return historicalCalls;
            }
        }

        internal void ValidateHistoricalCallUse(WarpCompiledSourceContext exactContext, WarpCompiledWorkerTicket exactTicket,
            WarpCoreCLRWorkerLease exactSource, SourceCheckpoint exactCheckpoint, WarpCompiledObservedCall candidate)
        {
            // Validate the complete private receipt first, before candidate data.
            ValidateHistorical(exactContext, exactTicket, exactSource, exactCheckpoint);
            if (!CopyHistoricalCallUses().Any(actual => ReferenceEquals(actual, candidate)))
            { throw new InvalidOperationException("A historical call join must be the exact object retained by its authenticated completion."); }
        }
    }
}
