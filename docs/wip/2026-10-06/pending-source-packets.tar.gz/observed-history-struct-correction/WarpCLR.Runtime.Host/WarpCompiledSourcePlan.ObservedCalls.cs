using System.Collections.Immutable;
using System.Reflection.Emit;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourcePlan
{
    internal const string ObservedCallJoinSemantics =
        "warp.context-observed-call/exact-compiler-cwt-complete-historical-checkpoint-final-node-unique-captured-cil-target-services-distinct-no-source-origin/0.1";

    internal ImmutableArray<WarpCompiledObservedCall> JoinHistoricalCallUses(WarpCoreCLRWorkerProcess.WordCheckpoint words)
    {
        // Genuine object seal first, before reading candidate transport data.
        RequireCompletionCompilerSeal();
        if (!string.Equals(words.IrHash, CompilerIdentity.KernelIrHash, StringComparison.Ordinal))
        { throw new InvalidOperationException("Observed history belongs to another final compiler kernel."); }
        WarpCoreCLRWorkerWords.Invocation request = words.CopyHistoricalRequest();
        ImmutableArray<WarpCoreCLRWorkerCallObservations.CallUse> calls = words.CopyHistoricalCallUses();
        var result = ImmutableArray.CreateBuilder<WarpCompiledObservedCall>(calls.Length);
        var joinedSites = new Dictionary<int, WarpCompiledObservedCall>();
        foreach (WarpCoreCLRWorkerCallObservations.CallUse call in calls)
        {
            WarpLogicalMachineNode node = RequireObservedNode(call, request.Depth);
            if (!joinedSites.TryGetValue(call.ProgramCounter, out WarpCompiledObservedCall? joined))
            {
                joined = JoinObservedNode(call, node); joinedSites.Add(call.ProgramCounter, joined);
            }
            result.Add(joined with { Transport = call });
        }
        return result.MoveToImmutable();
    }

    private WarpLogicalMachineNode RequireObservedNode(WarpCoreCLRWorkerCallObservations.CallUse call, int depthLimit)
    {
        if ((uint)call.ProgramCounter >= (uint)Layout.Nodes.Count || call.Depth == 0 ||
            call.Depth > (uint)Layout.GetPhysicalFrameCapacity(depthLimit) ||
            call.Frame != checked(WarpLogicalMachineLayout.HeaderWords + ((int)call.Depth - 1) * Layout.FrameWords) ||
            Layout.HasFrameOwners && (call.Activation == 0 || call.Depth > 1 && call.ParentActivation == 0) ||
            call.Depth == 1 && call.ParentActivation != 0)
        { throw new InvalidOperationException("An authenticated call inventory has invalid final frame geometry or activation shape."); }
        WarpLogicalMachineNode node = Layout.Nodes[call.ProgramCounter];
        if (node.Call is not { } operation || node.Function != call.Function ||
            operation.Callee + 1 != call.Callee || node.Continuation != call.Continuation)
        { throw new InvalidOperationException("A historical call does not match the actual final IR call node and continuation."); }
        return node;
    }

    private WarpCompiledObservedCall JoinObservedNode(WarpCoreCLRWorkerCallObservations.CallUse call, WarpLogicalMachineNode node)
    {
        bodies.TryGetValue(node.Function, out WarpPortableWordBody? body);
        bodies.TryGetValue(call.Callee, out WarpPortableWordBody? callee);
        if (body is not null && sourceBlocks.TryGetValue((node.Function, node.Block), out WarpPortableWordSourceBlock? source))
        {
            WarpPortableMethodGraphInstruction? captured = UniqueCapturedCall(body, source, node, callee);
            bool filter = body.AliasOwnerFunction != -1 || source.Instruction.ExceptionMemberships.Any(membership =>
                membership.Role == WarpPortableExceptionRole.Filter);
            bool service = callee is null && Layout.IsRuntimeHelper(call.Callee);
            WarpCompiledObservedCallKind kind = captured is not null ?
                (filter ? WarpCompiledObservedCallKind.FilterCilCall : WarpCompiledObservedCallKind.OriginalCilCall) :
                service ? (filter ? WarpCompiledObservedCallKind.FilterServiceCall : WarpCompiledObservedCallKind.SourceServiceCall) :
                (filter ? WarpCompiledObservedCallKind.FilterUnjoinedGuestCall : WarpCompiledObservedCallKind.SourceUnjoinedGuestCall);
            int[] callEffects = source.Instruction.Effects.Select((effect, index) => (effect, index))
                .Where(pair => pair.effect == WarpPortableTypedEffect.Call).Select(pair => pair.index).ToArray();
            return new(call, kind, node, body, source, captured, callee, null,
                captured is not null && callEffects.Length == 1 ? callEffects[0] : null);
        }
        if (body?.InvocationPrelude is { } prelude && prelude.GeneratedBlocks.Contains(node.Block))
        {
            // Zero-charge invocation setup has no fabricated CIL instruction,
            // effect index or target-body EH membership.
            if (node.SourceCost != 0)
            { throw new InvalidOperationException("An invocation prelude call acquired an original source charge."); }
            return new(call, WarpCompiledObservedCallKind.InvocationPreludeCall, node, body, null, null, callee, prelude, null);
        }
        WarpCompiledObservedCallKind generated = node.Function == 0 && !bodies.ContainsKey(0) ? WarpCompiledObservedCallKind.EntryWrapperCall :
            Layout.IsRuntimeHelper(node.Function) ? WarpCompiledObservedCallKind.RuntimeHelperCall :
            WarpCompiledObservedCallKind.UnmappedGeneratedCall;
        return new(call, generated, node, body, null, null, callee, null, null);
    }

    private WarpPortableMethodGraphInstruction? UniqueCapturedCall(WarpPortableWordBody body,
        WarpPortableWordSourceBlock source, WarpLogicalMachineNode node, WarpPortableWordBody? callee)
    {
        if (callee is null || callee.AliasOwnerFunction != -1) { return null; }
        string original = body.AliasOwnerFunction == -1 ? body.MethodIdentity : bodies[body.AliasOwnerFunction].MethodIdentity;
        WarpPortableMethodGraphMethod method = completionGraph.Methods.Single(candidate =>
            string.Equals(candidate.Identity, original, StringComparison.Ordinal));
        WarpPortableMethodGraphInstruction captured = method.Instructions.Single(candidate => candidate.Offset == source.Instruction.Offset);
        if (captured.OpCode.Value != source.Instruction.OpCode ||
            captured.OpCode != OpCodes.Call && captured.OpCode != OpCodes.Callvirt && captured.OpCode != OpCodes.Newobj ||
            captured.Method is null || !string.Equals(captured.Method, callee.MethodIdentity, StringComparison.Ordinal))
        { return null; }
        // A generated service/prelude/dispatch call cannot become the captured
        // call merely because it shares a source block or a returned PC. Require
        // exactly one actual owned node to that exact captured closed target.
        IReadOnlyList<WarpBasicBlock> blocks = body.Function == 0 ? Program.Kernel.Blocks : Program.Kernel.Functions[body.Function - 1].Blocks;
        int matches = 0;
        WarpIrInstruction? exact = null;
        foreach (int generated in source.GeneratedBlocks)
        {
            foreach (WarpIrInstruction instruction in blocks[generated].Instructions)
            {
                if (instruction.OpCode == WarpIrOpCode.Call && instruction.Callee + 1 == callee.Function)
                { matches++; exact = instruction; }
            }
        }
        // Compiler CWT and retained layout/node ownership have already been checked.
        // Both instructions are struct copies of that owned IR operation, not reference capabilities.
        return matches == 1 && exact is { } operation && node.Call is { } owned && operation.Equals(owned) ? captured : null;
    }
}
