using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.Loader;
using System.Text.RegularExpressions;

namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed class OriginalSources(RootInputs inputs) : IDisposable
{
    private readonly AssemblyLoadContext fixtureContext = new("ExactRootNumericFixtures", isCollectible: true);
    private Assembly? fixtures;

    internal MethodInfo Resolve(CaseSpec spec)
    {
        if (spec.FixtureRole == "runtime-created-original-cil") { return StoredDoubleSource(); }
        Assembly assembly = spec.FixtureRole switch
        {
            "additive-linked-source" => typeof(WarpCLR.Tests.Production.CurrentCoverage.WarpCurrentNumericSourceCases).Assembly,
            "actual-compiler-source" => typeof(WarpCLR.Compiler.WarpPortableWordLowerer).Assembly,
            "actual-root-tests" => LoadFixtures(),
            _ => throw new InvalidDataException("Unknown original source role"),
        };
        Type type = assembly.GetType(spec.Type, throwOnError: true)!;
        MethodInfo method = type.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
            .Single(candidate => candidate.Name == spec.Method);
        ValidateSignature(spec, method);
        return method;
    }

    private Assembly LoadFixtures()
    {
        if (fixtures is not null) { return fixtures; }
        fixtureContext.Resolving += (_, name) => name.Name is { } key && inputs.Assemblies.TryGetValue(key, out FilePin? pin)
            ? AssemblyLoadContext.Default.LoadFromAssemblyPath(pin.Path) : null;
        fixtures = fixtureContext.LoadFromAssemblyPath(inputs.SourceFixtureTests.Path);
        ProofEvidence.Require(ProofEvidence.HashFile(fixtures.Location).Equals(inputs.SourceFixtureTests.Sha256, StringComparison.OrdinalIgnoreCase),
            "Actual Root fixture PE, distinct ALC; no historical fixture DLL");
        return fixtures;
    }

    private static MethodInfo StoredDoubleSource()
    {
        // Same genuine original CIL as the pinned existing nonadjacent test.
        // No C# optimizer assumption and no invocation/rewriting of that test.
        AssemblyBuilder assembly = AssemblyBuilder.DefineDynamicAssembly(new AssemblyName("NumericOriginalStoredDouble_" + Guid.NewGuid().ToString("N")), AssemblyBuilderAccess.RunAndCollect);
        TypeBuilder type = assembly.DefineDynamicModule("DoubleRound").DefineType("DoubleRound", TypeAttributes.Public | TypeAttributes.Abstract | TypeAttributes.Sealed);
        MethodBuilder method = type.DefineMethod("DoubleRound", MethodAttributes.Public | MethodAttributes.Static, typeof(float), [typeof(ulong)]);
        ILGenerator il = method.GetILGenerator();
        il.DeclareLocal(typeof(double)); il.Emit(OpCodes.Ldarg_0); il.Emit(OpCodes.Conv_R_Un); il.Emit(OpCodes.Stloc_0);
        il.Emit(OpCodes.Ldloc_0); il.Emit(OpCodes.Conv_R4); il.Emit(OpCodes.Ret);
        MethodInfo result = type.CreateType()!.GetMethod("DoubleRound")!;
        ProofEvidence.Require(result.GetMethodBody()!.GetILAsByteArray()!.AsSpan().SequenceEqual(new byte[] { 0x02, 0x76, 0x0A, 0x06, 0x6B, 0x2A }),
            "Actual stored-Double original CIL sequence");
        return result;
    }

    private static void ValidateSignature(CaseSpec spec, MethodInfo method)
    {
        ProofEvidence.Require(method.IsStatic && !method.ContainsGenericParameters && method.GetMethodBody()?.GetILAsByteArray() is { Length: > 0 }, "Concrete original source method");
        if (spec.Classification == "reference-root-consistency")
        {
            ProofEvidence.Require(method.GetParameters().Select(parameter => parameter.ParameterType).SequenceEqual(new[] { typeof(object), typeof(double), typeof(double) }) &&
                method.ReturnType == typeof(ValueTuple<object, double>), "Exact object/Double tuple signature"); return;
        }
        string text = spec.DeclaredSignature;
        int start = text.IndexOf('('); int end = text.IndexOf(')', start);
        string[] parameters = text[(start + 1)..end].Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
            .Select(part => part.Split(' ', StringSplitOptions.RemoveEmptyEntries)[0]).ToArray();
        string result = text[(text.IndexOf("->", StringComparison.Ordinal) + 2)..].Trim();
        ProofEvidence.Require(parameters.SequenceEqual(method.GetParameters().Select(parameter => Alias(parameter.ParameterType)), StringComparer.Ordinal) &&
            Regex.Replace(result, "\\s", string.Empty, RegexOptions.CultureInvariant) == Alias(method.ReturnType), "Original declared width/signature: " + spec.Id);
    }

    internal static string Alias(Type type) => type == typeof(uint) ? "uint" : type == typeof(int) ? "int" :
        type == typeof(ulong) ? "ulong" : type == typeof(long) ? "long" : type == typeof(float) ? "float" :
        type == typeof(double) ? "double" : type == typeof(sbyte) ? "sbyte" : type == typeof(short) ? "short" :
        type == typeof(bool) ? "bool" : throw new InvalidDataException("No declared-type alias: " + type);

    public void Dispose() => fixtureContext.Unload();
}
