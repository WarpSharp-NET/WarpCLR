# Root successor: retain actual raw original CLR results separately from the portable contract comparison.
"""Future pinned analyzer build argv; no build/tool subprocess is launched."""
import argparse
import pathlib
import sys
sys.path.insert(0, '/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/current-numeric-source-proof-packet')
from proof_tools import pin, read, receipt, require, write_new
HERE = pathlib.Path(__file__).resolve().parent
ORIGINAL = pathlib.Path('/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/current-numeric-source-proof-packet')


def main():
    parser = argparse.ArgumentParser()
    for name in ["root-inputs", "shared-package-cache", "artifacts", "output"]:
        parser.add_argument("--" + name, type=pathlib.Path, required=True)
    args = parser.parse_args()
    root = read(args.root_inputs)
    provenance = read(ORIGINAL / "provenance.json")
    require(root["format"] == "warp.proof.current-numeric/actual-root-inputs/0.1", "Explicit actual future Root inputs")
    for row in [root["actualSourceReceipt"], root["actualArtifactReceipt"], root["actualRuntimeReceipt"], root["actualSdkReceipt"],
                root["sourceFixtureTests"], root["dotnetHost"], *root["assemblies"].values()]:
        pin(row)
    for row in provenance["pinnedPolicies"]:
        pin(row)
    numeric = pin(provenance["linkedNumericCases"])
    oracle = pin(provenance["linkedIndependentMathOracle"])
    policies = pathlib.Path(provenance["pinnedPolicies"][0]["path"]).parent
    config = provenance["pinnedPolicies"][-1]["path"]
    require(args.shared_package_cache.is_absolute() and args.shared_package_cache.is_dir(), "Existing exact pinned cache; no package copy/default cache")
    artifacts = args.artifacts.resolve()
    require(not artifacts.exists(), "Fresh owned build outputs; failures preserved before reuse")
    mapping = {"WarpProofSdk": "WarpCLR.Sdk", "WarpProofIr": "WarpCLR.IR", "WarpProofCompiler": "WarpCLR.Compiler",
               "WarpProofVerifier": "WarpCLR.Verifier", "WarpProofCoreClr": "WarpCLR.Backend.CoreCLR", "WarpProofHost": "WarpCLR.Runtime.Host"}
    properties = ["-p:WarpProofPolicies=" + str(policies), "-p:WarpProofNumericCases=" + str(numeric), "-p:WarpProofMathOracle=" + str(oracle),
                  "-p:WarpProofConfig=" + config, "-p:WarpProofPackageCache=" + str(args.shared_package_cache),
                  "-p:UseArtifactsOutput=true", "-p:ArtifactsPath=" + str(artifacts), "-p:UseSharedCompilation=false"]
    properties += ["-p:" + key + "=" + root["assemblies"][name]["path"] for key, name in mapping.items()]
    project = str(HERE / "WarpCLR.Tests.csproj")
    dotnet = str(pin(root["dotnetHost"]))
    commands = []
    for role, argv in [
        ("forced-restore-1", [dotnet, "restore", project, "--force", "--no-cache"]),
        ("clean-release", [dotnet, "clean", project, "-c", "Release", "-m:1"]),
        ("forced-restore-2", [dotnet, "restore", project, "--force", "--no-cache"]),
        ("nonincremental-release", [dotnet, "build", project, "-c", "Release", "--no-restore", "--no-incremental", "-m:1"]),
    ]:
        commands.append({"role": role, "argv": argv + properties, "cwd": str(HERE),
                         "environment": {"DOTNET_ROOT": str(pathlib.Path(dotnet).parent)}, "externalBuildValidationSeconds": 2400,
                         "zeroUniversalDiagnosticsRequired": True, "execute": False, "retries": 0})
    write_new(args.output, {"format": "warp.proof.current-numeric/future-universal-build-plan/0.1", "commands": commands,
              "rootInputs": receipt(args.root_inputs), "packetSourcesOnly": True, "copies": 0,
              "actualProducedHarnessPeMvidCilReceiptRequired": True, "externalBuildQuotaChangesProductionQuotas": False})


if __name__ == "__main__":
    main()
