"""Future serial command arrays only. No subprocess/tool/version execution."""
import argparse
import pathlib
from proof_tools import DIALECTS, HERE, pin, read, receipt, require, validate_prepared, v4_module, write_new


def main():
    parser = argparse.ArgumentParser()
    for name in ["root-inputs", "prepared", "native-tools", "cpu-tools", "output-root", "plan"]:
        parser.add_argument("--" + name, type=pathlib.Path, required=True)
    args = parser.parse_args()
    prepared, root = validate_prepared(args.prepared, args.root_inputs)
    native_adapter = v4_module("native_command_plan")
    native_tools = read(args.native_tools)
    tools, environment = native_adapter.tools_checked(native_tools)
    cpu = read(args.cpu_tools)
    require(cpu["format"] == "warp.proof.current-numeric/actual-cpu-tools/0.1", "Explicit actual CPU tool schema")
    for artifact in [cpu["prerequisiteReceipt"], *cpu["tools"].values(), *cpu["libraries"]]:
        pin(artifact)
    require(set(cpu["tools"]) == {"llc", "cc", "python"}, "Exact CPU codegen/link/comparison tools")
    require(cpu["tools"]["llc"] == native_tools["tools"]["llc"], "Same LLVM19 codegen executable for native and CPU")
    require(cpu["architecture"] == "x86_64" and cpu["llvmMajor"] == 19, "Finite physical CPU ABI prerequisite")
    output = args.output_root.resolve()
    require(not output.exists(), "New future retained image output root, no overwritten failures")
    commands, images = [], []

    def add(group, role, argv, outputs, quota, remaining):
        ordinal = len(commands)
        stem = output / "logs" / (f"{ordinal:04d}-" + group + "-" + role)
        commands.append({"ordinal": ordinal, "group": group, "role": role, "argv": argv, "environment": environment,
                         "cwd": str(output), "outputs": outputs, "stdout": str(stem) + ".stdout.log", "stderr": str(stem) + ".stderr.log",
                         "receipt": str(stem) + ".receipt.json", "positiveProducerStop": str(stem) + ".stop.json",
                         "deadlineSeconds": quota, "usesRemainingGroupDeadline": remaining, "retries": 0, "executed": False})

    for case in prepared["cases"]:
        emitted = read(case["emission"]["path"])
        for dialect in DIALECTS:
            source = next(row for row in emitted["dialects"] if row["dialect"] == dialect)
            requirements = native_adapter.source_requirements(pin(source), dialect)
            group = case["name"] + "-" + dialect
            stem = output / case["name"] / dialect
            bitcode, object_file = str(stem) + ".bc", str(stem) + ".o"
            extension = {"NVPTX": ".ptx", "AMDGPU": ".hsaco", "SPIRV": ".spv"}[dialect]
            image = str(stem) + extension
            add(group, "assemble", [tools["llvmAs"], source["path"], "-o", bitcode], [bitcode], 120, True)
            if dialect == "NVPTX":
                add(group, "codegen", [tools["llc"], "-mtriple=nvptx64-nvidia-cuda", "-mcpu=sm_80", "-mattr=+ptx80", "-filetype=asm", "-O=2", bitcode, "-o", image], [image], 120, True)
            elif dialect == "AMDGPU":
                add(group, "codegen", [tools["llc"], "-mtriple=amdgcn-amd-amdhsa", "-mcpu=gfx942", "-filetype=obj", "-O=2", bitcode, "-o", object_file], [object_file], 120, True)
                add(group, "link", [tools["lld"], "-shared", "--no-undefined", object_file, "-o", image], [image], 120, True)
            else:
                add(group, "translate", [tools["llvmSpirv"], "--spirv-max-version=1.2", bitcode, "-o", image], [image], 120, True)
                add(group, "validate", [tools["spirvVal"], "--target-env", "opencl2.2", image], [], 120, True)
            images.append({"case": case["name"], "dialect": dialect, "kind": "ACTUAL_OFFLINE_TARGET_IMAGE", "group": group,
                           "path": image, "source": source, "program": case["program"], "plan": case["plan"], "requirements": requirements,
                           "commonIrHash": case["irHash"], "commandOrdinals": [x["ordinal"] for x in commands if x["group"] == group],
                           "gpuExecution": False, "retarget": False})
            cpu_group = group + "-cpu"
            cpu_dir = output / case["name"] / (dialect + "-cpu")
            py = cpu["tools"]["python"]["path"]
            add(cpu_group, "retarget", [py, str(HERE / "retarget_numeric.py"), "--root-inputs", str(args.root_inputs.resolve()),
                "--prepared", str(args.prepared.resolve()), "--case", case["name"], "--dialect", dialect, "--output", str(cpu_dir)],
                [str(cpu_dir / "cpu.ll"), str(cpu_dir / "retarget.json")], 60, True)
            add(cpu_group, "codegen", [cpu["tools"]["llc"]["path"], "-mtriple=x86_64-unknown-linux-gnu", "-filetype=obj", "-relocation-model=pic", "-O=2",
                str(cpu_dir / "cpu.ll"), "-o", str(cpu_dir / "cpu.o")], [str(cpu_dir / "cpu.o")], 60, True)
            add(cpu_group, "link", [cpu["tools"]["cc"]["path"], "-shared", "-Wl,--no-undefined", str(cpu_dir / "cpu.o"), "-o", str(cpu_dir / "cpu.so")],
                [str(cpu_dir / "cpu.so")], 60, True)
            images.append({"case": case["name"], "dialect": dialect, "kind": "OFFLINE_CPU_ABI_RETARGET_LIBRARY", "group": cpu_group,
                           "path": str(cpu_dir / "cpu.so"), "source": source, "program": case["program"], "plan": case["plan"],
                           "commonIrHash": case["irHash"], "commandOrdinals": [x["ordinal"] for x in commands if x["group"] == cpu_group],
                           "gpuExecution": False, "arithmeticRewrite": False})
    require(len(images) == 2 * len(DIALECTS) * len(prepared["cases"]) and len(commands) == 17 * len(prepared["cases"]), "One actual device image and one CPU library per exact case/dialect; finite serial command census")
    write_new(args.plan, {"format": "warp.proof.current-numeric/serial-compilation-plan/0.1", "rootInputs": receipt(args.root_inputs),
              "prepared": receipt(args.prepared), "nativeTools": receipt(args.native_tools), "cpuTools": receipt(args.cpu_tools),
              "outputRoot": str(output), "commands": commands, "images": images, "nativeImages": len(DIALECTS) * len(prepared["cases"]), "cpuLibraries": len(DIALECTS) * len(prepared["cases"]),
              "execute": False, "RootExecutesPersonally": True, "noDeadlineResetOrRetries": True,
              "ordinaryWorkerQuotas": {"jitSeconds": 120, "quantumSeconds": 30, "cleanupSeconds": 2},
              "comparisonToolSeconds": 60, "missingPrerequisitesAreBlockers": True, "sourceAuthority": False, "gpu": False})


if __name__ == "__main__":
    main()
