using System.Reflection;
using System.Runtime.InteropServices;

namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed record FilePin(string Path, string Sha256)
{
    internal void Validate()
    {
        ProofEvidence.Require(System.IO.Path.IsPathFullyQualified(Path) && Sha256.Length == 64, "Explicit absolute file/hash pin");
        ProofEvidence.Require(string.Equals(ProofEvidence.HashFile(Path), Sha256, StringComparison.OrdinalIgnoreCase), "Input bytes: " + Path);
    }
}

internal sealed record RootInputs(string Format, string ProductionGateLabel, FilePin ActualSourceReceipt,
    FilePin ActualArtifactReceipt, FilePin ActualRuntimeReceipt, FilePin ActualSdkReceipt, FilePin ProposedSourcePlanV2,
    FilePin CoverageManifest, FilePin SourceFixtureTests, FilePin DotnetHost, FilePin WorkerAssembly,
    Dictionary<string, FilePin> Assemblies, Dictionary<string, FilePin> FixtureSources,
    Dictionary<string, FilePin> WorkerDeploymentFiles, string OrdinaryMetadataVersion, string PhysicalMachineVersion,
    uint OrdinaryCodecMagic, int MaximumLogicalDepth, long MaximumSourceSteps, int MaximumQuantaPerTrace,
    long ReservedBankBytes, long ImageAndLogReserveBytes, long MinimumFreeBytesAfterReservation)
{
    internal void Validate()
    {
        ProofEvidence.Require(Format == "warp.proof.current-numeric/actual-root-inputs/0.1" && !string.IsNullOrWhiteSpace(ProductionGateLabel), "Actual gate label and input schema");
        foreach (FilePin pin in new[] { ActualSourceReceipt, ActualArtifactReceipt, ActualRuntimeReceipt, ActualSdkReceipt,
            ProposedSourcePlanV2, CoverageManifest, SourceFixtureTests, DotnetHost, WorkerAssembly }) { pin.Validate(); }
        ProofEvidence.Require(ProposedSourcePlanV2.Sha256 == "cb07cf7a85cc3ca7583851ea86b849964cf3411829ef5b0c3cf75418ceea623a" &&
            CoverageManifest.Sha256 == "66f7f60b04fe9317a5fc37d106d2f32febb5d68f87241b2ffc95e10ce65a1aab", "Exact source-only planning pins; no readiness authority");
        string[] required = ["WarpCLR.Sdk", "WarpCLR.IR", "WarpCLR.Compiler", "WarpCLR.Verifier", "WarpCLR.Backend.CoreCLR", "WarpCLR.Runtime.Host"];
        ProofEvidence.Require(Assemblies.Keys.Order(StringComparer.Ordinal).SequenceEqual(required.Order(StringComparer.Ordinal)), "Exact six production assemblies");
        foreach ((string name, FilePin pin) in Assemblies)
        {
            pin.Validate();
            ProofEvidence.Require(System.IO.Path.GetFileNameWithoutExtension(pin.Path) == name, "Production assembly filename");
        }
        foreach (FilePin pin in FixtureSources.Values.Concat(WorkerDeploymentFiles.Values)) { pin.Validate(); }
        ProofEvidence.Require(WorkerDeploymentFiles.Count >= 5 && System.IO.Path.GetFileName(WorkerAssembly.Path) == "WarpCLR.CoreCLR.Worker.dll", "Explicit actual worker deployment census");
        ProofEvidence.Require(OrdinaryCodecMagic == 0x57425036 && PhysicalMachineVersion == "warp.logical-machine/0.8" &&
            OrdinaryMetadataVersion == "warp.logical-source-frames/0.6", "Ordinary conditional profile only; no private WBP8 fallback");
        ProofEvidence.Require(MaximumLogicalDepth == 32 && MaximumSourceSteps == 1024 && MaximumQuantaPerTrace > 0 &&
            ReservedBankBytes > 0 && ImageAndLogReserveBytes > 0 && MinimumFreeBytesAfterReservation >= 50L * 1024 * 1024 * 1024, "Explicit finite depth/source/operational/storage admission");
        ProofEvidence.Require(Environment.Version.ToString() == "10.0.12" && RuntimeInformation.ProcessArchitecture == Architecture.X64,
            "Pinned original-CLR oracle runtime/architecture; discrepancies block instead of altering expected bits");
    }

    internal void VerifyLoadedAssemblies()
    {
        foreach ((string name, FilePin expected) in Assemblies)
        {
            Assembly actual = AppDomain.CurrentDomain.GetAssemblies().Single(assembly => assembly.GetName().Name == name);
            ProofEvidence.Require(System.IO.Path.GetFullPath(actual.Location) == System.IO.Path.GetFullPath(expected.Path) &&
                ProofEvidence.HashFile(actual.Location).Equals(expected.Sha256, StringComparison.OrdinalIgnoreCase), "Loaded actual assembly identity");
        }
    }
}
