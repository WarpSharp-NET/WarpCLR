using System.Reflection.Emit;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class SourcePathAssertions
{
    internal static void Require(CapturedPlan plan)
    {
        string method = plan.Spec.Method;
        CilPoint[] points = OriginalCilReceipt.Decode(plan.Source.GetMethodBody()!.GetILAsByteArray()!);
        ProofEvidence.Require(points.Any(point => point.Name == "ret") && plan.Layout.Nodes.Any(node => node.SourceCost > 0),
            "Original Ret retains real positive source charge; no synthetic zero-cost entry relabel");
        if (method is "UnsignedSingle" or "UInt64ToSingle")
        {
            ProofEvidence.Require(points.Zip(points.Skip(1), (first, second) => first.Name == "conv.r.un" && second.Name == "conv.r4").Any(value => value) &&
                plan.Lowered.RequiredServices.Any(service => service.Contains("unsigned-single-adjacent", StringComparison.Ordinal)),
                "Original adjacent unsigned conversion and exact one-round service binding");
            ProofEvidence.Require(plan.Lowered.Bodies.SelectMany(body => body.SourceBlocks).Any(block => block.Instruction.OpCode == OpCodes.Conv_R_Un.Value) &&
                plan.Lowered.Bodies.SelectMany(body => body.SourceBlocks).Any(block => block.Instruction.OpCode == OpCodes.Conv_R4.Value), "Both original charged conversion maps retained");
        }
        if (method == "DoubleRound")
        {
            ProofEvidence.Require(plan.Source.GetMethodBody()!.LocalVariables.Single().LocalType == typeof(double) &&
                !plan.Lowered.RequiredServices.Any(service => service.Contains("unsigned-single-adjacent", StringComparison.Ordinal)) &&
                plan.Lowered.Bodies.SelectMany(body => body.Locals).Any(local => local.Type.Category == WarpPortableStackCategory.Binary64),
                "Real stored Double intermediate, two separate roundings, no adjacent conversion rewrite");
        }
        if (method == "Narrow")
        { ProofEvidence.Require(points.Any(point => point.Name == "conv.r4") && points.Any(point => point.Name == "conv.r8"), "Original Double->Single->Double CIL retained"); }
        if (method == "Small")
        { ProofEvidence.Require(plan.Lowered.Bodies[0].Arguments[0].Type.StorageBits == 8 && plan.Lowered.Bodies[0].Arguments[0].Type.IsSigned, "Original signed8 storage before I4 promotion"); }
        if (method is "Pipeline32" or "Pipeline64")
        { ProofEvidence.Require(points.Any(point => point.Name == "add") && points.Any(point => point.Name == "sub") && points.Any(point => point.Name == "mul") && points.Any(point => point.Name == "div"), "Original four-operand numerical path retained"); }
        if (method is "Round32" or "Round64")
        { ProofEvidence.Require(points.Any(point => point.Name == "mul") && points.Any(point => point.Name == "add"), "Original separately rounded multiplication/addition, no explicit FMA substitution"); }
        if (plan.Spec.Id == "original19-ExternalCall")
        {
            ProofEvidence.Require(plan.Source.ReturnType == typeof(uint) && points.Any(point => point.Name == "call") &&
                plan.Graph.Methods.Any(method => method.SourceMethod.DeclaringType == typeof(System.Numerics.BitOperations) &&
                    method.SourceMethod.Name == "RotateLeft" && method.SourceMethod.ReturnType == typeof(uint) &&
                    method.SourceMethod.GetParameters().Select(parameter => parameter.ParameterType).SequenceEqual(new[] { typeof(uint), typeof(int) }) &&
                    method.Intrinsic is not null), "Exact captured canonical UInt32/Int32 RotateLeft source intrinsic");
        }
        if (plan.Spec.Id == "added-DoubleToInt16")
        {
            ProofEvidence.Require(plan.Source.ReturnType == typeof(short) && points.Any(point => point.Name == "conv.i2") &&
                plan.Lowered.RequiredServices.Any(service => service.Contains("float-conv-i2-u2", StringComparison.Ordinal)) &&
                plan.Lowered.EntryProjection.ResultType.StorageBits == 16 && plan.Lowered.EntryProjection.ResultType.IsSigned,
                "Actual original conv.i2 and common signed32-intermediate/low16 declared signed storage service");
        }
        if (method == "ManifestMap") { Closure(plan, "ManifestHelper"); }
        if (method is "Call" or "Outer") { foreach (string name in new[] { "Rotate", "SumDown", "Mix" }) { Closure(plan, name); } }
    }

    private static void Closure(CapturedPlan plan, string name) =>
        ProofEvidence.Require(plan.Graph.Methods.Any(method => method.SourceMethod.Name == name && method.Cil.Length > 0 && method.Intrinsic is null),
            "Genuine original captured source closure: " + name);
}
