using System.Reflection;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed record CapturedPlan(CaseSpec Spec, MethodInfo Source, WarpPortableMethodGraph Graph,
    WarpPortableTypedProgram Typed, WarpPortableSourceHeapSchema Schema, WarpPortableWordLoweredProgram Lowered,
    WarpLogicalMachineLayout Layout)
{
    internal static CapturedPlan Capture(CaseSpec spec, MethodInfo source, RootInputs inputs)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
        WarpPortableWordLoweredProgram lowered = WarpPortableWordLowerer.Lower(graph, typed);
        WarpPortableWordProgramIdentity.Validate(graph, schema, lowered);
        var layout = new WarpLogicalMachineLayout(lowered.Kernel);
        RequireOrdinary(layout, inputs);
        ProofEvidence.Require(lowered.Kernel.Execution!.Bodies.Where(body => body.RuntimeHelper).All(body => body.SourceBlockCosts.All(cost => cost == 0)),
            "Pure numeric runtime services do not charge original source steps");
        var result = new CapturedPlan(spec, source, graph, typed, schema, lowered, layout);
        SourcePathAssertions.Require(result);
        return result;
    }

    internal static void RequireOrdinary(WarpLogicalMachineLayout layout, RootInputs inputs)
    {
        ProofEvidence.Require(WarpLogicalMachineLayout.Version == inputs.PhysicalMachineVersion && layout.Kernel.Execution is { } execution &&
            execution.IdentityVersion == inputs.OrdinaryMetadataVersion && execution.PrivateControllerProjection is null &&
            !execution.RuntimeStateAccess && !execution.ManagedExceptionTermination && !execution.LogicalWorkerAccess && layout.Kernel.ScalarArgumentCount == 0,
            "Exact ordinary typed numeric profile, no private/controller/source-authority capability");
    }

    internal object Describe() => new
    {
        Name = Spec.Id, Spec, Source = OriginalCilReceipt.Capture(Source), GraphHash = Graph.GraphHash, TypedHash = Typed.VerifiedHash,
        SchemaHash = Schema.SchemaHash, IrHash = WarpIrHash.Compute(Layout.Kernel), Lowered.LoweredHash, Lowered.MapsHash,
        CompilerIdentity = Lowered.CompilerIdentity!.IdentityHash, CompilerVersion = Lowered.CompilerIdentity!.IdentityVersion,
        MetadataVersion = Layout.Kernel.Execution!.IdentityVersion, PhysicalMachineVersion = WarpLogicalMachineLayout.Version,
        InputCount = Layout.Kernel.InputBufferCount, ScalarCount = Layout.Kernel.ScalarArgumentCount, Layout.RequiresManagedMemory,
        Layout.FrameWords, Layout.PrivateOffset, Layout.ResultWordCount, Layout.MaximumBlockCost,
        Types = Typed.Types, SourceBodies = Lowered.Bodies, EntryProjection = Lowered.EntryProjection,
        OriginalClosure = Graph.Methods.Select(method => new { method.Identity, Source = OriginalCilReceipt.Capture(method.SourceMethod, method.Intrinsic) }).ToArray(),
        Graph.Intrinsics, Lowered.RequiredServices,
        BodyMetadata = Layout.Kernel.Execution!.Bodies.Select(body => new { body.PrivateWordCount, body.RuntimeHelper, body.CountsSourceDepth,
            body.AliasOwnerFunction, body.AliasPrefixWords, Costs = body.SourceBlockCosts }).ToArray(),
        RootAuthority = false, PrivateRpc = false, GeneratedExecutionInParent = false,
    };
}
