using System.Reflection;
using WarpCLR.Compiler;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class CaptureDenials
{
    internal static void Run(CaseSpec spec, MethodInfo source, string directory)
    {
        uint[] state = [0x12345678, 0xFFFFFFFF, 0x80000000, 1]; uint[] arena = [0xDEADBEEF, 0x7F800001, 0xFFC54321];
        var banks = new Banks(state, arena, [[0x80000000], [0xFFFFFFFF]]); Banks before = banks.Copy();
        BankReceipt pre = BankReceipt.Write(Path.Combine(directory, "compiler-denial.pre.bank"), before);
        WarpVerificationException? refusal = null;
        try
        {
            WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
            WarpPortableWordLowerer.Lower(graph, WarpPortableTypedProgram.Verify(graph));
        }
        catch (WarpVerificationException error) { refusal = error; }
        BankReceipt post = BankReceipt.Write(Path.Combine(directory, "compiler-denial.post.bank"), banks);
        ProofEvidence.Write(Path.Combine(directory, "denial.json"), new { spec.Id, spec.Gap, spec.Classification,
            Source = OriginalCilReceipt.Capture(source), Denied = refusal is not null, Code = refusal?.Code, SourceOffset = refusal?.IlOffset,
            Error = refusal?.ToString(), Pre = pre, Post = post, GeneratedPlan = false, KernelExecuted = false, SourceAuthority = false,
            Status = "DEFAULT_DENIAL_REMAINS_NAMED_PRODUCTION_BLOCKER" });
        ProofEvidence.Equal(before.State, state, "Compiler denial cannot touch supplied State canary");
        ProofEvidence.Equal(before.Arena, arena, "Compiler denial cannot touch supplied Arena canary");
        ProofEvidence.Require(refusal?.IlOffset is { } offset && OriginalCilReceipt.Decode(source.GetMethodBody()!.GetILAsByteArray()!)
            .Any(point => point.Offset == offset && IsDeniedOpcode(spec.Method, point.Name)), "Exact original denied instruction/call, no unrelated rejection accepted");
    }

    private static bool IsDeniedOpcode(string method, string opcode) => method switch
    {
        "Divide" or "SignedDivide32" or "SignedDivide64" => opcode is "div" or "div.un",
        "ExternalCall" or "Sign32" or "Sign64" => opcode == "call",
        "DoubleToInt16" => opcode == "conv.i2",
        _ => method.StartsWith("CheckedAdd", StringComparison.Ordinal) ? opcode is "add.ovf" or "add.ovf.un" :
            method.StartsWith("CheckedDoubleTo", StringComparison.Ordinal) && opcode.StartsWith("conv.ovf.", StringComparison.Ordinal),
    };
}
