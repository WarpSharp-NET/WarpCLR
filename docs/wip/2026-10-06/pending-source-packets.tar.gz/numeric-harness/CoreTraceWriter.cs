using System.Globalization;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed class CoreTraceWriter(PreparedCase prepared, WarpLogicalMachineLayout layout, WarpCoreCLRWorkerProcess worker,
    RootInputs inputs, string directory)
{
    private readonly List<object> rows = [];
    internal int Count => rows.Count;

    internal async Task RunVectorAsync(PreparedVector vector)
    {
        vector.OracleReceipt.Validate(); Banks? firstFinal = null;
        foreach (int quantum in prepared.Quanta)
        {
            Banks initial = vector.Initial.Read();
            Banks completed = await TraceAsync(vector, initial, quantum, inputs.MaximumLogicalDepth, "default", vector.ExpectedMachineFault).ConfigureAwait(false);
            if (firstFinal is not null) { Whole(firstFinal, completed, "Identical completed/default-fault bank for both operational quanta"); }
            firstFinal = completed.Copy();
            if (vector.ExpectedMachineFault) { continue; }
            ulong charged = Remaining(initial.State) - Remaining(completed.State);
            ProofEvidence.Require(charged > 1 && charged <= (ulong)inputs.MaximumSourceSteps, "Finite exact original source charge, no helper charge");
            Banks exact = vector.Initial.Read(); SetBudget(exact.State, charged);
            await TraceAsync(vector, exact, quantum, inputs.MaximumLogicalDepth, "exact-source-budget", false).ConfigureAwait(false);
            Banks shortBudget = vector.Initial.Read(); SetBudget(shortBudget.State, charged - 1);
            await TraceAsync(vector, shortBudget, quantum, inputs.MaximumLogicalDepth, "one-short-source-budget", true, WarpLogicalMachineLayout.StepLimitFault).ConfigureAwait(false);
            if (prepared.Name == "original19-Recursive" && vector.RawArguments[0] >= 2)
            {
                Banks shallow = vector.Initial.Read(); shallow = shallow with { State = shallow.State[..layout.GetStateWords(2)] };
                await TraceAsync(vector, shallow, quantum, 2, "real-logical-call-depth-limit", true, WarpLogicalMachineLayout.CallDepthFault).ConfigureAwait(false);
            }
        }
    }

    private async Task<Banks> TraceAsync(PreparedVector vector, Banks initial, int quantum, int depth, string trace, bool fault, uint? faultKind = null)
    {
        Banks banks = initial.Copy();
        for (int attempt = 0; attempt < inputs.MaximumQuantaPerTrace && banks.State[WarpLogicalMachineLayout.StatusOffset] == WarpLogicalMachineLayout.Runnable; attempt++)
        {
            await StepAsync(vector, trace, banks, quantum, depth, attempt).ConfigureAwait(false);
        }
        uint status = banks.State[WarpLogicalMachineLayout.StatusOffset];
        ProofEvidence.Require(status == (fault ? WarpLogicalMachineLayout.Faulted : WarpLogicalMachineLayout.Completed), "Actual machine termination before admitted quantum/storage bound");
        if (fault)
        {
            uint actualKind = banks.State[WarpLogicalMachineLayout.FaultKindOffset];
            ProofEvidence.Require(faultKind is { } expected ? actualKind == expected : actualKind is WarpLogicalMachineLayout.StepLimitFault or WarpLogicalMachineLayout.CallDepthFault,
                "Exact source-budget/logical-depth machine fault; no numeric source fault substitute");
        }
        else
        {
            uint[] result = Enumerable.Range(0, layout.ResultWordCount).Select(word => banks.State[layout.GetResultWordOffset(word, depth)]).ToArray();
            ProofEvidence.Equal(vector.IndependentResult, result, "Complete original-width result tuple/padding and independent oracle");
        }
        string name = vector.Name + ".q" + quantum.ToString(CultureInfo.InvariantCulture) + "." + trace;
        ProofEvidence.Write(Path.Combine(directory, name + ".terminal.json"), new { vector.Name, Trace = trace, Quantum = quantum, Depth = depth,
            InitialSeed = vector.Initial, InitialBudget = Remaining(initial.State), FinalBudget = Remaining(banks.State), Status = status,
            FaultKind = banks.State[WarpLogicalMachineLayout.FaultKindOffset], CompleteResultWords = layout.ResultWordCount,
            WholeBank = BankReceipt.Write(Path.Combine(directory, name + ".terminal.bank"), banks), NumericFaultEhAuthority = false });
        return banks;
    }

    private async Task StepAsync(PreparedVector vector, string trace, Banks banks, int quantum, int depth, int attempt)
    {
        Banks before = banks.Copy(); string prefix = Path.Combine(directory, "step" + Count.ToString("D8", CultureInfo.InvariantCulture));
        BankReceipt pre = BankReceipt.Write(prefix + ".pre.bank", before); Exception? failure = null;
        try { await worker.ExecuteManagedQuantumAsync(layout, banks.Inputs, [], 0, banks.State, depth, quantum, banks.Arena, CancellationToken.None).ConfigureAwait(false); }
        catch (Exception error) { failure = error; }
        BankReceipt post = BankReceipt.Write(prefix + ".post.bank", banks);
        object? checkpoint = null;
        if (failure is null)
        {
            WarpCoreCLRWorkerProcess.WordCheckpoint exact = worker.RequireCommittedWordCheckpoint(banks.State, banks.Arena);
            worker.ValidateCommittedWordCheckpoint(exact, banks.State, banks.Arena);
            checkpoint = new { exact.Ordinal, exact.Sequence, exact.Module, exact.ProcessId, exact.IrHash, exact.RequestHash, exact.ResponseHash,
                Purpose = "Ordinary numeric proof; runtime-issued word receipt is not a Root Source grant" };
            RootConsistency.Check(prepared, layout, banks);
        }
        var row = new { Name = vector.Name, Trace = trace, Attempt = attempt, Quantum = quantum, MaximumDepth = depth, ScalarWords = Array.Empty<uint>(),
            Pre = pre, Post = post, InitialSeed = vector.Initial, prepared.IrHash, NativeComparable = failure is null,
            InvocationFailure = failure?.ToString(), AuthenticatedCheckpoint = checkpoint, RootAuthority = false, PrivateRpc = false };
        ProofEvidence.Write(prefix + ".json", row); rows.Add(row);
        if (failure is not null) { Whole(before, banks, "Failed RPC must not commit partial word buffers"); throw new InvalidDataException("Actual generated child transaction failed; full before/after retained", failure); }
        ProofEvidence.Equal(before.Arena, banks.Arena, "Pure source numeric tuple preserves all Arena canaries");
        for (int index = 0; index < before.Inputs.Length; index++) { ProofEvidence.Equal(before.Inputs[index], banks.Inputs[index], "Raw input column unchanged"); }
    }

    internal void Complete() => ProofEvidence.Write(Path.Combine(directory, "vectors.json"), new { Format = "warp.proof.current-numeric/ordinary-full-bank-traces/0.1",
        prepared.Name, prepared.IrHash, Count, Rows = rows, InitialSeeds = prepared.Vectors.Select(vector => vector.Initial),
        ScalarCount = 0, Status = "CORE_EXPECTED_SIDE_STOPPED_COMPLETE", RootAuthority = false, PrivateRpc = false });
    private static ulong Remaining(uint[] state) => state[WarpLogicalMachineLayout.RemainingStepsLowOffset] | (ulong)state[WarpLogicalMachineLayout.RemainingStepsHighOffset] << 32;
    private static void SetBudget(uint[] state, ulong value)
    { state[WarpLogicalMachineLayout.RemainingStepsLowOffset] = unchecked((uint)value); state[WarpLogicalMachineLayout.RemainingStepsHighOffset] = (uint)(value >> 32); }
    private static void Whole(Banks left, Banks right, string message)
    { ProofEvidence.Equal(left.State, right.State, message); ProofEvidence.Equal(left.Arena, right.Arena, message); foreach (int i in Enumerable.Range(0, left.Inputs.Length)) { ProofEvidence.Equal(left.Inputs[i], right.Inputs[i], message); } }
}
