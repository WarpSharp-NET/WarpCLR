using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class ProofEvidence
{
    internal static JsonSerializerOptions Options { get; } = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    internal static string Hash(byte[] data) => Convert.ToHexString(SHA256.HashData(data)).ToLowerInvariant();
    internal static string HashFile(string path) { using FileStream stream = File.OpenRead(path); return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant(); }
    internal static void Require(bool condition, string reason) { if (!condition) { throw new InvalidDataException(reason); } }
    internal static void Equal(uint[] left, uint[] right, string reason) => Require(left.AsSpan().SequenceEqual(right), reason);
    internal static void Write(string path, object value)
    {
        if (File.Exists(path)) { throw new IOException("Retained evidence cannot be overwritten: " + path); }
        File.WriteAllText(path, JsonSerializer.Serialize(value, Options) + "\n", new UTF8Encoding(false));
    }
    internal static T Read<T>(string path) => JsonSerializer.Deserialize<T>(File.ReadAllText(path), Options) ?? throw new InvalidDataException("Absent receipt " + path);
    internal static string Fresh(string path)
    {
        if (Directory.Exists(path) || File.Exists(path)) { throw new IOException("A fresh retained boundary is required."); }
        Directory.CreateDirectory(path); return Path.GetFullPath(path);
    }
    internal static FilePin Pin(string path) => new(Path.GetFullPath(path), HashFile(path));
}

internal sealed record Banks(uint[] State, uint[] Arena, uint[][] Inputs)
{
    internal Banks Copy() => new((uint[])State.Clone(), (uint[])Arena.Clone(), Inputs.Select(input => (uint[])input.Clone()).ToArray());
}
