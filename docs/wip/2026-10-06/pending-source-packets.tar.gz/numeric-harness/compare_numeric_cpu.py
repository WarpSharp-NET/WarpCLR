"""Root finite candidate adapter; original tool body retained by exact reference."""
import hashlib
import runpy
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
original = Path('/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/current-numeric-source-proof-packet/compare_numeric_cpu.py')
assert hashlib.sha256(original.read_bytes()).hexdigest() == 'cfd23db835d5d52bca87ec7b6506f099283dd5887123721c0492f8a2154ce94b'
runpy.run_path(str(original), run_name="__main__")
