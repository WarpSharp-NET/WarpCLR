using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class ChildStop
{
    internal static async Task CompleteAsync(WarpCoreCLRWorkerProcess worker, string path)
    {
        Exception? failure = null;
        try { await worker.DisposeAsync().ConfigureAwait(false); }
        catch (Exception error) { failure = error; }
        ProofEvidence.Write(path, new { worker.ProcessId, worker.CompiledModule, worker.IrHash, worker.IsClosed, worker.IsFaulted,
            worker.HasSuccessfulContainment, CleanupException = failure?.ToString(), QuotaSeconds = 2,
            Meaning = "Product-backed immutable first cleanup outcome plus complete held leader/descendant stop acknowledgement; no signal/empty-census substitute",
            RootExternalOwnedProducerStopReceiptStillRequired = true, NoRetry = true, NoLateOutcomePromotion = true });
        if (failure is not null) { throw new InvalidDataException("Exact child cleanup failed; retain all banks and stop failure, no overall comparison PASS", failure); }
        ProofEvidence.Require(worker.HasSuccessfulContainment, "Successful immutable first cleanup and complete containment closure required");
    }
}
