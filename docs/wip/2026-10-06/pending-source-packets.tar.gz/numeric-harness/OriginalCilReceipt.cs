using System.Reflection;
using System.Reflection.Emit;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class OriginalCilReceipt
{
    private static readonly Dictionary<ushort, OpCode> Opcodes = typeof(OpCodes).GetFields(BindingFlags.Public | BindingFlags.Static)
        .Where(field => field.FieldType == typeof(OpCode)).Select(field => (OpCode)field.GetValue(null)!)
        .GroupBy(opcode => unchecked((ushort)opcode.Value)).ToDictionary(group => group.Key, group => group.First());

    internal static object Capture(MethodBase method, string? intrinsic = null)
    {
        MethodBody? body = method.GetMethodBody(); byte[] cil = body?.GetILAsByteArray() ?? [];
        ProofEvidence.Require(cil.Length != 0 || intrinsic is not null, "Empty CIL allowed only for an exact catalog-bound intrinsic");
        string module = method.Module.FullyQualifiedName;
        return new { Signature = method.ToString(), Type = method.DeclaringType?.AssemblyQualifiedName, method.MetadataToken,
            Mvid = method.Module.ModuleVersionId, Assembly = method.Module.Assembly.FullName, ModulePath = module,
            ModuleSha256 = File.Exists(module) ? ProofEvidence.HashFile(module) : null, RuntimeCreatedOriginalCil = method.Module.Assembly.IsDynamic,
            ReturnType = (method as MethodInfo)?.ReturnType.AssemblyQualifiedName,
            Parameters = method.GetParameters().Select(parameter => new { parameter.Name, Type = parameter.ParameterType.AssemblyQualifiedName }).ToArray(),
            CilHex = Convert.ToHexString(cil), CilSha256 = ProofEvidence.Hash(cil), Instructions = Decode(cil),
            Locals = body?.LocalVariables.Select(local => new { local.LocalIndex, Type = local.LocalType.AssemblyQualifiedName, local.IsPinned }).ToArray(),
            MaxStackSize = body?.MaxStackSize, InitializeLocals = body?.InitLocals, ExactIntrinsic = intrinsic, OriginalSourceInvokeIsGeneratedExecution = false };
    }

    internal static CilPoint[] Decode(byte[] cil)
    {
        var rows = new List<CilPoint>();
        for (int offset = 0; offset < cil.Length;)
        {
            int start = offset; ushort value = cil[offset++];
            if (value == 0xFE) { ProofEvidence.Require(offset < cil.Length, "Truncated CIL opcode"); value = checked((ushort)(0xFE00 | cil[offset++])); }
            ProofEvidence.Require(Opcodes.TryGetValue(value, out OpCode opcode), "Actual CIL opcode identity");
            int count = OperandWords(cil, offset, opcode.OperandType);
            ProofEvidence.Require(offset + count <= cil.Length, "Actual CIL operand extent");
            rows.Add(new(start, value, opcode.Name!, Convert.ToHexString(cil.AsSpan(offset, count)))); offset += count;
        }
        return [.. rows];
    }

    private static int OperandWords(byte[] cil, int offset, OperandType kind) => kind switch
    {
        OperandType.InlineNone => 0,
        OperandType.ShortInlineBrTarget or OperandType.ShortInlineI or OperandType.ShortInlineVar => 1,
        OperandType.InlineVar => 2,
        OperandType.InlineI8 or OperandType.InlineR => 8,
        OperandType.InlineSwitch => checked(4 + 4 * System.Buffers.Binary.BinaryPrimitives.ReadInt32LittleEndian(cil.AsSpan(offset, 4))),
        _ => 4,
    };
}

internal sealed record CilPoint(int Offset, ushort OpCode, string Name, string OperandHex);
