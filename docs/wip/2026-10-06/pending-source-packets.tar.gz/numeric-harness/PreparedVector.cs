namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed record PreparedVector(string Name, ulong[] RawArguments, uint[] PhysicalInputWords, uint[] IndependentResult,
    bool ExpectedMachineFault, bool BoundedOriginalOracle, BankReceipt Initial, FilePin OracleReceipt);
internal sealed record PreparedCase(string Name, string Directory, FilePin Program, FilePin Plan, FilePin Emission,
    string IrHash, int StateWords, int FrameCapacity, int ArenaWords, int[] Quanta, PreparedVector[] Vectors);
internal sealed record PreparedSet(string Format, FilePin RootInputs, FilePin Inventory, FilePin Seeds, PreparedCase[] Cases,
    string[] DeniedProductionBlockers, FilePin StorageCensus, string[] AttemptedOriginalDenials, bool SourceAuthority, bool PrivateRpc);
