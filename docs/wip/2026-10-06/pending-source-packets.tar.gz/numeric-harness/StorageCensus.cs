using System.Numerics;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class StorageCensus
{
    internal static void Write(string path, IEnumerable<(CapturedPlan Plan, RawVector[] Vectors)> captured, RootInputs inputs, string output)
    {
        var rows = new List<object>(); BigInteger maximum = 0; int caseCount = 0;
        foreach ((CapturedPlan plan, RawVector[] vectors) in captured)
        {
            caseCount++;
            long words = checked((long)plan.Layout.GetStateWords(inputs.MaximumLogicalDepth) + 8 + plan.Layout.Kernel.InputBufferCount);
            long bank = checked(4 * (4 + plan.Layout.Kernel.InputBufferCount + words));
            // At each step: Core pre/post plus all three native pre/post. The
            // native adapter also saves pre, even though it is equal to Core pre.
            // Two quanta times base/exact/one-short plus shallow recursion;
            // bounded faults use a subset. Reserve eight traces, plus every
            // complete terminal bank, for every vector.
            BigInteger bytes = (BigInteger)vectors.Length * (bank + (BigInteger)8 * (inputs.MaximumQuantaPerTrace * 8L + 1) * bank);
            maximum += bytes;
            rows.Add(new { plan.Spec.Id, Vectors = vectors.Length, StateWords = plan.Layout.GetStateWords(inputs.MaximumLogicalDepth),
                PhysicalFrameCapacity = plan.Layout.GetPhysicalFrameCapacity(inputs.MaximumLogicalDepth), FrameStride = plan.Layout.FrameWords,
                InputWords = plan.Layout.Kernel.InputBufferCount, ScalarWords = 0, ArenaWords = 8, ResultWords = plan.Layout.ResultWordCount,
                BankBytes = bank, MaximumTraceCount = 8 * vectors.Length, inputs.MaximumQuantaPerTrace, MaximumBankBytes = bytes.ToString(System.Globalization.CultureInfo.InvariantCulture) });
        }
        BigInteger required = maximum + inputs.ImageAndLogReserveBytes;
        long free = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(output))!).AvailableFreeSpace;
        ProofEvidence.Write(path, new { Format = "warp.proof.current-numeric/pre-execution-full-bank-storage-census/0.1", Cases = rows,
            Formula = "bankBytes=4*(4+InputCount+StateWords+ArenaWords+sum(InputLengths)); max=Σvectors*(1 initial +8 traces*(maximumQuanta*8 Core/native pre/post +1 terminal))*bankBytes + image/log reserve",
            MaximumBankBytes = maximum.ToString(System.Globalization.CultureInfo.InvariantCulture), RequiredBytes = required.ToString(System.Globalization.CultureInfo.InvariantCulture),
            inputs.ReservedBankBytes, inputs.ImageAndLogReserveBytes, inputs.MinimumFreeBytesAfterReservation, ObservedFreeBytes = free, DoesNotDeleteEvidence = true,
            ExecutedQuanta = 0, NativeImages = 3 * caseCount, CpuLibraries = 3 * caseCount, RowsAreConservativeBounds = true });
        ProofEvidence.Require(required <= inputs.ReservedBankBytes && required + inputs.MinimumFreeBytesAfterReservation <= free, "Complete bank reservation and the owner 50 GiB minimum remaining free space are required before execution");
    }
}
