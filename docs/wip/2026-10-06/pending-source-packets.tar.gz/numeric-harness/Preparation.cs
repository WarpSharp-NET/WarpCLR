using System.Text.Json;
using WarpCLR.IR;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class Preparation
{
    internal static void Run(string inputPath, string inventoryPath, string output, RootInputs inputs)
    {
        string directory = ProofEvidence.Fresh(output); CaseInventory inventory = ProofEvidence.Read<CaseInventory>(inventoryPath);
        inventory.Validate(inputs); using var source = new OriginalSources(inputs);
        using JsonDocument seeds = JsonDocument.Parse(File.ReadAllText(inventory.SeedInventory.Path));
        using JsonDocument floatSeeds = JsonDocument.Parse(File.ReadAllText(inventory.CandidateFloat16Seeds!.Path));
        var recipes = new RawVectors(seeds.RootElement, floatSeeds.RootElement); var prepared = new List<PreparedCase>();
        var captured = new List<(CapturedPlan Plan, RawVector[] Vectors)>();
        ProofEvidence.Write(Path.Combine(directory, "input-identity.json"), new { Input = ProofEvidence.Pin(inputPath), inputs, Inventory = ProofEvidence.Pin(inventoryPath),
            CurrentArtifactClaim = "Only explicit future actual Root receipts; source-plan v2 is consistency provenance" });
        try
        {
            foreach (CaseSpec spec in inventory.RemainingDenials)
            {
                string denied = Path.Combine(directory, spec.Id); Directory.CreateDirectory(denied);
                CaptureDenials.Run(spec, source.Resolve(spec), denied);
            }
            foreach (CaseSpec spec in inventory.ProofCases)
            {
                CapturedPlan plan = CapturedPlan.Capture(spec, source.Resolve(spec), inputs);
                captured.Add((plan, recipes.Create(plan)));
            }
            string storage = Path.Combine(directory, "storage-census.json"); StorageCensus.Write(storage, captured, inputs, directory);
            foreach ((CapturedPlan plan, RawVector[] vectors) in captured) { prepared.Add(PrepareCase(plan, vectors, inputs, directory)); }
            inputs.VerifyLoadedAssemblies();
            ProofEvidence.Write(Path.Combine(directory, "prepared.json"), new PreparedSet("warp.proof.current-numeric/prepared-captured-source/0.2",
                ProofEvidence.Pin(inputPath), ProofEvidence.Pin(inventoryPath), inventory.SeedInventory, [.. prepared],
                inventory.RemainingDenials.Select(row => row.Id).ToArray(), ProofEvidence.Pin(storage), inventory.CandidateAttempts, false, false));
        }
        catch (Exception error)
        { ProofEvidence.Write(Path.Combine(directory, "preparation-failure.json"), new { Error = error.ToString(), Completed = prepared, OverallPass = false }); throw; }
    }

    private static PreparedCase PrepareCase(CapturedPlan plan, RawVector[] vectors, RootInputs inputs, string output)
    {
        string directory = Path.Combine(output, plan.Spec.Id); Directory.CreateDirectory(directory); PlanArtifacts.Write(plan, inputs, directory);
        uint[] initial = plan.Layout.CreateInitialState(inputs.MaximumLogicalDepth, inputs.MaximumSourceSteps);
        // One genuine namespace allocation per case, outside all seed/dialect/quantum loops.
        var rows = new List<PreparedVector>();
        foreach (RawVector vector in vectors)
        {
            uint[][] physical = vector.PhysicalWords.Select(word => new uint[] { word }).ToArray();
            ProofEvidence.Require(physical.Length == plan.Layout.Kernel.InputBufferCount, "Exact original parameter word packing");
            uint[] arena = [0xDEADBEEF, 0x80000000, 0x7F800001, 0xFFC54321, 1, 0xFFFFFFFF, 0x12345678, 0];
            var banks = new Banks((uint[])initial.Clone(), arena, physical);
            string prefix = Path.Combine(directory, vector.Name);
            uint[] expected = NumericOracle.Expected(plan, vector);
            object original = OriginalClrOracle.Check(plan, vector, expected);
            ProofEvidence.Write(prefix + ".oracle.json", new { vector, IndependentResult = expected, Original = original,
                IndependentKind = "Exact bit/rational/BigInteger model; linked independent BigInteger Sqrt/fmod/FMA oracle", ProductionServiceUsedAsOracle = false });
            rows.Add(new(vector.Name, vector.Arguments, vector.PhysicalWords, expected, vector.ExpectedMachineFault,
                vector.BoundedSourceOracle, BankReceipt.Write(prefix + ".initial.bank", banks), ProofEvidence.Pin(prefix + ".oracle.json")));
        }
        return new(plan.Spec.Id, Path.GetFullPath(directory), ProofEvidence.Pin(Path.Combine(directory, "program.json")),
            ProofEvidence.Pin(Path.Combine(directory, "word-plan.bin")), ProofEvidence.Pin(Path.Combine(directory, "emitted.json")),
            WarpIrHash.Compute(plan.Layout.Kernel), initial.Length, plan.Layout.GetPhysicalFrameCapacity(inputs.MaximumLogicalDepth), 8,
            [plan.Layout.MaximumBlockCost, Math.Max(4096, checked(plan.Layout.MaximumBlockCost + 1))], [.. rows]);
    }
}
