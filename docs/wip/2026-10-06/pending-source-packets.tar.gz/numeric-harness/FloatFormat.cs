using System.Numerics;

namespace WarpCLR.Tests.CurrentNumericProof;

// Proof-only rational/bit oracle. BigInteger never enters the product graph.
internal readonly record struct FloatFormat(int Width)
{
    internal int Fraction => Width == 32 ? 23 : 52;
    internal int Bias => Width == 32 ? 127 : 1023;
    internal ulong Sign => Width == 32 ? 0x80000000 : 0x8000000000000000;
    internal ulong FractionMask => (1UL << Fraction) - 1;
    internal ulong Infinity => Width == 32 ? 0x7F800000 : 0x7FF0000000000000;
    internal ulong NaN => Width == 32 ? 0x7FC00000 : 0x7FF8000000000000;
    internal bool IsNaN(ulong value) => (value & ~Sign) > Infinity;
    internal bool IsInfinite(ulong value) => (value & ~Sign) == Infinity;
    internal bool IsZero(ulong value) => (value & ~Sign) == 0;
    internal bool Negative(ulong value) => (value & Sign) != 0;
    internal (BigInteger Significand, int Exponent) Decode(ulong value)
    {
        int encoded = (int)(value >> Fraction & (Width == 32 ? 255UL : 2047UL));
        ulong fraction = value & FractionMask;
        BigInteger significand = encoded == 0 ? fraction : fraction | (1UL << Fraction);
        return (Negative(value) ? -significand : significand, Math.Max(encoded, 1) - Bias - Fraction);
    }

    internal ulong Round(BigInteger numerator, BigInteger denominator, int exponent, bool negativeZero = false)
    {
        ProofEvidence.Require(denominator > 0, "Positive independent rational denominator");
        if (numerator == 0) { return negativeZero ? Sign : 0; }
        ulong sign = numerator.Sign < 0 ? Sign : 0; numerator = BigInteger.Abs(numerator);
        int leading = checked((int)(numerator.GetBitLength() - denominator.GetBitLength()));
        if (leading >= 0 ? numerator < (denominator << leading) : (numerator << -leading) < denominator) { leading--; }
        leading += exponent;
        int unit = Math.Max(leading - Fraction, 1 - Bias - Fraction);
        int scale = exponent - unit;
        BigInteger scaledNumerator = scale >= 0 ? numerator << scale : numerator;
        BigInteger scaledDenominator = scale >= 0 ? denominator : denominator << -scale;
        BigInteger rounded = BigInteger.DivRem(scaledNumerator, scaledDenominator, out BigInteger remainder);
        if (2 * remainder > scaledDenominator || (2 * remainder == scaledDenominator && !rounded.IsEven)) { rounded++; }
        if (rounded >= BigInteger.One << (Fraction + 1)) { rounded >>= 1; unit++; }
        if (unit + Fraction > Bias) { return sign | Infinity; }
        if (rounded < BigInteger.One << Fraction) { return sign | checked((ulong)rounded); }
        return sign | checked((ulong)(unit + Fraction + Bias)) << Fraction | (checked((ulong)rounded) & FractionMask);
    }

    internal ulong Convert(ulong value, FloatFormat destination)
    {
        if (IsNaN(value)) { return destination.NaN; }
        if (IsInfinite(value)) { return destination.Infinity | (Negative(value) ? destination.Sign : 0); }
        (BigInteger significand, int exponent) = Decode(value);
        return destination.Round(significand, BigInteger.One, exponent, Negative(value));
    }
}
