using System.Buffers.Binary;
using System.Text;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class PlanArtifacts
{
    internal static void Write(CapturedPlan plan, RootInputs inputs, string directory)
    {
        string hash = WarpIrHash.Compute(plan.Layout.Kernel);
        byte[] bytes = WarpCoreCLRBinaryPlanCodec.Serialize(plan.Layout.Kernel);
        ProofEvidence.Require(BinaryPrimitives.ReadUInt32LittleEndian(bytes) == inputs.OrdinaryCodecMagic, "Ordinary conditional wire format");
        WarpControlFlowKernel decoded = WarpCoreCLRBinaryPlanCodec.Deserialize(bytes, hash);
        ProofEvidence.Require(WarpIrHash.Compute(decoded) == hash && bytes.AsSpan().SequenceEqual(WarpCoreCLRBinaryPlanCodec.Serialize(decoded)),
            "Complete width/tuple/roots/source-cost/capability hash and codec byte round trip");
        File.WriteAllBytes(Path.Combine(directory, "word-plan.bin"), bytes);
        ProofEvidence.Write(Path.Combine(directory, "program.json"), plan.Describe());
        var emitted = new List<object>();
        foreach (WarpBackendKind dialect in new[] { WarpBackendKind.NVPTX, WarpBackendKind.AMDGPU, WarpBackendKind.SPIRV })
        {
            string text = WarpPortableMachineEmitter.Emit(plan.Layout, dialect);
            ProofEvidence.Require(!System.Text.RegularExpressions.Regex.IsMatch(text, @"\b(fadd|fsub|fmul|fdiv|frem|fptrunc|fpext|sitofp|uitofp|fptosi|fptoui)\b"),
                "Exact strict word graph; vendor floating arithmetic or conversions cannot replace the source widths");
            string path = Path.Combine(directory, dialect + ".gpu.ll"); File.WriteAllText(path, text, new UTF8Encoding(false));
            emitted.Add(new { Dialect = dialect.ToString(), Path = Path.GetFullPath(path), Sha256 = ProofEvidence.HashFile(path), IrHash = hash,
                GraphHash = plan.Graph.GraphHash, TypedHash = plan.Typed.VerifiedHash, EntryPoint = WarpPortableMachineEmitter.EntryPoint });
        }
        ProofEvidence.Write(Path.Combine(directory, "emitted.json"), new { PlanSha256 = ProofEvidence.Hash(bytes), IrHash = hash, Dialects = emitted,
            ActualNativeCompilation = false, ActualGpuExecution = false });
    }
}
