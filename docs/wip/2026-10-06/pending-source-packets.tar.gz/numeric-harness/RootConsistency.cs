using System.Text.Json;
using WarpCLR.IR;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class RootConsistency
{
    internal static void Check(PreparedCase prepared, WarpLogicalMachineLayout layout, Banks banks)
    {
        if (prepared.Name != "root-consistency-multiply-tuple") { return; }
        using JsonDocument document = JsonDocument.Parse(File.ReadAllText(prepared.Program.Path));
        JsonElement program = document.RootElement; uint depth = banks.State[WarpLogicalMachineLayout.DepthOffset];
        bool helper = Enumerable.Range(0, checked((int)depth)).Select(frame => checked((int)banks.State[WarpLogicalMachineLayout.HeaderWords + frame * layout.FrameWords]))
            .Any(function => function != 0 && layout.Kernel.Execution!.Bodies[function].RuntimeHelper);
        bool sourceRoot = false;
        for (int frame = 0; frame < depth; frame++)
        {
            int start = WarpLogicalMachineLayout.HeaderWords + frame * layout.FrameWords;
            int function = checked((int)banks.State[start + WarpLogicalMachineLayout.FrameFunctionOffset]);
            if (!helper) { continue; }
            foreach (JsonElement body in program.GetProperty("sourceBodies").EnumerateArray())
            {
                if (body.GetProperty("function").GetInt32() != function) { continue; }
                foreach (JsonElement argument in body.GetProperty("arguments").EnumerateArray())
                {
                    if (argument.GetProperty("type").GetProperty("managedRootByteOffsets").GetArrayLength() == 0) { continue; }
                    int offset = start + layout.PrivateOffset + argument.GetProperty("wordOffset").GetInt32();
                    ProofEvidence.Require(banks.State.AsSpan(offset, 3).SequenceEqual(new uint[] { 17, 4, 29 }), "Complete source caller opaque root survives the pure helper");
                    sourceRoot = true;
                }
            }
        }
        if (helper) { ProofEvidence.Require(sourceRoot, "Source root frame exists while runtime numeric helper is suspended"); }
        JsonElement projection = program.GetProperty("entryProjection");
        ProofEvidence.Require(projection.GetProperty("wrapperInputRoots").GetArrayLength() > 0 &&
            projection.GetProperty("wrapperReturnedRoots").GetArrayLength() > 0 && projection.GetProperty("resultRoots").GetArrayLength() > 0,
            "Complete actual wrapper/returned/result root maps, no synthetic five-word tuple assumption");
        // Full State/Arena equality additionally covers all private/SSA/alias
        // roots. This consistency witness does not establish managed heap roots.
    }
}
