using System.Numerics;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class NumericOracle
{
    internal static uint[] Expected(CapturedPlan plan, RawVector vector)
    {
        if (vector.ExpectedMachineFault) { return []; }
        if (plan.Spec.Classification == "reference-root-consistency") { return RootTuple(plan, vector); }
        string method = plan.Spec.Method; ulong[] a = vector.Arguments;
        if (plan.Source.ReturnType == typeof(float) || plan.Source.ReturnType == typeof(double))
        {
            int width = plan.Source.ReturnType == typeof(float) ? 32 : 64;
            return Words(Floating(plan, a, width), width);
        }
        if (plan.Source.ReturnType == typeof(bool))
        {
            var f = new FloatFormat(plan.Source.GetParameters()[0].ParameterType == typeof(float) ? 32 : 64);
            bool ordered = !f.IsNaN(a[0]) && !f.IsNaN(a[1]); int order = ordered ? FloatOracle.Compare(f, a[0], a[1]) : 0;
            bool result = method.StartsWith("LessOrEqual", StringComparison.Ordinal) ? ordered && order <= 0 :
                method.StartsWith("Less", StringComparison.Ordinal) ? ordered && order < 0 : method.StartsWith("NotEqual", StringComparison.Ordinal) ? !ordered || order != 0 : ordered && order == 0;
            return [result ? 1u : 0];
        }
        return IntegerResult(plan, a);
    }

    private static ulong Floating(CapturedPlan plan, ulong[] a, int width)
    {
        string method = plan.Spec.Method; var f = new FloatFormat(width);
        if (method.StartsWith("Transport", StringComparison.Ordinal)) { return a[0]; }
        if (method == "Narrow") { return new FloatFormat(32).Convert(f.Convert(a[0], new(32)), f); }
        if (method == "Widen32To64") { return new FloatFormat(32).Convert(a[0], f); }
        if (method == "DoubleRound") { return new FloatFormat(64).Convert(new FloatFormat(64).Round(a[0], BigInteger.One, 0), f); }
        Type input = plan.Source.GetParameters()[0].ParameterType;
        if (input != typeof(float) && input != typeof(double))
        { return f.Round(Integer(a[0], input), BigInteger.One, 0); }
        if (method.StartsWith("Pipeline", StringComparison.Ordinal))
        { return FloatOracle.Divide(f, FloatOracle.Multiply(f, FloatOracle.Add(f, a[0], a[1]), FloatOracle.Add(f, a[2], a[3] ^ f.Sign)), FloatOracle.Add(f, a[0], a[1] ^ f.Sign)); }
        if (method == "FloatingPoint") { return FloatOracle.Add(f, a[0], 0x3F800000); }
        if (method == "Constant") { return FloatOracle.Add(f, FloatOracle.Add(f, a[0], 0x3FB999999999999A), a[0] ^ f.Sign); }
        if (method.StartsWith("Round", StringComparison.Ordinal)) { return FloatOracle.Add(f, FloatOracle.Multiply(f, a[0], a[1]), a[2]); }
        if (method.StartsWith("Local", StringComparison.Ordinal)) { ulong sum = FloatOracle.Add(f, a[0], a[1]); return FloatOracle.Multiply(f, sum, sum); }
        if (method.StartsWith("Negate", StringComparison.Ordinal)) { return f.IsNaN(a[0]) ? f.NaN : a[0] ^ f.Sign; }
        if (method.StartsWith("Remainder", StringComparison.Ordinal)) { return Production.WarpPortableMathOracle.Remainder(a[0], a[1], width, nearest: false); }
        if (method.StartsWith("Minimum", StringComparison.Ordinal)) { return FloatOracle.MinMax(f, a[0], a[1], maximum: false); }
        if (method.StartsWith("Maximum", StringComparison.Ordinal)) { return FloatOracle.MinMax(f, a[0], a[1], maximum: true); }
        if (method.StartsWith("Sqrt", StringComparison.Ordinal)) { return Production.WarpPortableMathOracle.Sqrt(a[0], width); }
        if (method.StartsWith("Fma", StringComparison.Ordinal)) { return Production.WarpPortableMathOracle.FusedMultiplyAdd(a[0], a[1], a[2], width); }
        throw new InvalidDataException("Unmodeled original floating source: " + plan.Spec.Id);
    }

    private static uint[] IntegerResult(CapturedPlan plan, ulong[] a)
    {
        string method = plan.Spec.Method; Type resultType = plan.Source.ReturnType;
        int width = resultType == typeof(long) || resultType == typeof(ulong) ? 64 : 32;
        BigInteger value;
        if (plan.Source.GetParameters()[0].ParameterType == typeof(float) || plan.Source.GetParameters()[0].ParameterType == typeof(double))
        {
            var f = new FloatFormat(plan.Source.GetParameters()[0].ParameterType == typeof(float) ? 32 : 64);
            if (resultType == typeof(short) || resultType == typeof(ushort))
            {
                // RyuJIT10.0.12's small conversion first truncates/clamps to signed32.
                // The declared return stores only low16; its sign does not widen storage.
                value = FloatOracle.ToInteger(f, a[0], 32, signed: true) & 0xFFFF;
            }
            else { value = FloatOracle.ToInteger(f, a[0], width, resultType == typeof(int) || resultType == typeof(long)); }
        }
        else if (method is "ManifestMap" or "ManifestReduction" or "ManifestHelper") { value = (BigInteger)a[0] * 33 + a[1]; }
        else if (method == "Grayscale") { return [Grayscale(unchecked((uint)a[0]))]; }
        else if (method == "Combine") { value = ((a[0] + (BigInteger)a[1] * 17) ^ a[2]) << (int)(a[3] & 31); }
        else if (method == "Scramble") { uint first = unchecked((uint)(a[0] - 0xDEADBEEF)); value = ~(first >> (int)(a[1] & 31)) | unchecked((uint)a[0] << 3); }
        else if (method == "Branch") { value = a[0] == 0 ? 1 : 2; }
        else if (method == "CompareAndSelect") { value = a[0] < a[1] ? (BigInteger)a[0] + 1 : a[0] == a[1] ? 0xA5A5A5A5 : (BigInteger)a[0] - 1; }
        else if (method is "Loop" or "SumDown") { value = Sum(a[0]); }
        else if (method == "Recursive") { value = a[0]; }
        else if (method is "Call" or "Outer") { value = ((BigInteger)Rotate(unchecked((uint)a[0])) * 33) ^ Sum(a[0] & 7); }
        else if (method is "Rotate" or "ExternalCall") { value = Rotate(unchecked((uint)a[0])); }
        else if (method == "Mix") { value = ((BigInteger)a[0] * 33) ^ a[1]; }
        else if (method == "WrongParameter") { value = a[0]; }
        else if (method == "Small") { value = Integer(a[0], typeof(sbyte)) + 256; }
        else if (method is "Wide" or "AddInt32" or "AddUInt32" or "AddInt64" or "AddUInt64") { value = (BigInteger)a[0] + a[1]; }
        else if (method is "ShiftSigned32" or "ShiftSigned64") { value = Integer(a[0], plan.Source.GetParameters()[0].ParameterType) >> (int)(a[1] & (uint)(width - 1)); }
        else { throw new InvalidDataException("Unmodeled original integer source: " + plan.Spec.Id); }
        return Words(Wrap(value, width), width);
    }

    internal static BigInteger Integer(ulong bits, Type type)
    {
        int width = type == typeof(sbyte) ? 8 : type == typeof(long) || type == typeof(ulong) ? 64 : 32;
        BigInteger raw = (BigInteger)bits & ((BigInteger.One << width) - 1);
        bool signed = type == typeof(sbyte) || type == typeof(int) || type == typeof(long);
        return signed && raw >= BigInteger.One << (width - 1) ? raw - (BigInteger.One << width) : raw;
    }
    private static ulong Wrap(BigInteger value, int width) => checked((ulong)(value & ((BigInteger.One << width) - 1)));
    internal static uint[] Words(ulong bits, int width) => width == 32 ? [unchecked((uint)bits)] : [unchecked((uint)bits), (uint)(bits >> 32)];
    private static BigInteger Sum(ulong n) => (BigInteger)n * (n + 1) / 2;
    private static uint Rotate(uint value) => (value << 1) | (value >> 31);
    private static uint Grayscale(uint rgba)
    { uint gray = ((rgba & 255) * 77 + ((rgba >> 8) & 255) * 150 + ((rgba >> 16) & 255) * 29) >> 8; return (rgba & 0xFF000000) | (gray * 0x10101); }

    private static uint[] RootTuple(CapturedPlan plan, RawVector vector)
    {
        var type = plan.Lowered.EntryProjection.ResultType; uint[] result = new uint[type.WordCount];
        var root = type.Fields.Single(field => !field.IsStatic && plan.Typed.Types.Single(value => value.Identity == field.TypeIdentity).Category == WarpPortableStackCategory.Reference);
        var number = type.Fields.Single(field => !field.IsStatic && plan.Typed.Types.Single(value => value.Identity == field.TypeIdentity).Category == WarpPortableStackCategory.Binary64);
        ProofEvidence.Require(root.ByteSize == 12 && number.ByteSize == 8 && type.ManagedRootByteOffsets.Contains(root.ByteOffset), "Actual tuple root/type/padding map");
        for (int word = 0; word < 3; word++) { Pack(result, root.ByteOffset + 4 * word, vector.PhysicalWords[word]); }
        uint[] product = Words(FloatOracle.Multiply(new(64), vector.Arguments[1], vector.Arguments[2]), 64);
        for (int word = 0; word < 2; word++) { Pack(result, number.ByteOffset + 4 * word, product[word]); }
        return result;
    }
    private static void Pack(uint[] result, int offset, uint value)
    { for (int part = 0; part < 4; part++) { int location = offset + part; result[location / 4] |= ((value >> (8 * part)) & 255) << (8 * (location % 4)); } }
}
