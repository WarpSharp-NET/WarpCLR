"""Root finite candidate adapter; original tool body retained by exact reference."""
import hashlib
import runpy
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
original = Path('/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/current-numeric-source-proof-packet/retarget_numeric.py')
assert hashlib.sha256(original.read_bytes()).hexdigest() == '3ba05dcdbd46f2b8fb6467e6b43a02757d240e4fe06a89056b3656c21a335d32'
runpy.run_path(str(original), run_name="__main__")
