"""Future independent finite-matrix join; every denied row remains a blocker."""
import argparse
import pathlib
from proof_tools import DIALECTS, pin, read, receipt, require, sha, validate_prepared, write_new


def main():
    parser = argparse.ArgumentParser()
    for name in ["root-inputs", "prepared", "core", "native-receipts", "comparisons", "root-stop", "output"]:
        parser.add_argument("--" + name, type=pathlib.Path, required=True)
    args = parser.parse_args()
    prepared, _ = validate_prepared(args.prepared, args.root_inputs)
    core = read(args.core / "core-result.json")
    require(core["status"] == "GENERATED_CORE_BANKS_COMPLETE_NATIVE_COMPARISONS_PENDING" and len(core["cases"]) == len(prepared["cases"]) == 77 and
            core["deniedProductionBlockers"] == prepared["deniedProductionBlockers"], "Complete stopped generated Core expected side")
    require({row["name"] for row in core["cases"]} == {row["name"] for row in prepared["cases"]}, "No current candidate omitted")
    rows, words, counts = [], 0, 0
    for case in prepared["cases"]:
        shared = [seed["initial"] for seed in case["vectors"]]
        witnesses = []
        for dialect in DIALECTS:
            native_path = args.native_receipts / case["name"] / (dialect + ".json")
            native = read(native_path)
            comparison_path = args.comparisons / case["name"] / dialect / "result.json"
            result = read(comparison_path)
            require(native["format"] == "warp.proof.current-numeric/compiled-target-image/0.1" and
                    native["commonIrHash"] == case["irHash"] and native["program"] == case["program"] and native["wordPlan"] == case["plan"],
                    "All three actual device compilation images from the same original program/type/IR")
            pin(native["image"]); pin(native["source"]); pin(native["positiveProducerStop"])
            require(result["status"] == "OFFLINE_CPU_COMPLETE" and result["case"] == case["name"] and result["dialect"] == dialect and
                    result["initialSeeds"] == shared and result["rootInputs"]["sha256"] == sha(args.root_inputs), "Shared identical complete seeds and actual current inputs")
            require(all(row["wholeBanksEqual"] and row["difference"] is None for row in result["rows"]), "Every complete bank equals matching generated Core bank")
            pin(result["imageReceipt"]); pin(result["coreVectors"]); pin(result["coreStop"])
            # Join raw bank content/lengths, not JSON serialization formatting.
            witnesses.append([(step["name"], step["trace"], step["quantum"], step["initialSeed"]["sha256"], step["corePre"]["sha256"],
                               step["corePost"]["sha256"], step["nativePost"]["sha256"]) for step in result["rows"]])
            for step in result["rows"]:
                for bank in [step["corePre"], step["corePost"], step["nativePre"], step["nativePost"]]:
                    pin(bank)
            counts += result["comparisons"]; words += result["wholeWordsCompared"]
            rows.append({"case": case["name"], "dialect": dialect, "native": receipt(native_path), "comparison": receipt(comparison_path)})
        require(witnesses[0] == witnesses[1] == witnesses[2], "Same complete seeded per-step bank bytes across all dialects; no per-backend namespace reallocation")
    root_stop = read(args.root_stop)
    require(root_stop["immutableFirstOutcome"] == "Succeeded" and root_stop["ownedProducerCensusEmpty"] and
            root_stop["allHeldContainedProcessesTerminal"], "Root actual complete held-identity stopped producer boundary")
    pin(root_stop["heldIdentityProof"])
    write_new(args.output, {"format": "warp.proof.current-numeric/finite-matrix-join/0.1", "status": "FINITE_OFFLINE_SOURCE_MATRIX_COMPLETE_PRODUCTION_GAPS_REMAIN",
              "numericSourceCandidates": len(prepared["cases"]) - 1, "referenceConsistencyLayouts": 1,
              "attemptedOriginalDenials": prepared["attemptedOriginalDenials"], "originalCaseCount": 90,
              "actualTargetImages": len(rows), "cpuLibraries": len(rows),
              "comparisons": counts, "wholeWordsCompared": words, "rows": rows, "deniedProductionBlockers": prepared["deniedProductionBlockers"],
              "rootInputs": receipt(args.root_inputs), "prepared": receipt(args.prepared), "core": receipt(args.core / "core-result.json"),
              "producerStop": receipt(args.root_stop), "gpu": False, "privateRpc": False, "sourceAuthority": False, "productionReadiness": False})


if __name__ == "__main__":
    main()
