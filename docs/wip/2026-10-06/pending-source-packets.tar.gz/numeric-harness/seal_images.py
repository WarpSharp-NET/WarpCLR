"""Root finite candidate adapter; original tool body retained by exact reference."""
import hashlib
import runpy
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
original = Path('/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/current-numeric-source-proof-packet/seal_images.py')
assert hashlib.sha256(original.read_bytes()).hexdigest() == '9a3fa5b5e3eb72bddf770b5c633b0eb47b74ebd4ea52373268d783617435b7b5'
runpy.run_path(str(original), run_name="__main__")
