using System.Text;

namespace WarpCLR.Tests.CurrentNumericProof;

// Explicit adapter to the sealed v4 bank_format.py WBP4 transport. It reuses
// the raw format, not the old private profile/case inventory or expected DLLs.
internal sealed record BankReceipt(string Path, string Sha256, int StateWords, int ArenaWords, int[] InputLengths)
{
    internal static BankReceipt Write(string path, Banks banks)
    {
        using (FileStream stream = new(path, FileMode.CreateNew, FileAccess.Write))
        using (var writer = new BinaryWriter(stream, Encoding.UTF8))
        {
            writer.Write(0x34504257u); writer.Write(banks.State.Length); writer.Write(banks.Arena.Length); writer.Write(banks.Inputs.Length);
            foreach (uint[] input in banks.Inputs) { writer.Write(input.Length); }
            foreach (uint[] words in new[] { banks.State, banks.Arena }.Concat(banks.Inputs))
            { foreach (uint word in words) { writer.Write(word); } }
        }
        return new(System.IO.Path.GetFullPath(path), ProofEvidence.HashFile(path), banks.State.Length, banks.Arena.Length, banks.Inputs.Select(input => input.Length).ToArray());
    }

    internal Banks Read()
    {
        new FilePin(Path, Sha256).Validate();
        using var reader = new BinaryReader(File.OpenRead(Path));
        ProofEvidence.Require(reader.ReadUInt32() == 0x34504257u && reader.ReadInt32() == StateWords &&
            reader.ReadInt32() == ArenaWords && reader.ReadInt32() == InputLengths.Length, "Exact WBP4 full bank header");
        ProofEvidence.Require(StateWords >= 0 && ArenaWords >= 0 && StateWords <= 16777216 && ArenaWords <= 16777216 &&
            InputLengths.Length <= 128 && InputLengths.All(length => length is >= 0 and <= 16777216), "Bounded bank admission");
        foreach (int length in InputLengths) { ProofEvidence.Require(reader.ReadInt32() == length, "Exact input bank length"); }
        uint[] state = ReadWords(reader, StateWords); uint[] arena = ReadWords(reader, ArenaWords);
        uint[][] inputs = InputLengths.Select(length => ReadWords(reader, length)).ToArray();
        ProofEvidence.Require(reader.BaseStream.Position == reader.BaseStream.Length, "No trailing bank payload");
        return new(state, arena, inputs);
    }

    private static uint[] ReadWords(BinaryReader reader, int count)
    { uint[] result = new uint[count]; for (int index = 0; index < count; index++) { result[index] = reader.ReadUInt32(); } return result; }
}
