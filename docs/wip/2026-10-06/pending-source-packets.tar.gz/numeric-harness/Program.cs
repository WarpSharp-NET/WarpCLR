using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Text.Json;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class Program
{
    private static async Task<int> Main(string[] args)
    {
        if (args.Length != 4 || args[0] is not ("prepare" or "core"))
        {
            throw new ArgumentException("Expected prepare|core, explicit Root inputs, inventory/preparation directory, fresh output directory.", nameof(args));
        }
        RootInputs inputs = JsonSerializer.Deserialize<RootInputs>(File.ReadAllText(args[1]), ProofEvidence.Options)
            ?? throw new InvalidDataException("Explicit actual Root input receipt is absent.");
        inputs.Validate();
        AssemblyLoadContext.Default.Resolving += (_, name) => name.Name is { } key && inputs.Assemblies.TryGetValue(key, out FilePin? pin)
            ? AssemblyLoadContext.Default.LoadFromAssemblyPath(pin.Path) : null;
        foreach (FilePin pin in inputs.Assemblies.Values) { AssemblyLoadContext.Default.LoadFromAssemblyPath(pin.Path); }
        return await ExecuteAsync(args, inputs).ConfigureAwait(false);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static async Task<int> ExecuteAsync(string[] args, RootInputs inputs)
    {
        if (args[0] == "prepare") { Preparation.Run(args[1], args[2], args[3], inputs); }
        else { await CoreTrace.RunAsync(args[1], args[2], args[3], inputs).ConfigureAwait(false); }
        return 0;
    }
}
