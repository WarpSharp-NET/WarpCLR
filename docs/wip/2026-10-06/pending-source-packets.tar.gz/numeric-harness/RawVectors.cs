using System.Globalization;
using System.Reflection;
using System.Text.Json;

namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed record RawVector(string Name, ulong[] Arguments, uint[] PhysicalWords, bool BoundedSourceOracle, bool ExpectedMachineFault);

internal sealed class RawVectors(JsonElement seeds, JsonElement float16Seeds)
{
    internal ulong[] Pool(string name) => seeds.GetProperty("rawPools").GetProperty(name).EnumerateArray()
        .Select(value => ulong.Parse(value.GetString()!, NumberStyles.HexNumber, CultureInfo.InvariantCulture)).ToArray();

    internal RawVector[] Create(CapturedPlan plan)
    {
        if (plan.Spec.Id == "added-DoubleToInt16")
        {
            ProofEvidence.Require(plan.Source.GetParameters().Select(parameter => parameter.ParameterType).SequenceEqual(new[] { typeof(double) }) &&
                plan.Source.ReturnType == typeof(short), "Exact original Double-to-Int16 source signature");
            ulong[] values = ReadHex(float16Seeds.GetProperty("binary64"));
            ProofEvidence.Require(values.Length == 230, "All frozen original floating16 Binary64 seed words");
            return values.Select((bits, index) => new RawVector("float16-" + index.ToString("D3", CultureInfo.InvariantCulture),
                [bits], Physical(plan.Source, [bits]), true, false)).ToArray();
        }
        string recipe = plan.Spec.VectorRecipe;
        var rows = new List<(string Name, ulong[] Arguments, bool Fault)>();
        string poolName = recipe.StartsWith("f32", StringComparison.Ordinal) ? "f32" : recipe.StartsWith("f64", StringComparison.Ordinal) ? "f64" :
            recipe.StartsWith("i64", StringComparison.Ordinal) ? "i64" : recipe == "i8-promote" ? "i8Raw" : "u32";
        ulong[] pool = Pool(poolName); int arity = plan.Source.GetParameters().Length;
        int count = recipe is "u32-loop" or "u32-recursion" ? 16 : pool.Length;
        for (int index = 0; index < count; index++)
        {
            ulong[] arguments = Enumerable.Range(0, arity).Select(argument => pool[(index + (poolName.StartsWith('f') ? 7 : 5) * argument) % pool.Length]).ToArray();
            if (recipe is "u32-loop" or "u32-recursion") { arguments[0] = checked((uint)index); }
            if (recipe.EndsWith("shifts", StringComparison.Ordinal)) { arguments[^1] = Pool("shifts")[index]; }
            if (recipe == "f64-root-pairs") { arguments = [0, pool[index], pool[(index + 7) % pool.Length]]; }
            rows.Add(("pool-" + index.ToString("D2", CultureInfo.InvariantCulture), arguments, false));
        }
        AddEdges(plan, rows);
        return rows.Select(row => new RawVector(row.Name, row.Arguments, Physical(plan.Source, row.Arguments), !row.Fault &&
            plan.Spec.Classification != "reference-root-consistency", row.Fault)).ToArray();
    }

    private void AddEdges(CapturedPlan plan, List<(string Name, ulong[] Arguments, bool Fault)> rows)
    {
        string recipe = plan.Spec.VectorRecipe; string method = plan.Spec.Method;
        if (recipe == "u32-pairs") { rows.AddRange(new[] { ("carry", new ulong[] { 0xFFFFFFFF, 1 }, false),
            ("signed-overflow", new ulong[] { 0x7FFFFFFF, 1 }, false), ("signed-underflow", new ulong[] { 0x80000000, 0xFFFFFFFF }, false) }); }
        if (recipe == "i64-pairs") { rows.Add(("wide-carry", [0x00000001FFFFFFFF, 1], false)); rows.Add(("signed-overflow", [0x7FFFFFFFFFFFFFFF, 1], false)); }
        if (recipe == "i32-conversion") { foreach (ulong value in new ulong[] { 0x00FFFFFF, 0x01000000, 0x01000001, 0x01000003 }) { rows.Add(("integer-rne-" + value.ToString("X8", CultureInfo.InvariantCulture), [value], false)); } }
        if (recipe == "i64-conversion") { rows.Add(("direct-versus-stored-double", [0x8000008000000001], false)); }
        if (recipe is "u32-loop" or "u32-recursion") { rows.Add(("bounded-unbounded-source", [0xFFFFFFFF], true)); }
        if (recipe == "u32-loop") { rows.Add(("bounded-large-source", [0x80000000], true)); }
        string? extra = recipe switch { "f64-narrow" => "f64NarrowExtra", "f32-integer-conversion" => "f32IntegerConversionExtra", "f64-integer-conversion" => "f64IntegerConversionExtra", _ => null };
        if (extra is not null) { foreach (ulong value in Pool(extra)) { rows.Add(("extra-" + value.ToString("X16", CultureInfo.InvariantCulture), [value], false)); } }
        if (recipe.EndsWith("fma-witness", StringComparison.Ordinal)) { AddFma(method.EndsWith("32", StringComparison.Ordinal) ? 32 : 64, rows); }
        if (method is "Local32" or "Local64") { rows.Add(("local-width-rounding", ReadHex(seeds.GetProperty("specialWitnesses").GetProperty(method + "Extra").GetProperty("inputs")), false)); }
        if (recipe is "f32-pairs" or "f64-pairs") { AddFloatPairs(recipe.StartsWith("f32", StringComparison.Ordinal) ? 32 : 64, rows); }
    }

    private void AddFma(int width, List<(string Name, ulong[] Arguments, bool Fault)> rows)
    {
        JsonElement special = seeds.GetProperty("specialWitnesses");
        rows.Add(("noncontraction", ReadHex(special.GetProperty("noncontraction" + width).GetProperty("inputs")), false));
        int index = 0;
        foreach (JsonElement value in special.GetProperty("Fma" + width + "Additional").EnumerateArray())
        { rows.Add(("fma-edge-" + (index++).ToString(CultureInfo.InvariantCulture), ReadHex(value), false)); }
    }

    private static void AddFloatPairs(int width, List<(string Name, ulong[] Arguments, bool Fault)> rows)
    {
        ulong sign = width == 32 ? 0x80000000 : 0x8000000000000000;
        ulong one = width == 32 ? 0x3F800000 : 0x3FF0000000000000;
        ulong snan = width == 32 ? 0x7F800001 : 0x7FF0000000000001;
        ulong qnan = width == 32 ? 0xFFC54321 : 0xFFFABCDEF0123456;
        ulong infinity = width == 32 ? 0x7F800000 : 0x7FF0000000000000;
        ulong two = width == 32 ? 0x40000000 : 0x4000000000000000;
        ulong three = width == 32 ? 0x40400000 : 0x4008000000000000;
        ulong five = width == 32 ? 0x40A00000 : 0x4014000000000000;
        ulong normal = width == 32 ? 0x00800000 : 0x0010000000000000;
        ulong[][] pairs = [[0, sign], [sign, 0], [snan, one], [one, snan], [qnan, one], [one, qnan],
            [infinity, infinity | sign], [three, two], [five, two], [three | sign, two], [1, normal], [one, 0], [infinity, one]];
        for (int index = 0; index < pairs.Length; index++) { rows.Add(("float-pair-" + index.ToString(CultureInfo.InvariantCulture), pairs[index], false)); }
    }

    private uint[] Physical(MethodInfo source, ulong[] arguments)
    {
        var result = new List<uint>(); ParameterInfo[] parameters = source.GetParameters();
        for (int index = 0; index < parameters.Length; index++)
        {
            Type type = parameters[index].ParameterType;
            if (type == typeof(object)) { result.AddRange(Pool("rootTriple").Select(value => checked((uint)value))); continue; }
            ulong value = arguments[index]; result.Add(unchecked((uint)value));
            if (type == typeof(double) || type == typeof(long) || type == typeof(ulong)) { result.Add((uint)(value >> 32)); }
        }
        return [.. result];
    }

    private static ulong[] ReadHex(JsonElement array) => array.EnumerateArray().Select(value => ulong.Parse(value.GetString()!, NumberStyles.HexNumber, CultureInfo.InvariantCulture)).ToArray();
}
