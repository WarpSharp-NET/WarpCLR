"""Finite source-only packet helpers. Import/execute only in Root's future run."""
import hashlib
import importlib.util
import json
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
ORIGINAL = pathlib.Path('/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/current-numeric-source-proof-packet')
FORMAT = "warp.proof.current-numeric/0.1"
DIALECTS = ("NVPTX", "AMDGPU", "SPIRV")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with pathlib.Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(pathlib.Path(path).read_text())


def pin(row):
    path = pathlib.Path(row["path"])
    require(path.is_absolute() and re.fullmatch(r"[a-fA-F0-9]{64}", row["sha256"]), "Explicit absolute SHA pin required")
    require(sha(path) == row["sha256"].lower(), "Exact bytes differ: " + str(path))
    return path


def receipt(path):
    return {"path": str(pathlib.Path(path).resolve()), "sha256": sha(path)}


def write_new(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def v4_module(name):
    provenance = read(ORIGINAL / "provenance.json")
    row = provenance["explicitV4FunctionAdapters"][name]
    path = pin(row)
    if name == "retarget_cpu":
        v4_module("bank_format")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def validate_prepared(path, root_inputs):
    prepared = read(path)
    require(prepared["format"] == "warp.proof.current-numeric/prepared-captured-source/0.2" and
            len(prepared["cases"]) == 77 and len(prepared["deniedProductionBlockers"]) == 13 and
            not prepared["sourceAuthority"] and not prepared["privateRpc"], "Exact original90 inventory: 74+one existing candidates, two explicit attempts, thirteen retained denials")
    require(sha(pin(prepared["rootInputs"])) == sha(root_inputs), "Actual Root input join differs")
    root = read(root_inputs)
    require(root["format"] == "warp.proof.current-numeric/actual-root-inputs/0.1", "Actual current input schema")
    for row in [root["actualSourceReceipt"], root["actualArtifactReceipt"], root["actualRuntimeReceipt"], root["actualSdkReceipt"],
                root["sourceFixtureTests"], root["dotnetHost"], root["workerAssembly"], *root["assemblies"].values()]:
        pin(row)
    require(root["ordinaryCodecMagic"] == 0x57425036 and root["ordinaryMetadataVersion"] == "warp.logical-source-frames/0.6",
            "Ordinary conditional profile; sealed v4 private0.10/WBP8 is not this adapter")
    inventory = read(pin(prepared["inventory"]))
    require(inventory["attemptFormat"] == "warp.proof.current-numeric/exact-original-candidate-attempts/0.1" and
            inventory["candidateAttempts"] == ["original19-ExternalCall", "added-DoubleToInt16"], "Exact finite attempted-denial identities")
    original_inventory = pin(inventory["originalInventory"])
    require(sha(original_inventory) == "37e4301e6885b2a66d16393f9e2c62530c7a4c042adda120fe6cadff4d72672f", "Exact immutable original90 inventory")
    original_rows = read(original_inventory)
    require(all(inventory[key] == value for key, value in original_rows.items()), "Every original identity/signature/recipe/classification/gap unchanged")
    pin(inventory["candidateFloat16Seeds"])
    attempts = inventory["candidateAttempts"]
    candidate_rows = inventory["numeric"] + inventory["referenceConsistency"] + [row for row in inventory["denials"] if row["id"] in attempts]
    denied = [row["id"] for row in inventory["denials"] if row["id"] not in attempts]
    require(prepared["deniedProductionBlockers"] == denied and prepared["attemptedOriginalDenials"] == attempts,
            "Actual complete capture is required before the two original denied rows can enter the proof set")
    expected = {row["id"] for row in candidate_rows}
    require({row["name"] for row in prepared["cases"]} == expected and len(expected) == 77, "No candidate skipped or relabeled")
    for row in prepared["cases"]:
        program, _ = validate_case(row)
        require(program["spec"] == next(value for value in candidate_rows if value["id"] == row["name"]),
                "Exact unchanged original case specification, including its historical classification")
    return prepared, root


def validate_case(row):
    program = read(pin(row["program"]))
    emitted = read(pin(row["emission"]))
    plan = pin(row["plan"])
    require(program["name"] == row["name"] and program["irHash"] == row["irHash"] == emitted["irHash"], "Same source/common IR join")
    require(program["metadataVersion"] == "warp.logical-source-frames/0.6" and program["scalarCount"] == 0 and
            not program["rootAuthority"] and not program["privateRpc"], "Ordinary numeric profile/capability join")
    require(plan.read_bytes()[:4] == (0x57425036).to_bytes(4, "little") and sha(plan) == emitted["planSha256"], "Exact ordinary codec bytes")
    require({x["dialect"] for x in emitted["dialects"]} == set(DIALECTS) and len(emitted["dialects"]) == 3, "All three actual source emissions")
    for source in emitted["dialects"]:
        pin(source)
        require((source["irHash"], source["graphHash"], source["typedHash"], source["entryPoint"]) ==
                (program["irHash"], program["graphHash"], program["typedHash"], "warp_resume"), "Exact source/type/IR/kernel entry join")
    for seed in row["vectors"]:
        pin(seed["initial"])
        pin(seed["oracleReceipt"])
    return program, emitted
