using System.Reflection;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class OriginalClrOracle
{
    // This is an explicitly separate pure, bounded original CLR TEST oracle.
    // It is never used by the compiler, worker, generated kernel or backend.
    internal static object Check(CapturedPlan plan, RawVector vector, uint[] independent)
    {
        if (!vector.BoundedSourceOracle) { return new { Invoked = false, Reason = "Opaque synthetic reference or bounded machine fault; no unbounded/fake-reference original invocation" }; }
        ParameterInfo[] parameters = plan.Source.GetParameters();
        object?[] arguments = parameters.Select((parameter, index) => Argument(parameter.ParameterType, vector.Arguments[index])).ToArray();
        object? result;
        try { result = plan.Source.Invoke(null, arguments); }
        catch (TargetInvocationException error) { throw new InvalidDataException("Original pure CLR oracle failed; retain exact original CIL/arguments, no rewritten bits or fallback", error.InnerException ?? error); }
        uint[] rawWords = Result(plan, result!);
        uint[] words = ApplyExplicitPortableNaNContract(plan, rawWords);
        ProofEvidence.Equal(independent, words, "Independent bit/BigInteger oracle differs from the original CLR result under the explicit portable NaN contract; this is a blocker");
        return new { Invoked = true, PureBoundedTestOracleOnly = true, OriginalCilSha256 = ProofEvidence.Hash(plan.Source.GetMethodBody()!.GetILAsByteArray()!),
            RawArguments = vector.Arguments, ReturnedWords = rawWords, PortableContractWords = words,
            PortableNaNContract = "existing-versioned-canonical-arithmetic-and-numerical-conversion-nan; raw-transport-exact",
            NormalizationApplied = !rawWords.SequenceEqual(words), RawOriginalClrEqualsIndependent = rawWords.SequenceEqual(independent),
            IndependentWords = independent, Runtime = Environment.Version.ToString(),
            Architecture = System.Runtime.InteropServices.RuntimeInformation.ProcessArchitecture.ToString(), GeneratedExpectedSide = false };
    }

    private static uint[] ApplyExplicitPortableNaNContract(CapturedPlan plan, uint[] rawWords)
    {
        Type type = plan.Source.ReturnType;
        if (type != typeof(float) && type != typeof(double) || plan.Spec.Method is "Transport32" or "Transport64")
        { return rawWords; }
        int width = type == typeof(float) ? 32 : 64;
        var format = new FloatFormat(width);
        ulong raw = rawWords[0];
        if (width == 64) { raw |= (ulong)rawWords[1] << 32; }
        if (!format.IsNaN(raw)) { return rawWords; }
        // This finite list binds only the original captured arithmetic/conversion
        // cases whose existing product semantics explicitly prescribe canonical NaNs.
        // Unknown source methods cannot acquire that policy from a name prefix.
        ProofEvidence.Require(plan.Spec.Method is "FloatingPoint" or "Pipeline32" or "Pipeline64" or "Narrow" or "Constant" or
            "Round32" or "Round64" or "Local32" or "Local64" or "Negate32" or "Negate64" or "Widen32To64" or
            "Remainder32" or "Remainder64" or "Minimum32" or "Minimum64" or "Maximum32" or "Maximum64" or
            "Sqrt32" or "Sqrt64" or "Fma32" or "Fma64", "No implicit NaN normalization policy for an unlisted original CLR source");
        return NumericOracle.Words(format.NaN, width);
    }

    private static object Argument(Type type, ulong value)
    {
        // Separate returns prevent conditional-expression numeric promotion
        // from boxing an Int32/Single argument as a different source type.
        if (type == typeof(uint)) { return unchecked((uint)value); }
        if (type == typeof(int)) { return unchecked((int)value); }
        if (type == typeof(ulong)) { return value; }
        if (type == typeof(long)) { return unchecked((long)value); }
        if (type == typeof(sbyte)) { return unchecked((sbyte)value); }
        if (type == typeof(float)) { return BitConverter.UInt32BitsToSingle(unchecked((uint)value)); }
        if (type == typeof(double)) { return BitConverter.UInt64BitsToDouble(value); }
        throw new InvalidDataException("No original oracle argument type");
    }

    private static uint[] Result(CapturedPlan plan, object result)
    {
        Type type = plan.Source.ReturnType;
        if (type == typeof(float) || type == typeof(double))
        {
            int width = type == typeof(float) ? 32 : 64;
            ulong raw = width == 32 ? BitConverter.SingleToUInt32Bits((float)result) : BitConverter.DoubleToUInt64Bits((double)result);
            return NumericOracle.Words(raw, width);
        }
        if (type == typeof(bool)) { return [(bool)result ? 1u : 0]; }
        if (type == typeof(uint)) { return [(uint)result]; }
        if (type == typeof(int)) { return [unchecked((uint)(int)result)]; }
        if (type == typeof(short)) { return [unchecked((ushort)(short)result)]; }
        if (type == typeof(ushort)) { return [(ushort)result]; }
        if (type == typeof(long)) { return NumericOracle.Words(unchecked((ulong)(long)result), 64); }
        if (type == typeof(ulong)) { return NumericOracle.Words((ulong)result, 64); }
        throw new InvalidDataException("No exact original oracle result type");
    }
}
