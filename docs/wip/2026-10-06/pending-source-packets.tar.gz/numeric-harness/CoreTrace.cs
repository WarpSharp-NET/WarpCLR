using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class CoreTrace
{
    internal static async Task RunAsync(string inputPath, string preparation, string output, RootInputs inputs)
    {
        string directory = ProofEvidence.Fresh(output);
        PreparedSet set = ProofEvidence.Read<PreparedSet>(Path.Combine(preparation, "prepared.json"));
        set.RootInputs.Validate(); set.Inventory.Validate(); set.Seeds.Validate(); set.StorageCensus.Validate();
        ProofEvidence.Require(set.Format == "warp.proof.current-numeric/prepared-captured-source/0.2" && set.Cases.Length == 77 &&
            set.DeniedProductionBlockers.Length == 13 &&
            set.AttemptedOriginalDenials.SequenceEqual(new[] { "original19-ExternalCall", "added-DoubleToInt16" }, StringComparer.Ordinal) && !set.SourceAuthority && !set.PrivateRpc &&
            set.RootInputs.Sha256 == ProofEvidence.HashFile(inputPath), "Exact complete captured set and current actual Root inputs");
        CaseInventory inventory = ProofEvidence.Read<CaseInventory>(set.Inventory.Path);
        inventory.Validate(inputs);
        ProofEvidence.Require(set.Cases.Select(row => row.Name).Order(StringComparer.Ordinal).SequenceEqual(
            inventory.ProofCases.Select(row => row.Id).Order(StringComparer.Ordinal), StringComparer.Ordinal) &&
            set.DeniedProductionBlockers.SequenceEqual(inventory.RemainingDenials.Select(row => row.Id), StringComparer.Ordinal),
            "Every original90 row is either an actual captured candidate or an exact retained denial");
        ProofEvidence.Write(Path.Combine(directory, "input-identity.json"), new { Input = ProofEvidence.Pin(inputPath), Preparation = ProofEvidence.Pin(Path.Combine(preparation, "prepared.json")),
            GeneratedExecution = "Exact admitted ordinary authenticated child; no parent JIT or captured source delegate", RootAuthority = false });
        var completed = new List<object>();
        try
        {
            foreach (PreparedCase row in set.Cases) { completed.Add(await RunCaseAsync(row, directory, inputs).ConfigureAwait(false)); }
            inputs.VerifyLoadedAssemblies();
            ProofEvidence.Write(Path.Combine(directory, "core-result.json"), new { Format = "warp.proof.current-numeric/core-expected-side/0.1",
                Status = "GENERATED_CORE_BANKS_COMPLETE_NATIVE_COMPARISONS_PENDING", Cases = completed, NumericCandidates = 76, AttemptedOriginalDenials = set.AttemptedOriginalDenials, ReferenceConsistencyLayouts = 1,
                DeniedProductionBlockers = set.DeniedProductionBlockers, FirstContainmentRequired = true, HostPid = Environment.ProcessId,
                RootAuthority = false, PrivateRpc = false, Gpu = false, Readiness = false });
        }
        catch (Exception error)
        { ProofEvidence.Write(Path.Combine(directory, "core-failure.json"), new { Error = error.ToString(), Completed = completed, OverallPass = false }); throw; }
    }

    private static async Task<object> RunCaseAsync(PreparedCase prepared, string output, RootInputs inputs)
    {
        prepared.Program.Validate(); prepared.Plan.Validate(); prepared.Emission.Validate();
        byte[] bytes = File.ReadAllBytes(prepared.Plan.Path);
        var layout = new WarpLogicalMachineLayout(WarpCoreCLRBinaryPlanCodec.Deserialize(bytes, prepared.IrHash));
        CapturedPlan.RequireOrdinary(layout, inputs);
        ProofEvidence.Require(WarpIrHash.Compute(layout.Kernel) == prepared.IrHash && layout.GetStateWords(inputs.MaximumLogicalDepth) == prepared.StateWords &&
            layout.GetPhysicalFrameCapacity(inputs.MaximumLogicalDepth) == prepared.FrameCapacity, "Exact layout/common plan, no reconstruction fallback");
        string directory = Path.Combine(output, prepared.Name); Directory.CreateDirectory(directory);
        var options = new WarpCoreCLRWorkerOptions { DotnetHostPath = inputs.DotnetHost.Path, WorkerAssemblyPath = inputs.WorkerAssembly.Path,
            MaximumWorkerProcesses = 1, CompilationTimeout = TimeSpan.FromSeconds(120), QuantumTimeout = TimeSpan.FromSeconds(30), CleanupTimeout = TimeSpan.FromSeconds(2) };
        WarpCoreCLRWorkerProcess worker = await WarpCoreCLRWorkerProcess.CompileAsync(bytes, prepared.IrHash, options, CancellationToken.None).ConfigureAwait(false);
        var writer = new CoreTraceWriter(prepared, layout, worker, inputs, directory);
        try
        {
            ProofEvidence.Write(Path.Combine(directory, "compiled-child.json"), new { worker.ProcessId, worker.CompiledModule, worker.IsCollectible,
                worker.IrHash, inputs.WorkerAssembly, inputs.DotnetHost, Plan = prepared.Plan, ParentJit = false,
                Envelope = "Existing ordinary worker/0.3 only; exact protocol/capability identity must join the actual Runtime receipt", inputs.ActualRuntimeReceipt });
            foreach (PreparedVector vector in prepared.Vectors) { await writer.RunVectorAsync(vector).ConfigureAwait(false); }
        }
        catch (Exception error)
        { ProofEvidence.Write(Path.Combine(directory, "case-failure.json"), new { Error = error.ToString(), worker.ProcessId, worker.CompiledModule, CompletedSteps = writer.Count }); throw; }
        finally { await ChildStop.CompleteAsync(worker, Path.Combine(directory, "child-stop.json")).ConfigureAwait(false); }
        writer.Complete();
        return new { prepared.Name, Rows = writer.Count, prepared.IrHash, prepared.Quanta, InitialSeeds = prepared.Vectors.Select(vector => vector.Initial),
            Stop = ProofEvidence.Pin(Path.Combine(directory, "child-stop.json")), Traces = ProofEvidence.Pin(Path.Combine(directory, "vectors.json")),
            Program = prepared.Program, Plan = prepared.Plan, Emission = prepared.Emission, RootAuthority = false };
    }
}
