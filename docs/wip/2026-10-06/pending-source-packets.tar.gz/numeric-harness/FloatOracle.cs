using System.Numerics;

namespace WarpCLR.Tests.CurrentNumericProof;

internal static class FloatOracle
{
    internal static ulong Add(FloatFormat f, ulong left, ulong right)
    {
        if (f.IsNaN(left) || f.IsNaN(right)) { return f.NaN; }
        if (f.IsInfinite(left) || f.IsInfinite(right))
        { return f.IsInfinite(left) && f.IsInfinite(right) && f.Negative(left) != f.Negative(right) ? f.NaN : f.IsInfinite(left) ? left : right; }
        (BigInteger a, int ea) = f.Decode(left); (BigInteger b, int eb) = f.Decode(right); int exponent = Math.Min(ea, eb);
        return f.Round((a << (ea - exponent)) + (b << (eb - exponent)), BigInteger.One, exponent,
            f.IsZero(left) && f.IsZero(right) && f.Negative(left) && f.Negative(right));
    }

    internal static ulong Multiply(FloatFormat f, ulong left, ulong right)
    {
        if (f.IsNaN(left) || f.IsNaN(right)) { return f.NaN; }
        bool negative = f.Negative(left) != f.Negative(right);
        if (f.IsInfinite(left) || f.IsInfinite(right)) { return f.IsZero(left) || f.IsZero(right) ? f.NaN : f.Infinity | (negative ? f.Sign : 0); }
        (BigInteger a, int ea) = f.Decode(left); (BigInteger b, int eb) = f.Decode(right);
        return f.Round(a * b, BigInteger.One, ea + eb, negative);
    }

    internal static ulong Divide(FloatFormat f, ulong left, ulong right)
    {
        bool negative = f.Negative(left) != f.Negative(right); ulong sign = negative ? f.Sign : 0;
        if (f.IsNaN(left) || f.IsNaN(right) || f.IsInfinite(left) && f.IsInfinite(right) || f.IsZero(left) && f.IsZero(right)) { return f.NaN; }
        if (f.IsInfinite(left) || f.IsZero(right)) { return f.Infinity | sign; }
        if (f.IsInfinite(right) || f.IsZero(left)) { return sign; }
        (BigInteger a, int ea) = f.Decode(left); (BigInteger b, int eb) = f.Decode(right);
        BigInteger numerator = BigInteger.Abs(a) * (negative ? -1 : 1);
        return f.Round(numerator, BigInteger.Abs(b), ea - eb, negative);
    }

    internal static int Compare(FloatFormat f, ulong left, ulong right)
    {
        ProofEvidence.Require(!f.IsNaN(left) && !f.IsNaN(right), "Unordered handled before comparison");
        if (f.IsZero(left) && f.IsZero(right)) { return 0; }
        if (left == right) { return 0; }
        if (f.Negative(left) != f.Negative(right)) { return f.Negative(left) ? -1 : 1; }
        int order = (left & ~f.Sign).CompareTo(right & ~f.Sign); return f.Negative(left) ? -order : order;
    }

    internal static ulong MinMax(FloatFormat f, ulong left, ulong right, bool maximum)
    {
        if (f.IsNaN(left) || f.IsNaN(right)) { return f.NaN; }
        if (f.IsZero(left) && f.IsZero(right)) { return maximum ? left & right : left | right; }
        int order = Compare(f, left, right); return maximum ? order >= 0 ? left : right : order <= 0 ? left : right;
    }

    internal static BigInteger ToInteger(FloatFormat f, ulong value, int width, bool signed)
    {
        BigInteger minimum = signed ? -(BigInteger.One << (width - 1)) : BigInteger.Zero;
        BigInteger maximum = (BigInteger.One << (signed ? width - 1 : width)) - 1;
        if (f.IsNaN(value)) { return BigInteger.Zero; }
        if (f.IsInfinite(value)) { return f.Negative(value) ? minimum : maximum; }
        (BigInteger significand, int exponent) = f.Decode(value);
        BigInteger magnitude = exponent >= 0 ? BigInteger.Abs(significand) << exponent : BigInteger.Abs(significand) >> -exponent;
        BigInteger truncated = significand.Sign < 0 ? -magnitude : magnitude;
        return BigInteger.Clamp(truncated, minimum, maximum);
    }
}
