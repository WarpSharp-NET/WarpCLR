namespace WarpCLR.Tests.CurrentNumericProof;

internal sealed record CaseSpec(string Id, string Type, string Method, string DeclaredSignature, string VectorRecipe,
    string FixtureRole, string? FixtureLogicalPath, string? SourceSha256, string Classification, string Oracle, string? Gap);

internal sealed record CaseInventory(string Format, FilePin CoverageMatrix, FilePin SeedInventory, CaseSpec[] Numeric,
    CaseSpec[] ReferenceConsistency, CaseSpec[] Denials)
{
    public string? AttemptFormat { get; init; }
    public FilePin? OriginalInventory { get; init; }
    public string[] CandidateAttempts { get; init; } = [];
    public FilePin? CandidateFloat16Seeds { get; init; }

    internal bool IsCandidateAttempt(CaseSpec row) => CandidateAttempts.Contains(row.Id, StringComparer.Ordinal);
    internal IEnumerable<CaseSpec> ProofCases => Numeric.Concat(ReferenceConsistency).Concat(Denials.Where(IsCandidateAttempt));
    internal IEnumerable<CaseSpec> RemainingDenials => Denials.Where(row => !IsCandidateAttempt(row));

    internal void Validate(RootInputs inputs)
    {
        ProofEvidence.Require(Format == "warp.proof.current-numeric/finite-capture-inventory/0.1" && Numeric.Length == 74 &&
            ReferenceConsistency.Length == 1 && Denials.Length == 15, "74 numeric + one separate root + all 15 blockers");
        ProofEvidence.Require(AttemptFormat == "warp.proof.current-numeric/exact-original-candidate-attempts/0.1" &&
            CandidateAttempts.SequenceEqual(new[] { "original19-ExternalCall", "added-DoubleToInt16" }, StringComparer.Ordinal),
            "Only the two exact explicit source candidates may be attempted; no accepted support is implied");
        FilePin originalPin = OriginalInventory ?? throw new InvalidDataException("Exact original inventory required");
        originalPin.Validate();
        ProofEvidence.Require(originalPin.Sha256 == "37e4301e6885b2a66d16393f9e2c62530c7a4c042adda120fe6cadff4d72672f", "Immutable original90 inventory");
        CaseInventory original = ProofEvidence.Read<CaseInventory>(originalPin.Path);
        ProofEvidence.Require(Format == original.Format && CoverageMatrix == original.CoverageMatrix && SeedInventory == original.SeedInventory &&
            Numeric.SequenceEqual(original.Numeric) && ReferenceConsistency.SequenceEqual(original.ReferenceConsistency) &&
            Denials.SequenceEqual(original.Denials), "Every original identity, signature, recipe, classification and gap stays unchanged");
        FilePin floatSeeds = CandidateFloat16Seeds ?? throw new InvalidDataException("Exact floating16 seed pin required");
        floatSeeds.Validate();
        CoverageMatrix.Validate(); SeedInventory.Validate();
        ProofEvidence.Require(Numeric.Concat(ReferenceConsistency).Concat(Denials).Select(row => row.Id).Distinct(StringComparer.Ordinal).Count() == 90,
            "No duplicate, omitted or relabeled case");
        foreach (CaseSpec row in Numeric.Concat(ReferenceConsistency).Concat(Denials))
        {
            if (row.FixtureLogicalPath is { } logical)
            {
                ProofEvidence.Require(inputs.FixtureSources.TryGetValue(logical, out FilePin? pin) &&
                    (row.SourceSha256 is null || row.SourceSha256.Equals(pin.Sha256, StringComparison.OrdinalIgnoreCase)), "Exact source fixture pin: " + row.Id);
            }
        }
    }
}
