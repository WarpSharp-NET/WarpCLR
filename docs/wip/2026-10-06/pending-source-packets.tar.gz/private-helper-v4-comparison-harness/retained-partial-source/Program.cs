using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

namespace WarpCLR.Tests.V4Proof;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length != 3) { throw new ArgumentException("Expected exact-reference config, seed inventory, fresh output directory.", nameof(args)); }
        var references = JsonSerializer.Deserialize<Dictionary<string, ReferenceInput>>(File.ReadAllText(args[0]), Evidence.Options)
            ?? throw new InvalidDataException("The exact reference inventory is absent.");
        foreach ((string name, ReferenceInput input) in references)
        {
            Evidence.Require(string.Equals(Path.GetFileNameWithoutExtension(input.Path), name, StringComparison.Ordinal), "Reference assembly name");
            Evidence.Require(string.Equals(Evidence.Hash(File.ReadAllBytes(input.Path)), input.Sha256, StringComparison.OrdinalIgnoreCase), "Reference bytes");
        }
        AssemblyLoadContext.Default.Resolving += (_, name) => name.Name is { } key && references.TryGetValue(key, out ReferenceInput? row) ?
            AssemblyLoadContext.Default.LoadFromAssemblyPath(row.Path) : null;
        ProofPreparation.Run(args[1], args[2], references);
        return 0;
    }
}

internal sealed record ReferenceInput(string Path, string Sha256);
