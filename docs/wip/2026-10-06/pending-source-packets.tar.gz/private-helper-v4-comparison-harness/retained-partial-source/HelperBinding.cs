using System.Reflection.Emit;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.V4Proof;

internal sealed class HelperBinding : WarpPortableWordExecutionBinding
{
    private const string Service = "warp.proof.v4/captured-source-private-raw-tuple/0.1";
    private readonly int payloadWords, resultWords;
    private readonly bool nested;
    private int helper, leaf;

    internal HelperBinding(WarpPortableMethodGraph graph, WarpPortableTypedProgram typed, WarpPortableSourceHeapSchema schema,
        int payloadWords, int resultWords, bool nested, bool fenced = true, bool boundaries = true)
        : base(graph.GraphHash, typed.VerifiedHash, schema.SchemaHash, Service, graph.GraphHash,
            new(FrameOwners: true, RuntimeStateAccess: true, PrivateController: true,
                PrivateHelperBoundaries: boundaries, PrivateHelperReturnFences: fenced))
    { this.payloadWords = payloadWords; this.resultWords = resultWords; this.nested = nested; }

    internal override void Prepare(WarpPortableWordBindingPreparation context)
    {
        helper = context.ReserveFunction(Service);
        if (nested) { leaf = context.ReserveFunction(Service + "/leaf"); }
        context.InstallFunction(CreateService(helper, nested), new(0, true, [0], countsSourceDepth: false));
        if (nested) { context.InstallFunction(CreateService(leaf, callLeaf: false), new(0, true, [0], countsSourceDepth: false)); }
    }

    private WarpControlFlowFunction CreateService(int function, bool callLeaf)
    {
        var instructions = new List<WarpIrInstruction>();
        for (int index = 0; index <= payloadWords; index++) { instructions.Add(new(index, WarpIrOpCode.LoadArgument, immediate: (uint)index)); }
        // A finite operational-cost block guarantees genuine outer/nested scope
        // checkpoints at small quantum, without changing source charge or data.
        for (int index = 32; index < 160; index++) { instructions.Add(new(index, WarpIrOpCode.Constant, immediate: unchecked((uint)index * 0x9E3779B9))); }
        int[] returned;
        if (callLeaf)
        {
            instructions.Add(new(160, leaf, Enumerable.Range(0, payloadWords + 1), resultWords));
            returned = Enumerable.Range(160, resultWords).ToArray();
        }
        else
        {
            instructions.Add(new(160, WarpIrOpCode.Constant)); instructions.Add(new(161, WarpManagedMemoryOpCode.StoreWord, 160, 0));
            instructions.Add(new(162, WarpIrOpCode.Constant, immediate: 0x7FC12345));
            instructions.Add(new(163, WarpIrOpCode.Constant, immediate: 0x80000000));
            instructions.Add(new(164, WarpIrOpCode.Constant, immediate: uint.MaxValue));
            returned = resultWords == 4 ? [1, 162, 163, 164] : Enumerable.Range(1, resultWords).ToArray();
        }
        return new(function, function == helper ? Service : Service + "/leaf", payloadWords + 1,
            [new(0, [], instructions, new WarpTupleReturnTerminator(returned))]);
    }

    internal override WarpBlockTerminator? LowerInstruction(WarpPortableWordInstructionContext context)
    {
        if (context.SourceInstruction.OpCode != OpCodes.Ret) { return null; }
        int bridge = context.EmitPrivateHelperBridge((stage, controller) =>
        {
            int[] payload = payloadWords == 0 ? [] : stage.LoadStackValue(0).ToArray();
            Evidence.Require(payload.Length == payloadWords, "Exact original source result width");
            int[] result = stage.Call(helper, payload.Prepend(controller).ToArray()).ToArray();
            return new WarpTupleReturnTerminator(result.Take(payloadWords));
        });
        return new WarpBranchTerminator(new(bridge, []));
    }

    internal override string Complete(WarpPortableWordBindingCompletion context) => WarpIrHash.Compute(context.StructuralKernel);
}
