using System.Security.Cryptography;
using System.Text.Json;

namespace WarpCLR.Tests.V4Proof;

internal static class Evidence
{
    internal static JsonSerializerOptions Options { get; } = new(JsonSerializerDefaults.Web) { WriteIndented = true };
    internal static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes));
    internal static void Require(bool condition, string label)
    { if (!condition) { throw new InvalidOperationException("Whole-bank proof oracle failed: " + label); } }
    internal static void Equal(uint[] first, uint[] second, string label) => Require(first.AsSpan().SequenceEqual(second), label);
    internal static void Write(string path, object value) => File.WriteAllText(path, JsonSerializer.Serialize(value, Options) + "\n");

    internal static object Bank(string path, uint[] state, uint[] arena, uint[][] inputs)
    {
        using (FileStream stream = File.Create(path))
        {
            using var writer = new BinaryWriter(stream);
            writer.Write(0x34504257u); writer.Write(state.Length); writer.Write(arena.Length); writer.Write(inputs.Length);
            foreach (uint[] input in inputs) { writer.Write(input.Length); }
            foreach (uint[] words in new[] { state, arena }.Concat(inputs))
            { foreach (uint word in words) { writer.Write(word); } }
        }
        return new { Path = path, Sha256 = Hash(File.ReadAllBytes(path)), StateWords = state.Length, ArenaWords = arena.Length,
            InputLengths = inputs.Select(input => input.Length).ToArray(), Format = "LE WBP4:u32 magic/state/arena/input-count,u32 input-lengths,raw State/Arena/input banks" };
    }
}
