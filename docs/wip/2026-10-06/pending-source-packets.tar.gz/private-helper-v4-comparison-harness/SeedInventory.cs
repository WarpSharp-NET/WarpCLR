using System.Text.Json;
using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal sealed record SeedInventory(string Status, string Version, uint[] RawWords, uint ControllerWord,
    int MaximumLogicalDepth, int MaximumSourceSteps)
{
    internal static SeedInventory Read(string path)
    {
        SeedInventory seed = JsonSerializer.Deserialize<SeedInventory>(File.ReadAllText(path), Evidence.Options)
            ?? throw new InvalidDataException("Shared seed inventory is absent.");
        Evidence.Require(string.Equals(seed.Version, "warp.proof.private-helper-v4/shared-raw-u32-seeds/0.1",
            StringComparison.Ordinal), "Seed schema");
        Evidence.Require(seed.RawWords.Length == 8 && seed.ControllerWord != 0 && seed.MaximumLogicalDepth == 8 &&
            seed.MaximumSourceSteps == 1024, "Finite shared raw-word inventory");
        return seed;
    }

    internal uint[] Arena(int seed) => Enumerable.Range(0, RawWords.Length)
        .Select(index => RawWords[(seed + index) % RawWords.Length]).ToArray();

    internal uint[][] Inputs(ProofProgram program, int seed) => Enumerable.Range(0, program.Layout.Kernel.InputBufferCount)
        .Select(index => new[] { RawWords[(seed + index) % RawWords.Length] }).ToArray();

    internal uint[] Initial(ProofProgram program)
    {
        // Exactly one namespace allocation per program, before any dialect loop.
        uint[] state = program.Layout.CreateInitialState(MaximumLogicalDepth, MaximumSourceSteps);
        program.Layout.SetSourceBoundaryMode(state, true);
        return state;
    }

    internal int[] Quanta(ProofProgram program)
    {
        Evidence.Require(program.Layout.MaximumBlockCost < 4096, "Distinct small and large operational quanta");
        return [program.Layout.MaximumBlockCost, 4096];
    }
}
