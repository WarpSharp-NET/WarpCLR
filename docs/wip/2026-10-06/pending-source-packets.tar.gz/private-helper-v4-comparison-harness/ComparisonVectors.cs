using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal sealed record ProofBanks(uint[] State, uint[] Arena, uint[][] Inputs)
{
    internal ProofBanks Copy() => new((uint[])State.Clone(), (uint[])Arena.Clone(),
        Inputs.Select(input => (uint[])input.Clone()).ToArray());
}

internal sealed class ComparisonVectors(ProofProgram program, SeedInventory seeds, string directory)
{
    private readonly List<object> rows = [];
    internal int Count => rows.Count;

    internal void Step(string name, ProofBanks banks, uint controller, int quantum, int seed, bool unchanged = false)
    {
        ProofBanks before = banks.Copy();
        string prefix = Prefix();
        object pre = Evidence.Bank(prefix + ".pre.bank", before.State, before.Arena, before.Inputs);
        Exception? failure = null;
        try { program.Invoke(banks.State, banks.Arena, banks.Inputs, controller, quantum, seeds.MaximumLogicalDepth); }
        catch (Exception error) { failure = error; }
        object post = Evidence.Bank(prefix + ".post.bank", banks.State, banks.Arena, banks.Inputs);
        Add(new { Name = name, Seed = seed, Quantum = quantum, Scalar = controller, Pre = pre, Post = post,
            IrHash = WarpIrHash.Compute(program.Layout.Kernel), NativeComparable = true, ExpectUnchanged = unchanged,
            ConsistencyAcknowledgment = false, RootAuthority = false, InvocationFailure = failure?.ToString() });
        if (failure is not null) { throw new InvalidOperationException("Generated Core invocation failed; exact pre/post banks retained.", failure); }
        foreach (int index in Enumerable.Range(0, before.Inputs.Length))
        { Evidence.Equal(before.Inputs[index], banks.Inputs[index], "Read-only physical input bank"); }
        if (unchanged)
        {
            Evidence.Equal(before.State, banks.State, "Fail-closed or parked complete State");
            Evidence.Equal(before.Arena, banks.Arena, "Fail-closed or parked complete Arena");
        }
    }

    internal void Acknowledge(string name, ProofBanks banks, int seed, int quantum, Action<uint[]> acknowledge)
    {
        ProofBanks before = banks.Copy(); string prefix = Prefix();
        object pre = Evidence.Bank(prefix + ".pre.bank", before.State, before.Arena, before.Inputs);
        acknowledge(banks.State);
        object post = Evidence.Bank(prefix + ".post.bank", banks.State, banks.Arena, banks.Inputs);
        Add(new { Name = name, Seed = seed, Quantum = quantum, Pre = pre, Post = post, NativeComparable = false,
            ConsistencyAcknowledgment = true, RootAuthority = false, Scope = "Physical fixture API only; no authenticated controller acquire/release" });
        Evidence.Equal(before.Arena, banks.Arena, "Acknowledgment cannot write Arena");
        for (int word = 0; word < before.State.Length; word++)
        {
            if (word != WarpLogicalMachineLayout.SourceBoundaryStateOffset)
            { Evidence.Require(before.State[word] == banks.State[word], "Acknowledgment changes only physical phase"); }
        }
    }

    internal void OrdinaryDenial(ProofBanks banks, int quantum, int seed)
    {
        ProofBanks before = banks.Copy(); string prefix = Prefix(); bool denied = false;
        object pre = Evidence.Bank(prefix + ".pre.bank", before.State, before.Arena, before.Inputs);
        try
        {
            program.Compiled.ExecuteManagedQuantum(banks.Inputs, [seeds.ControllerWord], 0, banks.State,
                seeds.MaximumLogicalDepth, quantum, banks.Arena, CancellationToken.None);
        }
        catch (InvalidOperationException) { denied = true; }
        object post = Evidence.Bank(prefix + ".post.bank", banks.State, banks.Arena, banks.Inputs);
        Add(new { Name = "ordinary-private-program-denial", Seed = seed, Quantum = quantum, Pre = pre, Post = post,
            NativeComparable = false, ConsistencyAcknowledgment = false, RootAuthority = false, Denied = denied });
        Evidence.Require(denied, "Ordinary CoreCLR invocation remains default denied");
        Evidence.Equal(before.State, banks.State, "Ordinary denial entire State");
        Evidence.Equal(before.Arena, banks.Arena, "Ordinary denial entire Arena");
    }

    internal void RefusedAcknowledgment(string name, ProofBanks banks, int seed, int quantum, Action<uint[]> action)
    {
        ProofBanks before = banks.Copy(); string prefix = Prefix(); bool denied = false;
        object pre = Evidence.Bank(prefix + ".pre.bank", before.State, before.Arena, before.Inputs);
        try { action(banks.State); }
        catch (InvalidOperationException) { denied = true; }
        object post = Evidence.Bank(prefix + ".post.bank", banks.State, banks.Arena, banks.Inputs);
        Add(new { Name = name, Seed = seed, Quantum = quantum, Pre = pre, Post = post,
            NativeComparable = false, ConsistencyAcknowledgment = true, RootAuthority = false, Denied = denied });
        Evidence.Require(denied, "Malformed, wrong-site or repeated acknowledgment fails closed");
        Evidence.Equal(before.State, banks.State, "Rejected acknowledgment entire State");
        Evidence.Equal(before.Arena, banks.Arena, "Rejected acknowledgment entire Arena");
    }

    internal void Complete() => Evidence.Write(Path.Combine(directory, "vectors.json"), new
    {
        Status = "CORE_EXPECTED_BANKS_COMPLETE_NATIVE_NOT_EXECUTED", program.Name, Count,
        Format = "warp.proof.v4/per-quantum-full-banks/0.1", Rows = rows, RootAuthority = false,
    });

    private string Prefix() => Path.Combine(directory, "step" + Count.ToString("D6", System.Globalization.CultureInfo.InvariantCulture));
    private void Add(object row)
    {
        Evidence.Write(Prefix() + ".json", row);
        rows.Add(row);
        Evidence.Write(Path.Combine(directory, "vectors.partial.json"), new { program.Name, Count, Rows = rows });
    }
}
