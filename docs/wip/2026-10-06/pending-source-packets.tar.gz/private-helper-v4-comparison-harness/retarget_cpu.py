"""Narrow proof-only GPU-dialect to one-worker CPU physical ABI retarget."""
import argparse
import pathlib
import re
from bank_format import sha, write_json

VERSION = "warp.proof.v4/known-worker-only-cpu-retarget-preserve-u32-graph/0.1"
DECLARATIONS = {
    "NVPTX": {"declare i32 @llvm.nvvm.read.ptx.sreg.tid.x()",
              "declare i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()",
              "declare i32 @llvm.nvvm.read.ptx.sreg.ntid.x()"},
    "AMDGPU": {"declare i32 @llvm.amdgcn.workitem.id.x()",
               "declare i32 @llvm.amdgcn.workgroup.id.x()"},
    "SPIRV": {"declare spir_func i64 @_Z13get_global_idj(i32)"},
}
TRIPLES = {"NVPTX": "nvptx64-nvidia-cuda", "AMDGPU": "amdgcn-amd-amdhsa", "SPIRV": "spir64-unknown-unknown"}
REPLACEMENTS = {
    "NVPTX": {"call i32 @llvm.nvvm.read.ptx.sreg.tid.x()": "add i32 0, 0",
              "call i32 @llvm.nvvm.read.ptx.sreg.ctaid.x()": "add i32 0, 0",
              "call i32 @llvm.nvvm.read.ptx.sreg.ntid.x()": "add i32 0, 256"},
    "AMDGPU": {"call i32 @llvm.amdgcn.workitem.id.x()": "add i32 0, 0",
               "call i32 @llvm.amdgcn.workgroup.id.x()": "add i32 0, 0"},
    "SPIRV": {"call spir_func i64 @_Z13get_global_idj(i32 0)": "add i64 0, 0"},
}


def transform(source, dialect):
    if " asm " in source or "asm sideeffect" in source:
        raise ValueError("Inline vendor assembly is outside this finite fixture; no atomic or math substitution")
    if any(re.search(r"\baddrspace\((?!1\)|5\))[0-9]+\)", line) for line in source.splitlines()):
        raise ValueError("Unknown physical address space")
    declarations = [line for line in source.splitlines() if line.startswith("declare ")]
    declared = set(declarations)
    if declared != DECLARATIONS[dialect] or len(declarations) != len(declared):
        raise ValueError("Unknown, absent or duplicated physical worker declaration set")
    old_triple = 'target triple = "' + TRIPLES[dialect] + '"'
    if source.splitlines().count(old_triple) != 1:
        raise ValueError("Exact source dialect triple differs")
    edits = []
    lines = []
    for line in source.splitlines():
        updated = line
        if line in declared:
            updated = ""
        elif line == old_triple:
            updated = 'target triple = "x86_64-unknown-linux-gnu"'
        elif line.startswith("attributes #0 ="):
            if dialect != "AMDGPU" or not re.fullmatch(r'attributes #0 = \{ nounwind "amdgpu-flat-work-group-size"="256,256" \}', line):
                raise ValueError("Unknown target-only attribute")
            updated = ""
        else:
            for token, value in REPLACEMENTS[dialect].items():
                updated = updated.replace(token, value)
            updated = updated.replace("define ptx_kernel void", "define void")
            updated = updated.replace("define amdgpu_kernel void", "define void")
            updated = updated.replace("define spir_kernel void", "define void")
            updated = updated.replace("spir_func ", "")
            updated = updated.replace(" #0 {", " {")
            updated = updated.replace(" addrspace(1)", "")
            updated = updated.replace(", addrspace(5)", "").replace(" addrspace(5)", "")
        if updated != line:
            edits.append({"line": len(lines) + 1, "before": line, "after": updated})
        lines.append(updated)
    cpu = "\n".join(lines) + "\n"
    if re.search(r"llvm\.(nvvm|amdgcn)|get_global_id|\baddrspace\(|\bspir_func\b|\b(ptx_kernel|amdgpu_kernel|spir_kernel)\b| asm ", cpu):
        raise ValueError("Unmapped target-only ABI remains")
    return cpu, edits


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--program", required=True, type=pathlib.Path)
    parser.add_argument("--dialect", choices=sorted(TRIPLES), required=True)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    args = parser.parse_args()
    import json
    program = args.program.resolve()
    identity = json.loads((program / "program.json").read_text())
    emitted = json.loads((program / "emitted.json").read_text())
    row = next(row for row in emitted["dialects"] if row["dialect"] == args.dialect)
    source = pathlib.Path(row["path"])
    if sha(source).lower() != row["sha256"].lower() or row["irHash"] != identity["irHash"]:
        raise ValueError("Exact current source/common IR join failed")
    if args.output.exists():
        raise FileExistsError("CPU source output boundary must be fresh")
    args.output.mkdir(parents=True)
    try:
        cpu, edits = transform(source.read_text(), args.dialect)
        target = args.output / "cpu.ll"
        target.write_text(cpu)
        write_json(args.output / "retarget.json", {"version": VERSION, "dialect": args.dialect,
                   "sourcePath": str(source), "sourceSha256": sha(source), "cpuPath": str(target), "cpuSha256": sha(target),
                   "commonIrHash": identity["irHash"], "programIdentitySha256": sha(program / "program.json"),
                   "emissionIdentitySha256": sha(program / "emitted.json"), "edits": edits,
                   "gpuExecution": False, "vendorMathOrAtomicReplacement": False, "authority": False})
    except Exception as error:
        write_json(args.output / "retarget-failure.json", {"error": repr(error), "source": str(source), "sourceSha256": sha(source)})
        raise


if __name__ == "__main__":
    main()
