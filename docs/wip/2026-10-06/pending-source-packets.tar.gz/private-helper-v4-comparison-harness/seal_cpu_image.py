"""Hash the completed CPU compiler boundary; this script launches no tools."""
import argparse
import json
import pathlib
from bank_format import sha, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--program", type=pathlib.Path, required=True)
    parser.add_argument("--cpu-directory", type=pathlib.Path, required=True)
    parser.add_argument("--tools", type=pathlib.Path, required=True)
    args = parser.parse_args()
    tools = json.loads(args.tools.read_text())
    for name in ["llc", "cc"]:
        row = tools["tools"][name]
        if not pathlib.Path(row["path"]).is_absolute() or sha(row["path"]).lower() != row["sha256"].lower():
            raise ValueError("Exact tool path/hash differs: " + name)
    identity = json.loads((args.program / "program.json").read_text())
    target = args.cpu_directory
    retarget = json.loads((target / "retarget.json").read_text())
    if retarget["commonIrHash"] != identity["irHash"] or retarget["cpuSha256"] != sha(target / "cpu.ll"):
        raise ValueError("Completed CPU compiler source identity differs")
    if (target / "image.json").exists():
        raise FileExistsError("A completed image identity cannot be overwritten")
    write_json(target / "image.json", {"imageSha256": sha(target / "cpu.so"), "objectSha256": sha(target / "cpu.o"),
               "cpuSourceSha256": sha(target / "cpu.ll"), "retargetSha256": sha(target / "retarget.json"),
               "commonIrHash": identity["irHash"], "programSha256": sha(args.program / "program.json"),
               "toolsSha256": sha(args.tools), "tools": tools["tools"],
               "kind": "LOCAL_OFFLINE_CPU_IMAGE_ONLY", "gpu": False, "authority": False})


if __name__ == "__main__":
    main()
