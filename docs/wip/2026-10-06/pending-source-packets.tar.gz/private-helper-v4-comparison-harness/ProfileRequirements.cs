using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal static class ProfileRequirements
{
    private const string Metadata = "warp.logical-source-frames/private-controller-helper-return-scoped-publication-fence/0.10";
    private const string Scope = "warp.logical-machine/private-helper-scope/header28-call-pc-plus1-header29-caller-depth-header30-caller-activation-header31-helper-activation/0.1";
    private const string Fence = "warp.private-helper-return-fence/exact-mode1-bound-header28-31-caller-helper-activation-scope-before-tuple-and-all-successors-phase5-phase6-zero-word-resume/0.2";
    private const string CompilerIdentity = "warp.source-program-identity/compiler-private-controller-helper-return-scoped-publication-fence-raw-utf16/0.9";

    internal static void Require()
    {
        Evidence.Require(string.Equals(WarpLogicalExecutionMetadata.PrivateHelperReturnFenceVersion, Metadata, StringComparison.Ordinal) &&
            string.Equals(WarpLogicalMachineLayout.PrivateHelperScopeVersion, Scope, StringComparison.Ordinal) &&
            string.Equals(WarpPrivateControllerProjection.HelperReturnFenceSemantics, Fence, StringComparison.Ordinal) &&
            string.Equals(WarpPortableWordProgramIdentity.PrivateHelperReturnFenceVersion, CompilerIdentity, StringComparison.Ordinal),
            "Exact v4 conditional version identities; no legacy/private profile fallback");
        Evidence.Require(WarpLogicalMachineLayout.HeaderWords == 64 && WarpLogicalMachineLayout.FrameHeaderWords == 8 &&
            WarpLogicalMachineLayout.PrivateHelperScopeCallOffset == 28 && WarpLogicalMachineLayout.PrivateHelperScopeActivationOffset == 31 &&
            WarpLogicalMachineLayout.AwaitingRootRelease == 5 && WarpLogicalMachineLayout.AcknowledgedRootRelease == 6,
            "Exact common physical consistency layout");
    }
}
