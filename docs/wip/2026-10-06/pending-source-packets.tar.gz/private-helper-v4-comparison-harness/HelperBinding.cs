using System.Reflection.Emit;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.V4Proof;

internal sealed class HelperBinding : WarpPortableWordExecutionBinding
{
    private const string Service = "warp.proof.v4/captured-source-private-raw-tuple/0.1";
    private readonly int payloadWords, resultWords;
    private readonly bool nested;
    private int helper, leaf;

    internal HelperBinding(WarpPortableMethodGraph graph, WarpPortableTypedProgram typed, WarpPortableSourceHeapSchema schema,
        int payloadWords, int resultWords, bool nested, bool fenced = true, bool boundaries = true)
        : base(graph.GraphHash, typed.VerifiedHash, schema.SchemaHash, Service, graph.GraphHash,
            new(FrameOwners: true, RuntimeStateAccess: true, PrivateController: true,
                PrivateHelperBoundaries: boundaries, PrivateHelperReturnFences: fenced))
    { this.payloadWords = payloadWords; this.resultWords = resultWords; this.nested = nested; }

    internal override void Prepare(WarpPortableWordBindingPreparation context)
    {
        helper = context.ReserveFunction(Service);
        if (nested) { leaf = context.ReserveFunction(Service + "/leaf"); }
        context.InstallFunction(CreateService(helper, nested), new(0, true, [0], countsSourceDepth: false));
        if (nested) { context.InstallFunction(CreateService(leaf, callLeaf: false), new(0, true, [0], countsSourceDepth: false)); }
    }

    private WarpControlFlowFunction CreateService(int function, bool callLeaf)
    {
        var instructions = new List<WarpIrInstruction>();
        int value = 0;
        for (int index = 0; index <= payloadWords; index++)
        {
            instructions.Add(new(value++, WarpIrOpCode.LoadArgument, immediate: (uint)index));
        }
        // Operational padding is deliberately largest in the nested outer call
        // block. Small quantum therefore captures genuine generated outer and
        // nested scopes; no original source charge or data is changed.
        int paddingWords = callLeaf ? 144 : 128;
        for (int index = 0; index < paddingWords; index++)
        {
            instructions.Add(new(value++, WarpIrOpCode.Constant, immediate: unchecked((uint)index * 0x9E3779B9)));
        }
        int[] returned;
        if (callLeaf)
        {
            instructions.Add(new(value, leaf, Enumerable.Range(0, payloadWords + 1), resultWords));
            returned = Enumerable.Range(value, resultWords).ToArray();
        }
        else
        {
            int address = value++;
            instructions.Add(new(address, WarpIrOpCode.Constant));
            instructions.Add(new(value++, WarpManagedMemoryOpCode.StoreWord, address, 0));
            int nan = value++, zero = value++, maximum = value++;
            instructions.Add(new(nan, WarpIrOpCode.Constant, immediate: 0x7FC12345));
            instructions.Add(new(zero, WarpIrOpCode.Constant, immediate: 0x80000000));
            instructions.Add(new(maximum, WarpIrOpCode.Constant, immediate: uint.MaxValue));
            returned = resultWords == 4 ? [1, nan, zero, maximum] : Enumerable.Range(1, resultWords).ToArray();
        }
        return new(function, function == helper ? Service : Service + "/leaf", payloadWords + 1,
            [new(0, [], instructions, new WarpTupleReturnTerminator(returned))]);
    }

    internal override WarpBlockTerminator? LowerInstruction(WarpPortableWordInstructionContext context)
    {
        if (context.SourceInstruction.OpCode != OpCodes.Ret) { return null; }
        if (!context.PrivateHelperBoundaries)
        {
            int controller = context.Emit(WarpPrivateControllerOpCode.LoadController);
            return EmitReturn(context, controller);
        }
        int bridge = context.EmitPrivateHelperBridge((stage, controller) =>
        {
            return EmitReturn(stage, controller);
        });
        return new WarpBranchTerminator(new(bridge, []));
    }

    private WarpBlockTerminator EmitReturn(WarpPortableWordInstructionContext context, int controller)
    {
        int[] payload = payloadWords == 0 ? [] : context.LoadStackValue(0).ToArray();
        Evidence.Require(payload.Length == payloadWords, "Exact original source result width");
        // Zero-width Call currently exposes a production admission seam
        // (Result=-1 vs private CallValue>=0). Root must resolve it explicitly;
        // never substitute a fake result or synthetic source plan.
        int[] result = context.Call(helper, payload.Prepend(controller).ToArray(), resultWords).ToArray();
        // Proof-only caller publication canary. It is after the exact Call in
        // the zero-charge bridge, so phase5 must protect this private store too.
        context.StorePrivateWord(context.Body.Arguments[0].WordOffset, context.Constant(0xBAD0C0DE));
        return new WarpTupleReturnTerminator(result.Take(payloadWords));
    }

    internal override string Complete(WarpPortableWordBindingCompletion context) => WarpIrHash.Compute(context.StructuralKernel);
}
