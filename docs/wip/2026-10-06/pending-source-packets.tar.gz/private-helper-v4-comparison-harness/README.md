# Source-only v4 offline whole-bank packet

This packet is **uncompiled, unvalidated, and stopped**. Authoring used filesystem reads/writes/hashes only. No dotnet, analyzer, test, generated CoreCLR entry, worker, LLVM compiler, native CPU entry, GPU, commit, push, or deployment command ran. Root must preserve each later failed execution boundary and run the complete finite matrix before drawing a result. Development remains local; no DevOps/lab/staging/live request is made.

The pinned v4 source proposal is:
`/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/private-helper-return-fence-v4-proposal/proposal-manifest-v4.json`
SHA256 `6ac1764ddc61221921c245e05f3b864ba00d6b1fe3dd8a9da994a8fec7fe0b3c`.
The independently read-only reviewed source receipt is:
`/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-evidence/numeric-worker/private-helper-return-fence-v4-root-source-review/integrity-receipt.json`
SHA256 `b058cda45329691c194dcee96c6c080fef7a38e2c6306b52b8b3e28296870c28`.
The latter is a source-integrity receipt, not executed v4 evidence. Its actual spelling contains `b3e282`, not `b3b282`.

The historical 9714 profile proof remains unchanged at:
`/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-evidence/numeric-worker/private-helper-native-profile9714/frozen-references/integration-manifest.json`.
That proof's nine device images and its old private-entry profile do not prove v4 return fencing or Root's future production DLL boundary. This packet imports only exact pinned small analyzer policies by absolute reference; it copies no historical source tree, proof tree, DLL, or package cache. Its retained-partial-source directory preserves only this packet's eight original small authoring inputs, excluded from compilation.

## Finite coverage

All four source methods are in SourceKernels.cs. They are captured with Discover/Verify/typed heap schema and compiler-owned instruction lowering. The harness never invokes an original method or uses a source/opcode interpreter.

| Source | Exact expected Release CIL | Source result | Private service result | Source charge |
|---|---|---|---|---|
| UInt32 Echo(uint) | ldarg.0; ret | one uint word | one raw word | 2 |
| UInt64 Wide(ulong) | ldarg.0; ret | two low/high uint transport words | two raw words | 2 |
| void Empty(uint) | ret | no words | no words | 1 |
| UInt32 Echo with nested pure helper | ldarg.0; ret | one uint word | four raw tuple words | 2 |

The last service explicitly returns `(sourceWord, 0x7FC12345, 0x80000000, 0xFFFFFFFF)`; the original source still returns UInt32. These extra runtime fields are a declared service tuple, not a numeric type substitution. The wide source remains UInt64 in the verified graph and uses its admitted two-word representation without UInt32 narrowing.

Each helper writes only Arena[0] with its raw incoming controller consistency word. Every other arena word is a canary. After the call the bridge has a private source-argument-slot canary store `0xBAD0C0DE`; phase5 must protect this store as well as terminal return. Operational constant padding, with the nested outer call largest, requests genuine generated outer/nested continuation scopes at the small quantum. Padding has no original source charge or data result.

There is one CreateInitialState per program. The initial bank is persisted once, cloned across all eight raw-word seeds, both quanta and all three dialects. Namespace/activation state is never reallocated per backend. Inputs and Arena use the same global seed JSON. Maximum logical depth8/source steps1024, quanta layout.MaximumBlockCost and4096. Normal trace groups planned:64; generated scope capture groups planned:32. Actual invocation and word counts are computed only by a later run.

The comparison includes phase0 re-parking with stale words, phase3 unchanged without acknowledgment, phase4+zero entirely unchanged, phase5 unconditional park after complete tuple restoration, phase5 unchanged for all selected words, and phase6+stale unchanged followed by phase6+zero consistency resume. It checks positive original Ret charge and no repeated bridge/helper charge. It checks tuple width0/1/2/4 at caller `64 + (depth-1)*FrameWords + 8 + ResultValue`, the retained call tag/depth/caller activation/helper activation, exact continuation, no root result before publication, and all private/arena/input words.

Malformed rows start from genuine generated bridge/outer/nested/publication banks, then mutate physical mode, phase, dispatch/function, scope tag/depth, result coordinate/width, caller/helper activation, namespace0, next-activation0, private layout/count or unexpected aliases. The complete malformed pre-bank is the expected unchanged post-bank at both quanta. Nested pure-helper return location, tuple width and parent activation are separate cases. Wrong-site/repeated consistency acknowledgment APIs must throw without changing any bank. Arbitrary nonzero namespace replacements or forged tuple *contents* cannot be authenticated by physical scope consistency; Root must bind their exact full-bank identity separately.

The controlled Core path deliberately uses only generated CompiledEntryPoint reflection. Ordinary ExecuteManagedQuantum remains denied before mutation. All 1->2/3->4/5->6 acknowledgments are labeled **synthetic consistency fixtures**, excluded from native entry replay and preserved with before/after banks. No opaque Root permit, nonce, SCCAS grant, publication/release receipt, HMAC command or worker-envelope extension exists here. No guest cctor/filter/handler/wait admission is invented by these four simple source methods.

## Exact future production input

Root must author a fresh root-inputs.json using root-inputs.template.json, and root-tools.json using root-tools.template.json, outside this stopped packet. Every production DLL and both actual source/artifact receipts require absolute paths and actual SHA256. No default DLL directory, borrowed sealed assembly, or historical test assembly is loaded. The compiled assembly is named WarpCLR.Tests to use existing friend APIs; references are Private=false, so product DLLs are not copied. The resolver loads only the supplied five assemblies and verifies actual loaded location/hash. The proof records actual original CIL bytes/token/MVID/module hash, compiler graph/typed/schema/map identity, generated collectible module/token, full source/root/alias maps and new metadata identity.

SDK10.0.303/global.json and runtime10.0.12 remain required. The project imports exact existing pinned analyzer policies, retains latest-all/style/nullable/warnings-as-errors, and includes the banned policy. The own proof.globalconfig carries the pinned diagnostic policy globally for these external-source-free files; it adds no suppression. No test-framework analyzer is added to this console oracle.

**Required narrow production seam:** Context.Call(..., resultWords:0) emits Call.Result=-1. Frozen v4 projection construction rejected CallValue<0. Root has identified the minimal exact zero-width-call identity correction: allow CallValue=-1 only for its matching zero-result Call; reject values<-1 and negative identities for any nonzero tuple. Current Core/LLVM already normalize physical zero-width FrameReturnValue and return-site ResultValue to0. The harness preserves actual Empty/Ret and this signed call identity; it never fabricates a synthetic substitute. Root must explicitly bind its corrected production source/artifact receipt. The packet does not edit the frozen v4 proposal or implementation.

Fenced programs require metadata0.10, scope0.1, fence0.2, compiler identity0.9 and WBP8. Ordinary and private-projection0.7/private-entry0.8 plans are independently built from the same supplied Root DLLs and preserve WBP6 conditional serialization/hash round trips. Those are current-boundary consistency checks, not historical pre/post hash evidence. Root must separately join any actual earlier emitted identities if asserting invariance. Prior fenced metadata0.9/WBP7 is not an admission fallback.

## Anticipated Root commands (not executed)

Use one existing pinned package cache; make no new cache copy. One allowed keeper is:
`/home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/fault-take-canonical-packages`.
The approved exact parent cache is another choice; choose one existing cache, not both.

Root may later generate a structured command plan:

```sh
/path/to/pinned/python3 /home/codex/Codex/Projects/WarpSharp-NET/.supervisor-stage/numeric-worker/private-helper-v4-comparison-packet/make_root_plan.py   --root-inputs /absolute/future/root-inputs.json   --tools /absolute/future/root-tools.json   --packages /absolute/existing/pinned/package-cache   --build-root /absolute/fresh/root-owned/proof-build   --evidence-root /absolute/fresh/root-owned/proof-evidence   --plan /absolute/fresh/root-owned/serial-plan.json
```

make_root_plan.py prints/writes commands only and never invokes a tool. Its plan uses forced --no-cache restore, clean, forced --no-cache restore, nonincremental Release with full enabled analyzers, then Core expected-side generation and serial per-dialect retarget/llc/cc/image seal/CPU entry execution, followed by an independent join. BaseOutputPath/BaseIntermediateOutputPath/MSBuildProjectExtensionsPath are Root-owned, so the stopped packet and product outputs are never cleaned or written. No project references build a product solution. Root's own bounded validation driver must run the argv arrays sequentially, set the explicit environment/path prepend, create log parents, record real command/tool/PID/PGID/timing/exit/stop receipts, and retain stdout/stderr and every failed boundary. No retry is encoded. Source-only plan generation is not authorization to execute it.

External build quota2400s, Core proof preparation1200s, per-llc/link/CPU process60s. Those are local validation caps, not changes to production JIT120s/quantum30s/cleanup2s. Root must stop/census every actual owned tool/CPU process before freezing execution evidence; an image hash or no-live-process snapshot alone is not a production containment acknowledgment.

retarget_cpu.py changes only the exact three physical worker intrinsic sets (one worker0), known calling conventions, target triple, explicit address spaces1/5 and the known AMD workgroup attribute. It persists every changed line and rejects unknown declarations/vendor inline assembly/other address spaces. It does not replace arithmetic, math, atomics, types, source budget or scope logic. It uses Root's actual emitted LLVM, hashes common IR and complete type/compiler identities, and keeps all original emitted .gpu.ll bytes. It produces x86_64 CPU LLVM for NVPTX/AMDGPU/SPIR-V source dialects. The planned images are12 CPU .so libraries plus their .o/.ll identities. It creates **zero PTX/HSACO/SPIR-V device images** and makes no device-validation/support/GPU claim; such an additional native-target gate belongs to Root's separate integration matrix.

run_cpu_vectors.py directly calls warp_resume through the full admitted State/input/scalar/count/base/depth/quantum/Arena C ABI. Each Core pre-bank is replayed once and every native post-bank is persisted and compared word by word with its Core post-bank. This covers all trajectory invocations and malformed cases; matching each step proves the stored continuation trace by induction. Parent fixture acknowledgments are recorded separately and do not become native authority. The independent join rereads all complete banks, checks exact vectors/seed/initial-state/source/type/IR/retarget/tool/object/image identities, and requires identical full-bank witness hashes across the three dialects. It computes counts from actual completed rows and rejects missing/failing/incomplete cases. Root must join its separate command/producer-stop receipts before calling the entire validation boundary complete.

Bank transport is a distinct diagnostic LE raw-word file: magic0x34504257 (ASCII WBP4), counts, input lengths, complete State then Arena then inputs. This is not the product WBP8 plan codec or any authenticated worker protocol. UINT words never pass through host float or signed-number reinterpretation. Failure bank contents and per-step JSON are written before oracle assertions; partial/failure statuses never count as PASS.

## Integration and stopping

The packet has only harness/script/project/policy/config/seed/documentation files. No Main/SDK/frozen source, production emitter, worker, Source permit, operation ticket, controller registry or envelope was changed. It does not manufacture Root's authentic phase5 tuple publication, root acknowledgment or normal controller release. Source consistency words and compiler metadata remain forgeable outside Root's opaque full-bank registration. Root owns authentic private entry/end/release and reacquisition before guest/cctor/filter/handler/wait execution, plus all source shared-access exclusion.

All authoring inputs and a rejected source-edit tool attempt are retained in source-preparation-log.json and retained-partial-source/. There were zero executed compiler/analyzer/test/child/native/GPU cases. The manifest/seal freezes only this source-only proposal. **STOP before any build or run; await Root execution direction.**
