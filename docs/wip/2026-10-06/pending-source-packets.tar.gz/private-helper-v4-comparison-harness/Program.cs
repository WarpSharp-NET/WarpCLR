using System.Runtime.Loader;
using System.Text.Json;

namespace WarpCLR.Tests.V4Proof;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length != 3)
        {
            throw new ArgumentException("Expected Root input config, seed inventory, fresh output directory.", nameof(args));
        }
        RootInputs inputs = JsonSerializer.Deserialize<RootInputs>(File.ReadAllText(args[0]), Evidence.Options)
            ?? throw new InvalidDataException("The future Root production input inventory is absent.");
        inputs.Validate();
        Evidence.Require(string.Equals(Environment.Version.ToString(), "10.0.12", StringComparison.Ordinal), "Pinned .NET runtime");
        AssemblyLoadContext.Default.Resolving += (_, name) =>
            name.Name is { } key && inputs.Assemblies.TryGetValue(key, out ReferenceInput? row) ?
                AssemblyLoadContext.Default.LoadFromAssemblyPath(row.Path) : null;
        foreach (ReferenceInput row in inputs.Assemblies.Values)
        { System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromAssemblyPath(row.Path); }
        ProofPreparation.Run(args[0], args[1], args[2], inputs);
        return 0;
    }
}

internal sealed record ReferenceInput(string Path, string Sha256)
{
    internal void Validate()
    {
        Evidence.Require(System.IO.Path.IsPathFullyQualified(Path), "Exact absolute input path");
        Evidence.Require(string.Equals(Evidence.Hash(File.ReadAllBytes(Path)), Sha256, StringComparison.OrdinalIgnoreCase),
            "Exact input bytes: " + Path);
    }
}

internal sealed record RootInputs(string Format, string ProductionGateLabel,
    ReferenceInput ProductionSourceReceipt, ReferenceInput ProductionArtifactReceipt,
    Dictionary<string, ReferenceInput> Assemblies)
{
    internal void Validate()
    {
        Evidence.Require(string.Equals(Format, "warp.proof.v4/root-production-inputs/0.1", StringComparison.Ordinal), "Input schema");
        Evidence.Require(!string.IsNullOrWhiteSpace(ProductionGateLabel), "Explicit future production gate label");
        ProductionSourceReceipt.Validate();
        ProductionArtifactReceipt.Validate();
        string[] required = ["WarpCLR.Core", "WarpCLR.IR", "WarpCLR.Compiler", "WarpCLR.Verifier", "WarpCLR.Backend.CoreCLR"];
        Evidence.Require(Assemblies.Keys.Order(StringComparer.Ordinal).SequenceEqual(required.Order(StringComparer.Ordinal)),
            "Exact five production references");
        foreach ((string name, ReferenceInput row) in Assemblies)
        {
            row.Validate();
            Evidence.Require(string.Equals(System.IO.Path.GetFileNameWithoutExtension(row.Path), name, StringComparison.Ordinal),
                "Reference assembly basename");
        }
    }
}
