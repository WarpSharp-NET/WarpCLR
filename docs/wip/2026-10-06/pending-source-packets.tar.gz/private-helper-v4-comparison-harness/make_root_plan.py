"""Emit structured future commands only; NEVER invokes dotnet/compiler/children."""
import argparse
import json
import pathlib
from bank_format import sha, write_json

PACKET = pathlib.Path(__file__).resolve().parent
EXPECTED_PROFILE = "6ac1764ddc61221921c245e05f3b864ba00d6b1fe3dd8a9da994a8fec7fe0b3c"
EXPECTED_INTEGRITY = "b058cda45329691c194dcee96c6c080fef7a38e2c6306b52b8b3e28296870c28"
PROGRAMS = ["CapturedUInt32Echo_Service1", "CapturedUInt64Echo_Service2", "CapturedVoidEmpty_Service0", "CapturedUInt32Echo_NestedService4"]
ASSEMBLIES = {"WarpCLR.Core": "WarpProofCore", "WarpCLR.IR": "WarpProofIr", "WarpCLR.Compiler": "WarpProofCompiler",
              "WarpCLR.Verifier": "WarpProofVerifier", "WarpCLR.Backend.CoreCLR": "WarpProofCoreClr"}


def validated(row):
    path = pathlib.Path(row["path"])
    if not path.is_absolute() or sha(path).lower() != row["sha256"].lower():
        raise ValueError("Explicit absolute input bytes differ: " + str(path))
    return str(path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root-inputs", required=True, type=pathlib.Path)
    parser.add_argument("--tools", required=True, type=pathlib.Path)
    parser.add_argument("--packages", required=True, type=pathlib.Path)
    parser.add_argument("--build-root", required=True, type=pathlib.Path)
    parser.add_argument("--evidence-root", required=True, type=pathlib.Path)
    parser.add_argument("--plan", required=True, type=pathlib.Path)
    args = parser.parse_args()
    if args.plan.exists() or args.build_root.exists() or args.evidence_root.exists():
        raise FileExistsError("Fresh Root-owned execution/output boundary required; never reuse failed bytes")
    refs = json.loads(args.root_inputs.read_text())
    if refs["format"] != "warp.proof.v4/root-production-inputs/0.1" or set(refs["assemblies"]) != set(ASSEMBLIES):
        raise ValueError("Future production reference inventory differs")
    validated(refs["productionSourceReceipt"])
    validated(refs["productionArtifactReceipt"])
    paths = {name: validated(row) for name, row in refs["assemblies"].items()}
    tools = json.loads(args.tools.read_text())
    if tools["format"] != "warp.proof.v4/root-tools/0.1":
        raise ValueError("Exact tool config schema differs")
    binaries = {name: validated(tools["tools"][name]) for name in ["dotnet", "python", "llc", "cc"]}
    immutable = json.loads((PACKET / "immutable-inputs.json").read_text())
    for row in immutable:
        validated(row)
    if immutable[0]["sha256"] != EXPECTED_PROFILE or immutable[1]["sha256"] != EXPECTED_INTEGRITY:
        raise ValueError("Proposal/integrity receipt pin differs")
    policy = pathlib.Path(immutable[2]["path"]).parent
    packages = args.packages.resolve()
    if not packages.is_dir():
        raise ValueError("Use the existing exact shared pinned cache; do not copy/download another package tree")
    build = args.build_root.resolve()
    evidence = args.evidence_root.resolve()
    msbuild = ["-p:ImportDirectoryBuildProps=false", "-p:ImportDirectoryPackagesProps=false", "-p:UseSharedCompilation=false",
               "-p:WarpProofPolicies=" + str(policy), "-p:BaseOutputPath=" + str(build / "bin") + "/",
               "-p:BaseIntermediateOutputPath=" + str(build / "obj") + "/", "-p:MSBuildProjectExtensionsPath=" + str(build / "obj") + "/"]
    msbuild += ["-p:" + ASSEMBLIES[name] + "=" + paths[name] for name in sorted(ASSEMBLIES)]
    project = str(PACKET / "WarpCLR.Tests.csproj")
    commands = []

    def add(name, argv, quota):
        commands.append({"ordinal": len(commands), "name": name, "argv": argv, "cwd": str(PACKET),
                         "externalValidationQuotaSeconds": quota, "execute": False,
                         "stdoutPath": str(evidence / "logs" / (name + ".stdout.log")),
                         "stderrPath": str(evidence / "logs" / (name + ".stderr.log")),
                         "commandReceiptPath": str(evidence / "logs" / (name + ".receipt.json"))})

    add("restore1", [binaries["dotnet"], "restore", project, "--force", "--no-cache", "--packages", str(packages)] + msbuild, 2400)
    add("clean", [binaries["dotnet"], "clean", project, "-c", "Release", "-m:1"] + msbuild, 2400)
    add("restore2", [binaries["dotnet"], "restore", project, "--force", "--no-cache", "--packages", str(packages)] + msbuild, 2400)
    add("release", [binaries["dotnet"], "build", project, "-c", "Release", "--no-restore", "--no-incremental", "-m:1"] + msbuild, 2400)
    prepared = evidence / "core"
    add("core-prepare", [binaries["dotnet"], str(build / "bin" / "Release" / "net10.0" / "WarpCLR.Tests.dll"),
                         str(args.root_inputs.resolve()), str(PACKET / "proposed-seeds.json"), str(prepared)], 1200)
    for name in PROGRAMS:
        program = prepared / name
        for dialect in ["NVPTX", "AMDGPU", "SPIRV"]:
            cpu = evidence / "cpu-images" / name / dialect
            stem = name + "-" + dialect
            add(stem + "-retarget", [binaries["python"], str(PACKET / "retarget_cpu.py"), "--program", str(program),
                                    "--dialect", dialect, "--output", str(cpu)], 60)
            add(stem + "-llc", [binaries["llc"], "-O2", "-filetype=obj", "-relocation-model=pic", str(cpu / "cpu.ll"), "-o", str(cpu / "cpu.o")], 60)
            add(stem + "-link", [binaries["cc"], "-shared", "-Wl,--no-undefined", str(cpu / "cpu.o"), "-o", str(cpu / "cpu.so")], 60)
            add(stem + "-image-seal", [binaries["python"], str(PACKET / "seal_cpu_image.py"), "--program", str(program),
                                      "--cpu-directory", str(cpu), "--tools", str(args.tools.resolve())], 60)
            add(stem + "-cpu", [binaries["python"], str(PACKET / "run_cpu_vectors.py"), "--program", str(program),
                               "--cpu-directory", str(cpu), "--tools", str(args.tools.resolve()), "--seeds", str(PACKET / "proposed-seeds.json"),
                               "--output", str(evidence / "comparisons" / name / dialect)], 60)
    add("independent-join", [binaries["python"], str(PACKET / "join_results.py"), "--evidence", str(evidence),
                            "--seeds", str(PACKET / "proposed-seeds.json"), "--root-inputs", str(args.root_inputs.resolve()),
                            "--tools", str(args.tools.resolve())], 60)
    write_json(args.plan, {"status": "PROPOSED_FUTURE_COMMANDS_NOT_EXECUTED", "format": "warp.proof.v4/serial-root-command-plan/0.1",
               "rootInputsSha256": sha(args.root_inputs), "toolsSha256": sha(args.tools), "packetManifestSha256": sha(PACKET / "packet-manifest.json"),
               "v4ProposalSha256": EXPECTED_PROFILE, "rootSourceIntegritySha256": EXPECTED_INTEGRITY,
               "pathPrepend": str(pathlib.Path(binaries["dotnet"]).parent),
               "environment": {"DOTNET_ROOT": str(pathlib.Path(binaries["dotnet"]).parent),
                               "NUGET_PACKAGES": str(packages), "DOTNET_CLI_TELEMETRY_OPTOUT": "1"},
               "commands": commands, "executionRequiredFromRoot": "Use one existing bounded serial validation driver; save actual argv/env/PID/PGID/exit/stop receipts and complete stdout/stderr. This plan never starts tools.",
               "cpuImagesPlanned": 12, "deviceImages": 0, "gpu": False, "privateRpc": False, "authority": False,
               "productionQuotasUnchanged": {"jit": 120, "quantum": 30, "cleanup": 2}})


if __name__ == "__main__":
    main()
