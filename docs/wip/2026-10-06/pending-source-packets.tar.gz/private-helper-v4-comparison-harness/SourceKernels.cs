namespace WarpCLR.Tests.V4Proof;

internal static class SourceKernels
{
    // Captured CIL only. The harness never invokes these source methods.
    public static uint Echo(uint value) => value;
    public static ulong Wide(ulong value) => value;
    public static void Empty(uint value) { }
}
