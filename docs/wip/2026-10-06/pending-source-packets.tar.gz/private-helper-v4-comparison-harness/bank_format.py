"""Full raw uint bank transport for the offline proof; no source execution."""
import hashlib
import json
import pathlib
import struct

MAGIC = 0x34504257
FORMAT = "warp.proof.v4/little-endian-full-uint-banks/0.1"
MAX_WORDS = 16_777_216


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    pathlib.Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def read_bank(row):
    path = pathlib.Path(row["path"])
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest().lower() != row["sha256"].lower():
        raise ValueError("Full bank hash differs: " + str(path))
    if len(data) < 16 or len(data) % 4:
        raise ValueError("Truncated/unaligned bank file")
    words = list(struct.unpack("<" + "I" * (len(data) // 4), data))
    magic, state_count, arena_count, input_count = words[:4]
    if magic != MAGIC or max(state_count, arena_count, input_count) > MAX_WORDS or input_count > 128:
        raise ValueError("Bank schema or admission differs")
    lengths = words[4:4 + input_count]
    if len(lengths) != input_count or any(size > MAX_WORDS for size in lengths):
        raise ValueError("Bank input lengths exceed admission")
    if 4 + input_count + state_count + arena_count + sum(lengths) != len(words):
        raise ValueError("Complete full bank length differs")
    offset = 4 + input_count
    state = words[offset:offset + state_count]
    offset += state_count
    arena = words[offset:offset + arena_count]
    offset += arena_count
    inputs = []
    for length in lengths:
        inputs.append(words[offset:offset + length])
        offset += length
    return state, arena, inputs


def write_bank(path, state, arena, inputs):
    words = [MAGIC, len(state), len(arena), len(inputs)]
    words += [len(bank) for bank in inputs]
    words += list(state) + list(arena)
    for bank in inputs:
        words += list(bank)
    if any(value < 0 or value > 0xFFFFFFFF for value in words):
        raise ValueError("A raw UInt32 word was narrowed or converted")
    pathlib.Path(path).write_bytes(struct.pack("<" + "I" * len(words), *words))
    return {"path": str(pathlib.Path(path).resolve()), "sha256": sha(path), "stateWords": len(state),
            "arenaWords": len(arena), "inputLengths": [len(bank) for bank in inputs], "format": FORMAT}


def difference(expected, actual):
    names = ["State", "Arena"] + ["Input" + str(i) for i in range(len(expected[2]))]
    left = [expected[0], expected[1]] + expected[2]
    right = [actual[0], actual[1]] + actual[2]
    if len(left) != len(right):
        return {"kind": "bank-count", "expected": len(left), "actual": len(right)}
    for name, a, b in zip(names, left, right, strict=True):
        if len(a) != len(b):
            return {"bank": name, "kind": "length", "expected": len(a), "actual": len(b)}
        for offset, (x, y) in enumerate(zip(a, b, strict=True)):
            if x != y:
                return {"bank": name, "word": offset, "expected": x, "actual": y,
                        "expectedHex": f"{x:08X}", "actualHex": f"{y:08X}"}
    return None
