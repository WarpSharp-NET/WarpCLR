using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal sealed record GeneratedCheckpoints(ProofBanks BeforeHelper, ProofBanks OuterActive, ProofBanks? NestedActive,
    ProofBanks Publication);

internal static class ScopeSeeds
{
    internal static GeneratedCheckpoints Capture(ProofProgram program, SeedInventory seeds, ComparisonVectors writer,
        uint[] initial, int seed)
    {
        int quantum = program.Layout.MaximumBlockCost;
        var banks = new ProofBanks((uint[])initial.Clone(), seeds.Arena(seed), seeds.Inputs(program, seed));
        TraceCases.ReachHelper(program, seeds, writer, banks, seed, quantum, "scope-seed");
        ProofBanks before = banks.Copy();
        writer.Acknowledge("synthetic-scope-entry-3-to-4", banks, seed, quantum,
            state => program.Layout.AcknowledgePrivateHelperBoundary(state));
        ProofBanks? outer = null, nested = null;
        for (int attempt = 0; attempt < 128; attempt++)
        {
            writer.Step("genuine-generated-scope-capture", banks, seeds.ControllerWord, quantum, seed);
            uint callerDepth = banks.State[WarpLogicalMachineLayout.PrivateHelperScopeCallerDepthOffset];
            if (banks.State[15] == WarpLogicalMachineLayout.AwaitingRootRelease)
            {
                Evidence.Require(outer is not null && (!program.Nested || nested is not null), "Genuine generated outer/nested helper scopes");
                TraceCases.Publication(program, seeds, banks, seed);
                return new(before, outer ?? throw new InvalidOperationException("Genuine outer scope was not captured."), nested, banks.Copy());
            }
            Evidence.Require(program.Layout.HasValidRuntimeHeader(banks.State) && banks.State[0] == WarpLogicalMachineLayout.Runnable &&
                callerDepth != 0, "Genuine running generated scope before any corruption");
            if (banks.State[6] == callerDepth + 1) { outer ??= banks.Copy(); }
            if (banks.State[6] == callerDepth + 2) { nested ??= banks.Copy(); }
        }
        throw new InvalidOperationException("Finite generated scope capture did not reach publication.");
    }
}
