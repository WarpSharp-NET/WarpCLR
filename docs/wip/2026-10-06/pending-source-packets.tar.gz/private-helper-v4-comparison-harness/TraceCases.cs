using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal static class TraceCases
{
    internal static void Run(ProofProgram program, SeedInventory seeds, ComparisonVectors writer, uint[] initial,
        int seed, int quantum)
    {
        var banks = new ProofBanks((uint[])initial.Clone(), seeds.Arena(seed), seeds.Inputs(program, seed));
        writer.OrdinaryDenial(banks, quantum, seed);
        ReachHelper(program, seeds, writer, banks, seed, quantum, "normal");
        ProofBanks phase0 = banks.Copy(); phase0.State[15] = 0;
        writer.Step("phase0-stale-word-reparks-before-load", phase0, seeds.ControllerWord, quantum, seed);
        Evidence.Equal(banks.State, phase0.State, "Phase0 changes only phase0-to3 at exact same bridge");
        Evidence.Equal(banks.Arena, phase0.Arena, "Phase0 park before service effect");
        foreach (uint stale in new[] { 0u, seeds.ControllerWord, uint.MaxValue })
        { writer.Step("phase3-word-without-ack-is-unchanged", banks, stale, quantum, seed, unchanged: true); }
        writer.Acknowledge("synthetic-entry-3-to-4", banks, seed, quantum,
            state => program.Layout.AcknowledgePrivateHelperBoundary(state));
        writer.Step("phase4-zero-before-load-is-entirely-unchanged", banks, 0, quantum, seed, unchanged: true);
        for (int attempt = 0; attempt < 128 && banks.State[15] != WarpLogicalMachineLayout.AwaitingRootRelease; attempt++)
        {
            writer.Step("helper-quantum-until-unconditional-phase5", banks, seeds.ControllerWord, quantum, seed);
            Evidence.Require(banks.State[0] == WarpLogicalMachineLayout.Runnable, "No caller/terminal successor can complete before phase5");
        }
        Publication(program, seeds, banks, seed);
        foreach (uint stale in new[] { 0u, 1u, seeds.ControllerWord, uint.MaxValue })
        { writer.Step("phase5-entire-banks-park-for-all-words", banks, stale, quantum, seed, unchanged: true); }
        writer.Acknowledge("synthetic-publication-5-to-6-NO-root-release", banks, seed, quantum,
            state => program.Layout.AcknowledgePrivateHelperRelease(state));
        writer.Step("phase6-stale-word-cannot-resume", banks, seeds.ControllerWord, quantum, seed, unchanged: true);
        program.Layout.RequireAcknowledgedPrivateHelperRelease(banks.State, 0);
        for (int attempt = 0; attempt < 128 && banks.State[0] == WarpLogicalMachineLayout.Runnable; attempt++)
        {
            writer.Step("phase6-zero-consistency-only-resume", banks, 0, quantum, seed);
            Evidence.Require(banks.State[15] == 0 && banks.State.AsSpan(28, 4).SequenceEqual(new uint[4]),
                "Acknowledged release scope clears exactly before successor");
        }
        Completed(program, seeds, banks, seed, seeds.ControllerWord);
        DisabledMode(program, seeds, writer, initial, seed, quantum);
    }

    internal static void ReachHelper(ProofProgram program, SeedInventory seeds, ComparisonVectors writer, ProofBanks banks,
        int seed, int quantum, string prefix)
    {
        for (int attempt = 0; attempt < 128; attempt++)
        {
            if (banks.State[15] == WarpLogicalMachineLayout.NeedsPrivateHelper) { return; }
            if (banks.State[15] == WarpLogicalMachineLayout.BeforeSourceBoundary)
            {
                writer.Acknowledge(prefix + "-synthetic-source-1-to-2", banks, seed, quantum,
                    state => WarpLogicalMachineLayout.AcknowledgeSourceBoundary(state));
            }
            writer.Step(prefix + "-captured-original-cil", banks, seeds.ControllerWord, quantum, seed);
            Evidence.Require(banks.State[0] == WarpLogicalMachineLayout.Runnable, "Original CIL must reach its admitted private bridge");
        }
        throw new InvalidOperationException("Finite source run did not reach its exact helper bridge.");
    }

    internal static void Publication(ProofProgram program, SeedInventory seeds, ProofBanks banks, int seed)
    {
        WarpPrivateHelperReturnSite site = program.Layout.PrivateHelperReturnSites.Single();
        Evidence.Require(banks.State[15] == WarpLogicalMachineLayout.AwaitingRootRelease && program.Layout.HasValidRuntimeHeader(banks.State),
            "Exact valid phase5 restored caller before every successor");
        int frame = checked(64 + ((int)banks.State[6] - 1) * program.Layout.FrameWords);
        Evidence.Require(banks.State[6] == banks.State[29] && banks.State[frame] == site.CallerFunction &&
            banks.State[frame + 1] == site.Continuation && banks.State[frame + 4] == banks.State[30] &&
            banks.State[28] == site.CallProgramCounter + 1, "Physical caller/scope/PC/activation coordinates");
        uint[] expected = program.ServiceWords == 4 ? [banks.Inputs[0][0], 0x7FC12345, 0x80000000, uint.MaxValue] :
            banks.Inputs.Take(program.ServiceWords).Select(input => input[0]).ToArray();
        Evidence.Equal(expected, banks.State.AsSpan(frame + WarpLogicalMachineLayout.FrameHeaderWords + site.ResultValue,
            site.ResultWordCount).ToArray(), "Entire raw zero/one/two/four-word tuple");
        Evidence.Require(banks.State[frame + program.Layout.PrivateOffset] == banks.Inputs[0][0], "Caller private canary store has not executed");
        Evidence.Require(banks.State[7] == 0 && banks.State[8] == 0, "Root return remains unpublished");
        SourceCharge(program, seeds, banks);
        Arena(seeds, banks, seed, seeds.ControllerWord);
    }

    private static void Completed(ProofProgram program, SeedInventory seeds, ProofBanks banks, int seed, uint controller)
    {
        Evidence.Require(banks.State[0] == WarpLogicalMachineLayout.Completed, "Exact caller successor completes after consistency release");
        for (int word = 0; word < program.PayloadWords; word++)
        {
            Evidence.Require(banks.State[program.Layout.GetResultWordOffset(word, seeds.MaximumLogicalDepth)] == banks.Inputs[word][0],
                "Original source result is exact raw UInt32/UInt64 transport");
        }
        SourceCharge(program, seeds, banks); Arena(seeds, banks, seed, controller);
        WarpPrivateHelperReturnSite site = program.Layout.PrivateHelperReturnSites.Single();
        int caller = Enumerable.Range(0, seeds.MaximumLogicalDepth * program.Layout.Kernel.HelperExpansionFactor)
            .Select(index => 64 + index * program.Layout.FrameWords).First(frame => banks.State[frame] == site.CallerFunction);
        Evidence.Require(banks.State[caller + program.Layout.PrivateOffset] == 0xBAD0C0DE, "Post-call caller store executes only after release fixture");
    }

    private static void SourceCharge(ProofProgram program, SeedInventory seeds, ProofBanks banks)
    {
        uint charge = program.PayloadWords == 0 ? 1u : 2u;
        Evidence.Require(banks.State[4] == (uint)seeds.MaximumSourceSteps - charge && banks.State[5] == 0,
            "Original Ret is positive charged; bridge/helper/publication/resume never repeat source charge");
    }

    private static void Arena(SeedInventory seeds, ProofBanks banks, int seed, uint controller)
    {
        uint[] expected = seeds.Arena(seed); expected[0] = controller;
        Evidence.Equal(expected, banks.Arena, "Only helper Arena word0 changes; every canary remains raw");
    }

    private static void DisabledMode(ProofProgram program, SeedInventory seeds, ComparisonVectors writer,
        uint[] initial, int seed, int quantum)
    {
        var banks = new ProofBanks((uint[])initial.Clone(), seeds.Arena(seed), seeds.Inputs(program, seed));
        program.Layout.SetSourceBoundaryMode(banks.State, false);
        for (int attempt = 0; attempt < 128 && banks.State[0] == WarpLogicalMachineLayout.Runnable; attempt++)
        { writer.Step("disabled-mode-zero-word-is-legal-consistency-only", banks, 0, quantum, seed); }
        Evidence.Require(banks.State[15] == 0 && banks.State.AsSpan(28, 4).SequenceEqual(new uint[4]), "Disabled mode does not record a private scope");
        Completed(program, seeds, banks, seed, 0);
    }
}
