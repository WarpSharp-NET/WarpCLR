using System.Buffers.Binary;
using System.Text;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal static class ProgramArtifacts
{
    internal static void Write(ProofProgram program, string directory)
    {
        string hash = WarpIrHash.Compute(program.Layout.Kernel);
        byte[] plan = WarpCoreCLRBinaryPlanCodec.Serialize(program.Layout.Kernel);
        Evidence.Require(BinaryPrimitives.ReadUInt32LittleEndian(plan) == 0x57425038, "New fenced plan WBP8 only");
        Evidence.Require(string.Equals(WarpIrHash.Compute(WarpCoreCLRBinaryPlanCodec.Deserialize(plan, hash)), hash,
            StringComparison.Ordinal), "Complete tuple/metadata codec identity");
        File.WriteAllBytes(Path.Combine(directory, "word-plan.bin"), plan);
        ConditionalProfiles(program, directory);
        var emitted = new List<object>();
        foreach (WarpBackendKind dialect in new[] { WarpBackendKind.NVPTX, WarpBackendKind.AMDGPU, WarpBackendKind.SPIRV })
        {
            string source = WarpPortableMachineEmitter.Emit(program.Layout, dialect);
            string path = Path.Combine(directory, dialect + ".gpu.ll"); File.WriteAllText(path, source, new UTF8Encoding(false));
            emitted.Add(new { Dialect = dialect.ToString(), Path = path, Sha256 = Evidence.Hash(File.ReadAllBytes(path)), IrHash = hash,
                GraphHash = program.Graph.GraphHash, TypedHash = program.Typed.VerifiedHash,
                EntryPoint = WarpPortableMachineEmitter.EntryPoint, CPUOnlyRetargetPlanned = true });
        }
        Evidence.Write(Path.Combine(directory, "emitted.json"), new { PlanSha256 = Evidence.Hash(plan), IrHash = hash, Dialects = emitted });
    }

    private static void ConditionalProfiles(ProofProgram program, string directory)
    {
        var rows = new List<object>();
        WarpPortableWordLoweredProgram ordinary = WarpPortableWordLowerer.Lower(program.Graph, program.Typed);
        rows.Add(DescribeProfile("ordinary", ordinary.Kernel, 0x57425036, directory));
        // Compile fresh exact old conditional plans using these actual Root DLLs;
        // no historical DLL is borrowed and no historical hash PASS is inferred.
        foreach (bool boundary in new[] { false, true })
        {
            WarpPortableWordLoweredProgram previous = WarpPortableWordLowerer.Lower(program.Graph, program.Typed, program.Schema,
                new HelperBinding(program.Graph, program.Typed, program.Schema, program.PayloadWords, program.ServiceWords,
                    program.Nested, fenced: false, boundaries: boundary));
            WarpPortableWordProgramIdentity.Validate(program.Graph, program.Schema, previous);
            rows.Add(DescribeProfile(boundary ? "private-entry0.8" : "private-projection0.7", previous.Kernel, 0x57425036, directory));
        }
        Evidence.Write(Path.Combine(directory, "conditional-profiles.json"), new { Rows = rows,
            Scope = "Round-trip exact conditional identities from this production boundary; historical hash invariance needs Root's independent pre/post identity join" });
    }

    private static object DescribeProfile(string name, WarpControlFlowKernel kernel, uint magic, string directory)
    {
        string hash = WarpIrHash.Compute(kernel); byte[] bytes = WarpCoreCLRBinaryPlanCodec.Serialize(kernel);
        Evidence.Require(BinaryPrimitives.ReadUInt32LittleEndian(bytes) == magic, "Explicit conditional wire magic");
        WarpControlFlowKernel decoded = WarpCoreCLRBinaryPlanCodec.Deserialize(bytes, hash);
        Evidence.Require(string.Equals(hash, WarpIrHash.Compute(decoded), StringComparison.Ordinal) &&
            bytes.AsSpan().SequenceEqual(WarpCoreCLRBinaryPlanCodec.Serialize(decoded)), "Conditional hash/byte round trip");
        string path = Path.Combine(directory, name + ".word-plan.bin"); File.WriteAllBytes(path, bytes);
        return new { name, path, Sha256 = Evidence.Hash(bytes), IrHash = hash, Metadata = kernel.Execution!.IdentityVersion,
            HasPrivateProjection = kernel.Execution!.PrivateControllerProjection is not null,
            Fenced = kernel.Execution!.PrivateControllerProjection?.RequiresHelperReturnFences == true };
    }
}
