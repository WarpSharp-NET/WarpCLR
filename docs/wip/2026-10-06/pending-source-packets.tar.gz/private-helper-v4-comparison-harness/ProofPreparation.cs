using System.Reflection;
using System.Runtime.InteropServices;
using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal static class ProofPreparation
{
    internal static void Run(string inputPath, string seedPath, string output, RootInputs inputs)
    {
        if (Directory.Exists(output)) { throw new IOException("Proof output must be a fresh retained boundary."); }
        Directory.CreateDirectory(output);
        ProfileRequirements.Require();
        SeedInventory seeds = SeedInventory.Read(seedPath);
        var completed = new List<object>();
        Evidence.Write(Path.Combine(output, "input-identity.json"), new { inputs.ProductionGateLabel,
            InputsPath = Path.GetFullPath(inputPath), InputsSha256 = Evidence.Hash(File.ReadAllBytes(inputPath)),
            SeedPath = Path.GetFullPath(seedPath), SeedSha256 = Evidence.Hash(File.ReadAllBytes(seedPath)), inputs });
        try
        {
            foreach (var spec in new[] {
                (Name: "CapturedUInt32Echo_Service1", Method: "Echo", Payload: 1, Words: 1, Nested: false),
                (Name: "CapturedUInt64Echo_Service2", Method: "Wide", Payload: 2, Words: 2, Nested: false),
                (Name: "CapturedVoidEmpty_Service0", Method: "Empty", Payload: 0, Words: 0, Nested: false),
                (Name: "CapturedUInt32Echo_NestedService4", Method: "Echo", Payload: 1, Words: 4, Nested: true) })
            {
                string directory = Path.Combine(output, spec.Name); Directory.CreateDirectory(directory);
                Evidence.Write(Path.Combine(directory, "requested-source-plan.json"), new { spec.Name, spec.Method, spec.Payload, spec.Words, spec.Nested,
                    VoidCallAdmissionSeam = spec.Words == 0 ? "Context.Call Result=-1 must be admitted as an exact zero-width private call identity by Root's explicit production correction" : null });
                ProofProgram program = ProofProgram.Create(spec.Name, spec.Method, spec.Payload, spec.Words, spec.Nested);
                completed.Add(RunProgram(program, seeds, directory));
                Evidence.Write(Path.Combine(output, "core-partial.json"), completed);
            }
            VerifyLoadedReferences(inputs);
            Evidence.Write(Path.Combine(output, "core-result.json"), new { Status = "CORE_PREPARATION_COMPLETE_CPU_COMPARISONS_PENDING",
                Programs = completed, Runtime = RuntimeInformation.FrameworkDescription, Architecture = RuntimeInformation.ProcessArchitecture.ToString(),
                HostPid = Environment.ProcessId, GPU = false, PrivateRpc = false, Authority = false });
        }
        catch (Exception error)
        {
            Evidence.Write(Path.Combine(output, "preparation-failure.json"), new { error = error.ToString(), Completed = completed,
                Scope = "Retain complete input/bank files; no partial overall PASS or fallback plan" });
            throw;
        }
    }

    private static object RunProgram(ProofProgram program, SeedInventory seeds, string directory)
    {
        Evidence.Write(Path.Combine(directory, "program.json"), program.Describe());
        ProgramArtifacts.Write(program, directory);
        uint[] initial = seeds.Initial(program);
        object initialBank = Evidence.Bank(Path.Combine(directory, "initial.bank"), initial, [], []);
        var writer = new ComparisonVectors(program, seeds, directory);
        for (int seed = 0; seed < seeds.RawWords.Length; seed++)
        {
            GeneratedCheckpoints scopes = ScopeSeeds.Capture(program, seeds, writer, initial, seed);
            foreach (int quantum in seeds.Quanta(program))
            {
                TraceCases.Run(program, seeds, writer, initial, seed, quantum);
                InvalidCases.Run(program, seeds, writer, scopes, seed, quantum);
            }
        }
        writer.Complete();
        return new { program.Name, Initial = initialBank, Count = writer.Count,
            Quanta = seeds.Quanta(program), SharedNamespace = initial[WarpLogicalMachineLayout.OwnerContextOffset] };
    }

    private static void VerifyLoadedReferences(RootInputs inputs)
    {
        foreach ((string name, ReferenceInput expected) in inputs.Assemblies)
        {
            System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromAssemblyPath(expected.Path);
            Assembly actual = AppDomain.CurrentDomain.GetAssemblies().Single(assembly =>
                string.Equals(assembly.GetName().Name, name, StringComparison.Ordinal));
            Evidence.Require(string.Equals(Path.GetFullPath(actual.Location), Path.GetFullPath(expected.Path), StringComparison.Ordinal) &&
                string.Equals(Evidence.Hash(File.ReadAllBytes(actual.Location)), expected.Sha256, StringComparison.OrdinalIgnoreCase),
                "Loaded future production reference path/bytes: " + name);
        }
    }
}
