using System.Reflection;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.V4Proof;

internal sealed record ProofProgram(string Name, int PayloadWords, int ServiceWords, bool Nested,
    MethodInfo Source, WarpPortableMethodGraph Graph, WarpPortableTypedProgram Typed,
    WarpPortableSourceHeapSchema Schema, WarpPortableWordLoweredProgram Lowered,
    WarpLogicalMachineLayout Layout, CoreCLRResumableKernel Compiled)
{
    internal static ProofProgram Create(string name, string method, int payloadWords, int serviceWords, bool nested)
    {
        MethodInfo source = typeof(SourceKernels).GetMethod(method, BindingFlags.Public | BindingFlags.Static)
            ?? throw new InvalidDataException("The original proof CIL method is absent.");
        byte[] cil = source.GetMethodBody()?.GetILAsByteArray() ?? throw new InvalidDataException("Original CIL is absent.");
        byte[] expected = payloadWords == 0 ? [0x2A] : [0x02, 0x2A];
        Evidence.Require(cil.AsSpan().SequenceEqual(expected), "Exact original Release CIL (genuine Ret has positive charge)");
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
        WarpPortableWordLoweredProgram lowered = WarpPortableWordLowerer.Lower(graph, typed, schema,
            new HelperBinding(graph, typed, schema, payloadWords, serviceWords, nested));
        WarpPortableWordProgramIdentity identity = WarpPortableWordProgramIdentity.Validate(graph, schema, lowered);
        Evidence.Require(string.Equals(identity.IdentityVersion, WarpPortableWordProgramIdentity.PrivateHelperReturnFenceVersion,
            StringComparison.Ordinal), "Compiler CWT-sealed new conditional consistency identity");
        var layout = new WarpLogicalMachineLayout(lowered.Kernel);
        Evidence.Require(layout.HasPrivateHelperReturnFences && layout.PrivateHelperReturnSites.Count == 1, "One exact private call scope");
        Evidence.Require(layout.ResultWordCount == payloadWords && layout.PrivateHelperReturnSites[0].ResultWordCount == serviceWords,
            "Exact source and helper tuple widths (raw wide transport)");
        Evidence.Require(layout.Kernel.ScalarArgumentCount == 1, "One physical UInt32 controller consistency channel");
        return new(name, payloadWords, serviceWords, nested, source, graph, typed, schema, lowered, layout,
            CoreCLRResumableKernel.Compile(layout));
    }

    internal void Invoke(uint[] state, uint[] arena, uint[][] inputs, uint controller, int quantum, int maximumDepth) =>
        Compiled.CompiledEntryPoint.Invoke(null, [inputs, new uint[] { controller }, 0, state, maximumDepth,
            quantum, CancellationToken.None, arena]);

    internal object Describe() => new
    {
        Name, PayloadWords, ServiceWords, Nested, IrHash = WarpIrHash.Compute(Layout.Kernel),
        GraphHash = Graph.GraphHash, TypedHash = Typed.VerifiedHash, SchemaHash = Schema.SchemaHash,
        CompilerIdentity = Lowered.CompilerIdentity!.IdentityHash, CompilerVersion = Lowered.CompilerIdentity!.IdentityVersion,
        MetadataVersion = Layout.Kernel.Execution!.IdentityVersion, ScopeVersion = WarpLogicalMachineLayout.PrivateHelperScopeVersion,
        Layout.FrameWords, Layout.PrivateOffset, Layout.MaximumBlockCost, Layout.ResultWordCount, Layout.PrivateHelperReturnSites,
        Lowered.MapsHash, Lowered.RequiredServices, SourceBodies = Lowered.Bodies, EntryProjection = Lowered.EntryProjection,
        BodyMetadata = Layout.Kernel.Execution!.Bodies.Select(body => new { body.PrivateWordCount, body.RuntimeHelper, body.CountsSourceDepth,
            body.AliasOwnerFunction, body.AliasPrefixWords, Costs = body.SourceBlockCosts.ToArray() }).ToArray(),
        SourceAliasMetadata = Lowered.Bodies.Select(body => new { body.Function, body.AliasOwnerFunction, body.AliasPrefixWords,
            body.StoragePrefixWords, body.PrivateTemporaries }).ToArray(),
        InputCount = Layout.Kernel.InputBufferCount, ScalarCount = Layout.Kernel.ScalarArgumentCount, Layout.RequiresManagedMemory,
        Source = new { Signature = Source.ToString(), Source.MetadataToken, Mvid = Source.Module.ModuleVersionId,
            ModulePath = Source.Module.FullyQualifiedName, ModuleSha256 = Evidence.Hash(File.ReadAllBytes(Source.Module.FullyQualifiedName)),
            Cil = Convert.ToHexString(Source.GetMethodBody()!.GetILAsByteArray()!),
            CilSha256 = Evidence.Hash(Source.GetMethodBody()!.GetILAsByteArray()!) },
        Generated = new { Token = Compiled.CompiledEntryPoint.MetadataToken, Mvid = Compiled.CompiledEntryPoint.Module.ModuleVersionId,
            Collectible = Compiled.IsCollectible, Assembly = Compiled.CompiledEntryPoint.Module.Assembly.FullName },
        CwtIdentityIsExecutionAuthority = false,
    };
}
