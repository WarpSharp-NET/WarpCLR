using WarpCLR.IR;

namespace WarpCLR.Tests.V4Proof;

internal static class InvalidCases
{
    internal static void Run(ProofProgram program, SeedInventory seeds, ComparisonVectors writer,
        GeneratedCheckpoints scopes, int seed, int quantum)
    {
        foreach ((string name, Action<ProofBanks> mutation) in BridgeMutations(program))
        { Block(program, writer, scopes.BeforeHelper, name, mutation, seed, quantum, seeds.ControllerWord); }
        foreach (ProofBanks original in new[] { scopes.OuterActive, scopes.Publication })
        {
            foreach ((string name, Action<ProofBanks> mutation) in ScopeMutations(program, original))
            {
                string phase = original.State[15] == WarpLogicalMachineLayout.AwaitingRootRelease ? "publication" : "active";
                Block(program, writer, original, phase + "-" + name, mutation, seed, quantum, seeds.ControllerWord);
            }
        }
        if (scopes.NestedActive is { } nested)
        {
            foreach ((string name, Action<ProofBanks> mutation) in NestedMutations(program, nested))
            { Block(program, writer, nested, "nested-" + name, mutation, seed, quantum, seeds.ControllerWord); }
        }
        writer.RefusedAcknowledgment("release-ack-at-before-helper-is-denied", scopes.BeforeHelper.Copy(), seed, quantum,
            state => program.Layout.AcknowledgePrivateHelperRelease(state));
        ProofBanks acknowledged = scopes.Publication.Copy();
        writer.Acknowledge("negative-case-synthetic-5-to-6", acknowledged, seed, quantum,
            state => program.Layout.AcknowledgePrivateHelperRelease(state));
        writer.RefusedAcknowledgment("repeated-release-ack-is-denied", acknowledged, seed, quantum,
            state => program.Layout.AcknowledgePrivateHelperRelease(state));
        writer.RefusedAcknowledgment("release-admission-with-stale-controller-is-denied", acknowledged, seed, quantum,
            state => program.Layout.RequireAcknowledgedPrivateHelperRelease(state, seeds.ControllerWord));
    }

    private static void Block(ProofProgram program, ComparisonVectors writer, ProofBanks original, string name,
        Action<ProofBanks> mutation, int seed, int quantum, uint scalar)
    {
        ProofBanks malformed = original.Copy(); mutation(malformed);
        bool rejectedByLayout = !program.Layout.HasValidRuntimeHeader(malformed.State);
        writer.Step("malformed-" + name, malformed, scalar, quantum, seed, unchanged: true);
        Evidence.Require(rejectedByLayout, "Narrow consistency validator also rejects malformed complete scope: " + name);
    }

    private static IEnumerable<(string Name, Action<ProofBanks> Change)> BridgeMutations(ProofProgram program)
    {
        int Frame(ProofBanks bank) => checked(64 + ((int)bank.State[6] - 1) * program.Layout.FrameWords);
        yield return ("mode2", bank => bank.State[14] = 2);
        yield return ("mode0-with-phase3", bank => bank.State[14] = 0);
        yield return ("phase7", bank => bank.State[15] = 7);
        yield return ("wrong-dispatch-pc", bank => bank.State[Frame(bank) + 1] = uint.MaxValue);
        yield return ("wrong-caller-function", bank => bank.State[Frame(bank)] = uint.MaxValue);
        yield return ("zero-namespace", bank => bank.State[12] = 0);
        yield return ("zero-next-activation", bank => bank.State[13] = 0);
        yield return ("zero-caller-activation", bank => bank.State[Frame(bank) + 4] = 0);
        yield return ("stale-caller-activation", bank => bank.State[Frame(bank) + 4] = bank.State[13] + 1);
        yield return ("unexpected-alias-depth", bank => bank.State[Frame(bank) + 6] = 1);
        yield return ("unexpected-alias-activation", bank => bank.State[Frame(bank) + 7] = 1);
        yield return ("wrong-frame-stride", bank => bank.State[16]++);
        yield return ("wrong-private-base", bank => bank.State[17]++);
        yield return ("leftover-scope-without-tag", bank => bank.State[30] = 1);
    }

    private static IEnumerable<(string Name, Action<ProofBanks> Change)> ScopeMutations(ProofProgram program, ProofBanks original)
    {
        int caller = checked(64 + ((int)original.State[29] - 1) * program.Layout.FrameWords);
        int outer = caller + program.Layout.FrameWords;
        yield return ("mode2", bank => bank.State[14] = 2);
        yield return ("mode0-with-active-scope", bank => bank.State[14] = 0);
        yield return ("unknown-call-tag", bank => bank.State[28] = uint.MaxValue);
        yield return ("tag-erased-only", bank => bank.State[28] = 0);
        yield return ("whole-active-scope-erased", bank => bank.State.AsSpan(28, 4).Clear());
        yield return ("caller-depth0", bank => bank.State[29] = 0);
        yield return ("caller-depth-overflow", bank => bank.State[29] = uint.MaxValue);
        yield return ("caller-function", bank => bank.State[caller] = uint.MaxValue);
        yield return ("caller-pc", bank => bank.State[caller + 1] = uint.MaxValue);
        yield return ("caller-activation-binding", bank => bank.State[30]++);
        yield return ("helper-activation-binding", bank => bank.State[31]++);
        yield return ("caller-frame-activation0", bank => bank.State[caller + 4] = 0);
        yield return ("outer-activation-duplicates-caller", bank => bank.State[outer + 4] = bank.State[caller + 4]);
        yield return ("outer-helper-function", bank => bank.State[outer] = uint.MaxValue);
        yield return ("outer-return-value-coordinate", bank => bank.State[outer + 2]++);
        yield return ("outer-return-word-count", bank => bank.State[outer + 3]++);
        yield return ("outer-private-count", bank => bank.State[outer + 5] = 1);
        yield return ("outer-alias-depth", bank => bank.State[outer + 6] = 1);
        yield return ("outer-alias-activation", bank => bank.State[outer + 7] = 1);
        yield return ("phase3-wrong-active-site", bank => bank.State[15] = 3);
        yield return ("phase4-wrong-active-site", bank => bank.State[15] = 4);
        yield return ("phase7", bank => bank.State[15] = 7);
        yield return ("zero-namespace", bank => bank.State[12] = 0);
        yield return ("zero-next-activation", bank => bank.State[13] = 0);
        yield return ("managed-exception-ref-without-terminal", bank => bank.State[25] = 1);
        if (original.State[15] == 0)
        { yield return ("publication-phase-at-helper-depth", bank => bank.State[15] = 5); }
        else
        { yield return ("publication-phase-erased-at-caller-depth", bank => bank.State[15] = 0); }
    }

    private static IEnumerable<(string Name, Action<ProofBanks> Change)> NestedMutations(ProofProgram program, ProofBanks original)
    {
        int frame = checked(64 + ((int)original.State[6] - 1) * program.Layout.FrameWords);
        int parent = frame - program.Layout.FrameWords;
        yield return ("return-value", bank => bank.State[frame + 2]++);
        yield return ("return-word-count", bank => bank.State[frame + 3]++);
        yield return ("parent-continuation", bank => bank.State[parent + 1] = uint.MaxValue);
        yield return ("function-outside-pure-closure", bank => bank.State[frame] = 0);
        yield return ("activation-duplicates-parent", bank => bank.State[frame + 4] = bank.State[parent + 4]);
        yield return ("nested-alias-depth", bank => bank.State[frame + 6] = 1);
        yield return ("nested-alias-activation", bank => bank.State[frame + 7] = 1);
    }
}
