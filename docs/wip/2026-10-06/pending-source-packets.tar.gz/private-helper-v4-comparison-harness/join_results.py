"""Independent full-bank and same-seed/type/source/image join after Root execution."""
import argparse
import hashlib
import json
import pathlib
from bank_format import difference, read_bank, sha, write_json

PROGRAMS = ["CapturedUInt32Echo_Service1", "CapturedUInt64Echo_Service2", "CapturedVoidEmpty_Service0", "CapturedUInt32Echo_NestedService4"]
DIALECTS = ["NVPTX", "AMDGPU", "SPIRV"]


def require(condition, label):
    if not condition:
        raise AssertionError(label)


def validate_reference(row):
    require(pathlib.Path(row["path"]).is_absolute() and sha(row["path"]).lower() == row["sha256"].lower(), "Input reference bytes differ")


def join_program(root, name, seeds_path, tools_path):
    program_path = root / "core" / name
    program = json.loads((program_path / "program.json").read_text())
    vectors_path = program_path / "vectors.json"
    vectors = json.loads(vectors_path.read_text())
    expected = [(i, row) for i, row in enumerate(vectors["rows"]) if row["nativeComparable"]]
    require(expected, "No actual native-comparable generated Core row")
    source = program["source"]
    validate_reference({"path": source["modulePath"], "sha256": source["moduleSha256"]})
    require(sha(program_path / "initial.bank") != "", "Persisted single initial state is absent")
    expected_words = 0
    for ordinal, row in expected:
        require(row["invocationFailure"] is None and row["irHash"] == program["irHash"], "Core row identity/failure differs")
        before, after = read_bank(row["pre"]), read_bank(row["post"])
        if row["expectUnchanged"]:
            require(difference(before, after) is None, "Malformed/parked expected bank was mutated")
        expected_words += len(after[0]) + len(after[1]) + sum(map(len, after[2]))
    records = []
    witness_hashes = []
    for dialect in DIALECTS:
        target = root / "cpu-images" / name / dialect
        comparison = root / "comparisons" / name / dialect
        result = json.loads((comparison / "result.json").read_text())
        retarget = json.loads((target / "retarget.json").read_text())
        image = json.loads((target / "image.json").read_text())
        require(result["status"] == "OFFLINE_CPU_COMPLETE" and result["dialect"] == dialect and result["program"] == name,
                "Actual CPU run did not complete exactly")
        require(result["vectorsSha256"] == sha(vectors_path) and result["seedsSha256"] == sha(seeds_path) and
                result["initialBankSha256"] == sha(program_path / "initial.bank"), "Global seed and complete vector identity differ")
        require(result["imageSha256"] == image["imageSha256"] == sha(target / "cpu.so"), "CPU executable bytes differ")
        require(image["objectSha256"] == sha(target / "cpu.o") and image["cpuSourceSha256"] == sha(target / "cpu.ll"), "CPU object/source identity differs")
        require(image["retargetSha256"] == sha(target / "retarget.json") and image["toolsSha256"] == sha(tools_path), "Named actual retarget/tool identity differs")
        require(retarget["programIdentitySha256"] == image["programSha256"] == sha(program_path / "program.json") and
                retarget["commonIrHash"] == result["commonIrHash"] == program["irHash"], "Exact common IR/type/compiler identity differs")
        require(len(result["rows"]) == len(expected) == result["comparisons"], "Some expected complete banks were omitted")
        witness = hashlib.sha256()
        for (ordinal, core), native in zip(expected, result["rows"], strict=True):
            require(native["ordinal"] == ordinal and native["corePre"] == core["pre"] and native["corePost"] == core["post"],
                    "Native run did not use the identical frozen Core pre/post banks")
            require(native["seed"] == core["seed"] and native["quantum"] == core["quantum"] and native["scalar"] == core["scalar"],
                    "Physical seed/quantum/uint scalar differs")
            require(difference(read_bank(core["post"]), read_bank(native["nativePost"])) is None, "Independent whole-bank equality failed")
            require(native["wholeBanksEqual"] and native["difference"] is None, "Comparison falsely reports success")
            witness.update(bytes.fromhex(native["nativePost"]["sha256"]))
        require(result["completeWordsCompared"] == expected_words, "Complete word comparison count differs")
        witness_hashes.append(witness.hexdigest())
        records.append({"dialect": dialect, "comparisons": len(expected), "words": expected_words,
                        "imageSha256": image["imageSha256"], "resultSha256": sha(comparison / "result.json"),
                        "identicalSeedWitnessSha256": witness.hexdigest()})
    require(len(set(witness_hashes)) == 1, "Cross-dialect identical raw initial-seed and complete-bank witness differs")
    return {"program": name, "commonIrHash": program["irHash"], "graphHash": program["graphHash"],
            "typedHash": program["typedHash"], "source": source, "initialBankSha256": sha(program_path / "initial.bank"), "dialects": records}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", required=True, type=pathlib.Path)
    parser.add_argument("--seeds", required=True, type=pathlib.Path)
    parser.add_argument("--root-inputs", required=True, type=pathlib.Path)
    parser.add_argument("--tools", required=True, type=pathlib.Path)
    args = parser.parse_args()
    result_path = args.evidence / "independent-join.json"
    if result_path.exists():
        raise FileExistsError("A retained join result cannot be overwritten")
    try:
        inputs = json.loads(args.root_inputs.read_text())
        for row in list(inputs["assemblies"].values()) + [inputs["productionSourceReceipt"], inputs["productionArtifactReceipt"]]:
            validate_reference(row)
        core = json.loads((args.evidence / "core" / "core-result.json").read_text())
        require(core["status"] == "CORE_PREPARATION_COMPLETE_CPU_COMPARISONS_PENDING" and len(core["programs"]) == 4, "All four genuine original source plans are required")
        identity = json.loads((args.evidence / "core" / "input-identity.json").read_text())
        require(identity["inputsSha256"] == sha(args.root_inputs) and identity["seedSha256"] == sha(args.seeds), "Future production and seed input identity differs")
        rows = [join_program(args.evidence, name, args.seeds, args.tools) for name in PROGRAMS]
        write_json(result_path, {"status": "COMPLETE_OFFLINE_CPU_WHOLE_BANK_JOIN", "programs": rows, "cpuImages": 12,
                   "comparisons": sum(d["comparisons"] for row in rows for d in row["dialects"]),
                   "completeWordsCompared": sum(d["words"] for row in rows for d in row["dialects"]),
                   "rootInputsSha256": sha(args.root_inputs), "toolsSha256": sha(args.tools), "seedsSha256": sha(args.seeds),
                   "productionGateLabel": inputs["productionGateLabel"], "deviceImages": 0, "gpu": False, "privateRpc": False, "authority": False,
                   "limits": "Controlled generated Core reflection and direct native CPU calls; synthetic phase acknowledgments are not Root publication/release. Root must join actual bounded-command/producer-stop receipts separately."})
    except Exception as error:
        write_json(args.evidence / "independent-join-failure.json", {"status": "RETAINED_FAILED_JOIN_NO_PASS", "error": repr(error)})
        raise


if __name__ == "__main__":
    main()
