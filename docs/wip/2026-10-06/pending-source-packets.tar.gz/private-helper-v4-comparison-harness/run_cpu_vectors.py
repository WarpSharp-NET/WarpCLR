"""Direct native CPU entry ABI comparison; no CIL/opcode interpreter or authority."""
import argparse
import ctypes
import json
import pathlib
import os
import platform
import time
from bank_format import difference, read_bank, sha, write_bank, write_json


def pin(words):
    return (ctypes.c_uint32 * max(1, len(words)))(*words)


def entry(library, program):
    image = ctypes.CDLL(str(library.resolve()))
    kernel = getattr(image, "warp_resume")
    pointers = [ctypes.POINTER(ctypes.c_uint32)] * (1 + program["inputCount"])
    numbers = [ctypes.c_uint32] * (program["scalarCount"] + 4)
    tail = [ctypes.POINTER(ctypes.c_uint32), ctypes.c_uint32] if program["requiresManagedMemory"] else []
    kernel.argtypes = pointers + numbers + tail
    kernel.restype = None
    return image, kernel


def execute(kernel, program, bank, scalar, quantum, maximum_depth):
    state, arena, inputs = bank
    state_pin, arena_pin = pin(state), pin(arena)
    input_pins = [pin(words) for words in inputs]
    if program["scalarCount"] != 1 or len(inputs) != program["inputCount"] or any(len(words) != 1 for words in inputs):
        raise ValueError("Exact one-worker one-controller raw ABI differs")
    arguments = [state_pin] + input_pins + [scalar, 1, 0, maximum_depth, quantum]
    if program["requiresManagedMemory"]:
        arguments += [arena_pin, len(arena)]
    kernel(*arguments)
    return list(state_pin)[:len(state)], list(arena_pin)[:len(arena)], [list(pin_)[:len(words)] for pin_, words in zip(input_pins, inputs, strict=True)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--program", required=True, type=pathlib.Path)
    parser.add_argument("--cpu-directory", required=True, type=pathlib.Path)
    parser.add_argument("--tools", required=True, type=pathlib.Path)
    parser.add_argument("--seeds", required=True, type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("CPU comparison evidence must be a fresh retained boundary")
    args.output.mkdir(parents=True)
    program_path = args.program.resolve()
    program = json.loads((program_path / "program.json").read_text())
    vectors = json.loads((program_path / "vectors.json").read_text())
    retarget = json.loads((args.cpu_directory / "retarget.json").read_text())
    image_receipt = json.loads((args.cpu_directory / "image.json").read_text())
    image = args.cpu_directory / "cpu.so"
    if image_receipt["imageSha256"] != sha(image) or image_receipt["retargetSha256"] != sha(args.cpu_directory / "retarget.json"):
        raise ValueError("Exact admitted CPU image/retarget join failed")
    if retarget["commonIrHash"] != program["irHash"] or image_receipt["commonIrHash"] != program["irHash"]:
        raise ValueError("CPU image/common IR differs")
    if image_receipt["toolsSha256"] != sha(args.tools) or image_receipt["programSha256"] != sha(program_path / "program.json"):
        raise ValueError("Actual compiler tools/program receipt differs")
    if retarget["programIdentitySha256"] != sha(program_path / "program.json"):
        raise ValueError("Source type/tuple/compiler identity differs")
    seeds = json.loads(args.seeds.read_text())
    module, kernel = entry(image, program)
    rows = []
    started = time.monotonic()
    try:
        for ordinal, row in enumerate(vectors["rows"]):
            if not row["nativeComparable"]:
                continue
            if row["irHash"] != program["irHash"] or row["invocationFailure"] is not None:
                raise ValueError("Failed or differently bound Core row cannot become a CPU expected-side oracle")
            before = read_bank(row["pre"])
            expected = read_bank(row["post"])
            actual = execute(kernel, program, before, row["scalar"], row["quantum"], seeds["maximumLogicalDepth"])
            path = args.output / (f"step{ordinal:06d}.native.post.bank")
            complete_bank = write_bank(path, *actual)
            mismatch = difference(expected, actual)
            witness = {"ordinal": ordinal, "name": row["name"], "seed": row["seed"], "quantum": row["quantum"],
                       "scalar": row["scalar"], "corePre": row["pre"], "corePost": row["post"], "nativePost": complete_bank,
                       "wholeBanksEqual": mismatch is None, "difference": mismatch, "commonIrHash": program["irHash"]}
            write_json(args.output / (f"step{ordinal:06d}.comparison.json"), witness)
            rows.append(witness)
            if mismatch is not None:
                raise AssertionError("Whole State/Arena/input bank mismatch (full expected and actual retained)")
        write_json(args.output / "result.json", {"status": "OFFLINE_CPU_COMPLETE", "rows": rows,
                   "comparisons": len(rows), "completeWordsCompared": sum(r["corePost"]["stateWords"] + r["corePost"]["arenaWords"] + sum(r["corePost"]["inputLengths"]) for r in rows),
                   "dialect": retarget["dialect"], "program": program["name"], "commonIrHash": program["irHash"],
                   "imageSha256": sha(image), "vectorsSha256": sha(program_path / "vectors.json"),
                   "seedsSha256": sha(args.seeds), "initialBankSha256": sha(program_path / "initial.bank"),
                   "inputIdentitySha256": sha(program_path.parent / "input-identity.json"),
                   "pid": os.getpid(), "architecture": platform.machine(), "seconds": time.monotonic() - started,
                   "gpu": False, "privateRpc": False, "authority": False})
    except Exception as error:
        write_json(args.output / "failure.json", {"error": repr(error), "completed": rows, "pid": os.getpid(),
                   "imageSha256": sha(image), "status": "RETAINED_INCOMPLETE_FAILURE_NO_PASS"})
        raise
    finally:
        del kernel, module


if __name__ == "__main__":
    main()
