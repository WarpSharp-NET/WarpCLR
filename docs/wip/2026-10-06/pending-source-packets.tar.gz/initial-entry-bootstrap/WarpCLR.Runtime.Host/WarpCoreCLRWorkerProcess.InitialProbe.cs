using System.Security.Cryptography;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCoreCLRWorkerProcess
{
    internal static uint[][] CaptureProbeInputs(WarpOrdinaryArrayAdmission admission, int count) =>
        CaptureOrdinaryInputs(admission, count);

    internal const string InitialProbeSemantics = "warp.coreclr.host/ordinary-unheld-complete-kind19-initial-emitted-entry-no-wordcheckpoint-no-execution-permission/0.1";

    internal static long InitialProbeTransferBytes(long requestBytes, int stateWords, int arenaWords)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(requestBytes);
        WarpCoreCLRInitialEntryProbeWords.RequireResponseCapacity(stateWords, arenaWords);
        return checked(requestBytes * 8 + 4096 + WarpCoreCLRInitialEntryProbeWords.TrailerBytes * 8);
    }

    internal async Task<InitialProbeCheckpoint> ProbeInitialEntryAsync(WarpLogicalMachineLayout layout,
        uint[][] inputs, uint[] carrier, int worker, uint[] state, int depth, int quantum, uint[] arena,
        CancellationToken cancellationToken)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, lifetimeToken);
        deadline.CancelAfter(options.QuantumTimeout);
        WarpOrdinaryArrayAdmission? ordinary = null;
        WarpCoreCLRWordTransaction.Lease? buffers = null;
        WarpCoreCLRAsyncGate.Lease? transaction = null;
        WarpCoreCLRTransferAdmission.Lease? storage = null;
        WarpCoreCLRStoppedCommands.Command? command = null;
        try
        {
            ordinary = WarpOrdinaryArrayAdmission.Acquire(inputs, carrier, state, arena);
            uint[][] captured = CaptureOrdinaryInputs(ordinary, inputs.Length);
            buffers = await WarpCoreCLRWordTransaction.AcquireAsync(state, arena, deadline.Token).ConfigureAwait(false);
            ValidateAliases(captured, carrier, state, arena);
            if (carrier.Length != 1 || carrier[0] != 0 ||
                !string.Equals(WarpIrHash.Compute(layout.Kernel), IrHash, StringComparison.Ordinal))
            { throw new InvalidOperationException("The probe requires exact raw [0] and the actual compiled plan."); }
            transaction = await transactions.AcquireAsync(deadline.Token).ConfigureAwait(false);
            long bytes = WarpCoreCLRWorkerWords.Estimate(captured, carrier, state, arena);
            storage = await WarpCoreCLRTransferAdmission.AcquireAsync(
                InitialProbeTransferBytes(bytes, state.Length, arena.Length), deadline.Token).ConfigureAwait(false);
            byte[] request = WarpCoreCLRWorkerWords.Request(captured, carrier, worker, state, depth, quantum, arena);
            (ulong _, WarpCoreCLRStoppedCommands.Command started) = BeginWordCommand(request, state, arena, null, captured, carrier,
                null, false, null, deadline.Token, WarpCoreCLRInitialEntryProbeWords.Probe);
            command = started;
            await WarpCoreCLRWorkerProtocol.WriteAsync(process.StandardInput.BaseStream, key, command.RequestKind,
                command.Sequence, request, deadline.Token).ConfigureAwait(false);
            WarpCoreCLRWorkerProtocol.Frame frame = await WarpCoreCLRWorkerProtocol.ReadAsync(process.StandardOutput.BaseStream,
                key, command.Sequence, deadline.Token).ConfigureAwait(false);
            WarpCoreCLRAuthenticatedResponse authenticated = WarpCoreCLRAuthenticatedResponse.Capture(frame, key,
                command.ResponseKind, command.Sequence, out byte[] response);
            var result = WarpCoreCLRInitialEntryProbeWords.ReadResponse(response, request, state.Length, arena.Length,
                CompiledModule, layout.GetBlockEntry(0, 0));
            probes?.BeforeResultPublication?.Invoke();
            lock (sync)
            {
                if (faulted) { throw new InvalidOperationException("A quarantined child cannot publish an initial entry receipt."); }
                deadline.Token.ThrowIfCancellationRequested();
                byte[] after = WarpCoreCLRWorkerWords.Request(captured, carrier, worker, state, depth, quantum, arena);
                if (!CryptographicOperations.FixedTimeEquals(after, request) ||
                    !result.State.AsSpan().SequenceEqual(state) || !result.Arena.AsSpan().SequenceEqual(arena))
                { throw new InvalidDataException("An initial entry probe changed an original or returned word bank."); }
                // Transfer only the retained request/frame working-storage lease.
                // No mutable word is copied back and no WordCheckpoint is issued.
                storage.Retain(checked(request.LongLength + response.LongLength + captured.LongLength * IntPtr.Size + 2048));
                InitialProbeCheckpoint receipt = PrepareInitialProbeCheckpoint(command, layout, inputs, captured, carrier,
                    authenticated, request, response, storage);
                storage = null;
                Committed(command, null, null);
                return receipt;
            }
        }
        catch (Exception error)
        {
            Exception cause = command is null ? error : await StopOwnedCommandAsync(error, state, arena, command).ConfigureAwait(false);
            throw WordFailure(cause, command, cancellationToken);
        }
        finally
        {
            try { storage?.Dispose(); transaction?.Dispose(); buffers?.Dispose(); }
            finally { ordinary?.Dispose(); }
        }
    }
}
