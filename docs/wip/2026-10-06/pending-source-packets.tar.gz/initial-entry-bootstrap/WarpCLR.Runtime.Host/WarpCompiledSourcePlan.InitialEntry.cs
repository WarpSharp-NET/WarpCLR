using WarpCLR.Compiler;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourcePlan
{
    internal WarpCompiledInitialEntryProjection CaptureInitialEntryProjection()
    {
        // Inventories and matching hash strings alone cannot authenticate a plan.
        RequireCompletionCompilerSeal();
        WarpPortableSourceInvocation invocation = WarpPortableSourceSegmentMap.Capture(completionGraph, TypeSchema, Program).Invocation;
        if (invocation.OriginKind != 2 || invocation.SourceOffset is not null || invocation.SourceOpCode is not null ||
            invocation.EffectIndex is not null || !invocation.Effects.IsEmpty || !invocation.ExceptionMemberships.IsEmpty ||
            !bodies.TryGetValue(invocation.Function, out WarpPortableWordBody? body) ||
            !string.Equals(body.MethodIdentity, completionGraph.EntryIdentity, StringComparison.Ordinal) ||
            !string.Equals(invocation.MethodIdentity, body.MethodIdentity, StringComparison.Ordinal) ||
            invocation.EntryProgramCounter != Layout.GetBlockEntry(0, 0) ||
            !invocation.LocalProgramCounters.Contains(invocation.EntryProgramCounter))
        { throw new InvalidOperationException("The initial projection must identify the exact final root invocation without fabricated CIL or EH data."); }
        var entry = Layout.Nodes[invocation.EntryProgramCounter];
        var sourceEntry = Layout.Nodes[Layout.GetBlockEntry(body.Function, 0)];
        if (entry.Function != 0 || entry.SourceCost != 0 || sourceEntry.Function != body.Function)
        { throw new InvalidOperationException("The final machine entry must precede the separately captured source body."); }
        return new(CompilerIdentity, invocation, entry, body, sourceEntry);
    }
}
