using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    private readonly ConditionalWeakTable<uint[], byte[]> initialProbeStates = new();
    private readonly ConditionalWeakTable<WarpCompiledWorkerTicket, InitialProbeAttempt> initialProbeAttempts = new();
    private readonly ConditionalWeakTable<WarpCompiledWorkerTicket, InitialBeforeBodyReceipt> initialProbeReceipts = new();
    private bool initialProbeInFlight;

    private void RememberInitialProbeState(uint[] state) =>
        initialProbeStates.Add(state, SHA256.HashData(MemoryMarshal.AsBytes(state.AsSpan())));

    internal async Task<InitialBeforeBodyReceipt> ProbeInitialBeforeBodyAsync(WarpCompiledWorkerTicket ticket,
        WarpCoreCLRWorkerLease source, CancellationToken cancellationToken = default)
    {
        InitialProbeAttempt attempt;
        lock (executionIdentityGate)
        {
            attempt = new InitialProbeAttempt(this, ticket, source, sourceCheckpointAuthority);
            initialProbeAttempts.Add(ticket, attempt);
            Volatile.Write(ref initialProbeInFlight, true);
        }
        WarpCoreCLRWorkerProcess.InitialProbeCheckpoint? words = null;
        try
        {
            words = await source.ProbeInitialEntryAsync(attempt.Inputs, attempt.Carrier, checked((int)ticket.Worker),
                attempt.State, Plan.MaximumDepth, Plan.Quantum, Arena, cancellationToken).ConfigureAwait(false);
            lock (executionIdentityGate)
            {
                attempt.RequireCurrent(this, ticket, source);
                var receipt = new InitialBeforeBodyReceipt(this, ticket, source, attempt, words, sourceCheckpointAuthority);
                initialProbeReceipts.Add(ticket, receipt);
                words = null;
                return receipt;
            }
        }
        finally
        {
            words?.Dispose();
            lock (executionIdentityGate) { Volatile.Write(ref initialProbeInFlight, false); }
        }
    }

    private void RequireInitialTicketMetadata(WarpCompiledWorkerTicket ticket, WarpCoreCLRWorkerLease source)
    {
        // No candidate bank reads precede exact Context, ticket, compiler and
        // source module/lease object validation.
        Plan.RequireCompletionCompilerSeal();
        if (ticket is null || source is null || !ReferenceEquals(ticket.Context, this) || ticket.Worker >= Plan.Workers ||
            !ReferenceEquals(tickets[ticket.Worker], ticket) || ticket.Released || ticket.Executed || ticket.Executing ||
            source.IsReleased || source.IsFaulted || !source.IsCollectible || source.CompiledModule == Guid.Empty ||
            !ReferenceEquals(source.Layout, Plan.Layout) || Volatile.Read(ref stopped) != 0 || remoteCensus is not null ||
            helpers[ticket.Worker] is not null || executionQuanta[ticket.Worker] != 0 ||
            sourceCheckpoints.TryGetValue(states[ticket.Worker], out _) || allocations[ticket.Worker] != 0 ||
            sourceLeases[ticket.Worker] || sourceLoanStarted[ticket.Worker])
            { throw new InvalidOperationException("The initial probe requires the exact unexecuted initial ticket and ordinary source lease."); }
        WarpCoreCLRWordTransaction.RequireUnquarantinedInitialProbeStorage(states[ticket.Worker], Arena);
    }

    private void RequireInitialTicketBanks(WarpCompiledWorkerTicket ticket, uint[][] captured)
    {
        uint[] state = states[ticket.Worker];
        if (Arena[Scheduler + WarpPortableSchedulerLayout.ControllerOwner] != 0 || ticket.Dispatch != Dispatch || Arena[Worker(ticket.Worker) + WarpPortableSchedulerLayout.RunGeneration] != ticket.Generation ||
            WorkerState(ticket.Worker) != WarpPortableSchedulerLayout.Running ||
            !initialProbeStates.TryGetValue(state, out byte[]? initial) ||
            !CryptographicOperations.FixedTimeEquals(initial, SHA256.HashData(MemoryMarshal.AsBytes(state.AsSpan()))) ||
            !CryptographicOperations.FixedTimeEquals(sourceArgumentIdentity, WarpCoreCLRReadOnlyWordIdentity.FromArguments(captured, [])))
        { throw new InvalidOperationException("The initial source invocation or its original argument words changed."); }
    }

    internal sealed class InitialProbeAttempt
    {
        private readonly WarpCompiledSourceContext context;
        private readonly WarpCompiledWorkerTicket ticket;
        private readonly WarpCoreCLRWorkerLease source;
        private readonly uint[][] banks;

        internal InitialProbeAttempt(WarpCompiledSourceContext context, WarpCompiledWorkerTicket ticket,
            WarpCoreCLRWorkerLease source, object authority)
        {
            if (context is null || !ReferenceEquals(authority, context.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context secret may prepare its initial probe."); }
            context.RequireInitialTicketMetadata(ticket, source);
            if (context.initialProbeInFlight || context.initialProbeAttempts.TryGetValue(ticket, out _))
            { throw new InvalidOperationException("The initial ticket has already used its one ordinary probe attempt."); }
            this.context = context; this.ticket = ticket; this.source = source;
            Inputs = context.inputs; State = context.states[ticket.Worker]; Carrier = [0];
            using WarpOrdinaryArrayAdmission admission = WarpOrdinaryArrayAdmission.Acquire(Inputs, Carrier, State, context.Arena);
            uint[][] captured = WarpCoreCLRWorkerProcess.CaptureProbeInputs(admission, Inputs.Length);
            banks = captured;
            context.RequireInitialTicketBanks(ticket, captured);
        }

        internal uint[][] Inputs { get; }
        internal uint[] State { get; }
        internal uint[] Carrier { get; }

        internal void RequireCurrent(WarpCompiledSourceContext exactContext, WarpCompiledWorkerTicket exactTicket,
            WarpCoreCLRWorkerLease exactSource)
        {
            if (!ReferenceEquals(context, exactContext) || !ReferenceEquals(ticket, exactTicket) || !ReferenceEquals(source, exactSource) ||
                !context.initialProbeAttempts.TryGetValue(ticket, out InitialProbeAttempt? issued) || !ReferenceEquals(issued, this) ||
                !ReferenceEquals(Inputs, context.inputs) || !ReferenceEquals(State, context.states[ticket.Worker]))
            { throw new InvalidOperationException("The initial probe must retain its exact privately issued attempt and original storage."); }
            context.RequireInitialTicketMetadata(ticket, source);
            if (Inputs.Length != banks.Length || banks.Where((bank, index) => !ReferenceEquals(bank, Inputs[index])).Any())
            { throw new InvalidOperationException("The initial attempt replaced an original input bank."); }
        }
    }
}
