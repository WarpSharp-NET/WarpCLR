namespace WarpCLR.Runtime.Host;

internal static partial class WarpCoreCLRWordTransaction
{
    // Read-only denial of the existing irreversible transaction quarantine.
    // Array identity lookups inspect no word, and confer no ownership permission.
    internal static void RequireUnquarantinedInitialProbeStorage(uint[] state, uint[] arena)
    {
        if (Gates.TryGetValue(state, out Gate? stateGate) && Volatile.Read(ref stateGate.Quarantined) ||
            Gates.TryGetValue(arena, out Gate? arenaGate) && Volatile.Read(ref arenaGate.Quarantined))
        { throw new WarpHostException("WRPCORECLR3002", "Initial probe storage is quarantined after an owned transaction failure."); }
    }
}
