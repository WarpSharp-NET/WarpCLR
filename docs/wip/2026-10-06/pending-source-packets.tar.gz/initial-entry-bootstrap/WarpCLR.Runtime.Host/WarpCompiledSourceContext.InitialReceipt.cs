using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    internal sealed class InitialBeforeBodyReceipt : IDisposable
    {
        internal const string Semantics = "warp.context-initial-entry/private-context-exact-initial-ticket-compiler-cwt-actual-kind19-emitted-entry-before-all-nodes-null-previous-sourcecheckpoint-data-only/0.1";
        private readonly WarpCompiledSourceContext context;
        private readonly WarpCompiledWorkerTicket ticket;
        private readonly WarpCoreCLRWorkerLease source;
        private readonly InitialProbeAttempt attempt;
        private readonly WarpCoreCLRWorkerProcess.InitialProbeCheckpoint words;
        private bool disposed;

        internal InitialBeforeBodyReceipt(WarpCompiledSourceContext context, WarpCompiledWorkerTicket ticket,
            WarpCoreCLRWorkerLease source, InitialProbeAttempt attempt, WarpCoreCLRWorkerProcess.InitialProbeCheckpoint words, object authority)
        {
            if (context is null || !ReferenceEquals(authority, context.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context may retain its actual initial before-body encounter."); }
            attempt.RequireCurrent(context, ticket, source);
            words.ValidateCurrent(context.Plan.Layout, source.ProcessId, source.CompiledModule,
                attempt.Inputs, attempt.Carrier, attempt.State, context.Arena);
            this.context = context; this.ticket = ticket; this.source = source; this.attempt = attempt; this.words = words;
            Projection = context.Plan.CaptureInitialEntryProjection();
        }

        internal SourceCheckpoint? PreviousSourceCheckpoint => null;
        // This is the sealed final EntryInvocation projection, not an executed
        // call-use. The genuine emitted hook below was before the wrapper too.
        internal WarpCompiledInitialEntryProjection Projection { get; }
        internal WarpPortableSourceInvocation Invocation => Projection.Invocation;
        internal int EncounterFunction => words.EntryFunction;
        internal int EncounterProgramCounter => words.EntryProgramCounter;
        internal ulong Ordinal => words.Ordinal;
        internal ulong Sequence => words.Sequence;
        internal int ProcessId => words.ProcessId;
        internal Guid Module => words.Module;

        internal void ValidateInitial(WarpCompiledSourceContext exactContext, WarpCompiledWorkerTicket exactTicket,
            WarpCoreCLRWorkerLease exactSource)
        {
            lock (context.executionIdentityGate)
            {
                if (!ReferenceEquals(context, exactContext) || !ReferenceEquals(ticket, exactTicket) || !ReferenceEquals(source, exactSource) ||
                    disposed || !context.initialProbeReceipts.TryGetValue(ticket, out InitialBeforeBodyReceipt? issued) || !ReferenceEquals(issued, this))
                { throw new InvalidOperationException("Only the exact issued current initial receipt may be validated."); }
                attempt.RequireCurrent(context, ticket, source);
                using WarpOrdinaryArrayAdmission admission = WarpOrdinaryArrayAdmission.Acquire(attempt.Inputs, attempt.Carrier, attempt.State, context.Arena);
                uint[][] captured = WarpCoreCLRWorkerProcess.CaptureProbeInputs(admission, attempt.Inputs.Length);
                context.RequireInitialTicketBanks(ticket, captured);
                words.ValidateCurrent(context.Plan.Layout, source.ProcessId, source.CompiledModule,
                    attempt.Inputs, attempt.Carrier, attempt.State, context.Arena);
            }
        }

        internal byte[] CopyResponsePayload()
        {
            ValidateInitial(context, ticket, source);
            return words.CopyResponsePayload();
        }

        internal WarpCLR.Backend.CoreCLR.WarpCoreCLRWorkerWords.Invocation CopyProbeRequest()
        {
            ValidateInitial(context, ticket, source);
            return words.CopyRequest();
        }

        public void Dispose()
        {
            lock (context.executionIdentityGate)
            {
                if (disposed) { return; }
                if (!context.initialProbeReceipts.TryGetValue(ticket, out InitialBeforeBodyReceipt? issued) || !ReferenceEquals(issued, this))
                { throw new InvalidOperationException("An unissued or cloned initial receipt cannot retire its genuine predecessor."); }
                disposed = true; words.Dispose();
            }
        }
    }
}
