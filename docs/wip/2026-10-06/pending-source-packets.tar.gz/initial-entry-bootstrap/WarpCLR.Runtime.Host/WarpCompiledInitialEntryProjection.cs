using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

// Compiler-CWT-validated consistency projection captured by the exact Plan.
// Only the emitted encounter is observed; no IR node or call use has run.
internal sealed record WarpCompiledInitialEntryProjection(WarpPortableWordProgramIdentity CompilerIdentity,
    WarpPortableSourceInvocation Invocation, WarpLogicalMachineNode EntryNode, WarpPortableWordBody SourceBody,
    WarpLogicalMachineNode SourceBodyEntryNode)
{
    // This is final compiler-owned block membership, not an executed CIL site.
    // Retain the exact prelude object when it owns the source body's entry node.
    internal WarpPortableWordInvocationPrelude? SourceBodyEntryPrelude =>
        SourceBody.InvocationPrelude is { } prelude && prelude.GeneratedBlocks.Contains(SourceBodyEntryNode.Block)
            ? prelude : null;

    internal SourceEntryKind SourceBodyEntryKind
    {
        get
        {
            if (SourceBodyEntryPrelude is not null) { return SourceEntryKind.InvocationPrelude; }
            foreach (WarpPortableWordSourceBlock sourceBlock in SourceBody.SourceBlocks)
            {
                if (sourceBlock.Block == SourceBodyEntryNode.Block) { return SourceEntryKind.OriginalSourceBlock; }
            }
            return SourceEntryKind.GeneratedSetup;
        }
    }

    internal enum SourceEntryKind
    {
        GeneratedSetup,
        InvocationPrelude,
        OriginalSourceBlock,
    }
}
