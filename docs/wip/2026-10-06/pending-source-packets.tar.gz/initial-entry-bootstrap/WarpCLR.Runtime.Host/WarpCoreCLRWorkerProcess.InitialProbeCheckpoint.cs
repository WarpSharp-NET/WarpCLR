using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCoreCLRWorkerProcess
{
    private static readonly ConditionalWeakTable<InitialProbeCheckpoint, object> IssuedInitialProbes = new();
    private static readonly object InitialProbeMarker = new();

    private static InitialProbeCheckpoint PrepareInitialProbeCheckpoint(WarpCoreCLRStoppedCommands.Command command,
        WarpLogicalMachineLayout layout, uint[][] inputs, uint[][] capturedInputs, uint[] carrier,
        WarpCoreCLRAuthenticatedResponse authenticated, byte[] request, byte[] response, WarpCoreCLRTransferAdmission.Lease storage)
    {
        lock (RegistrySync)
        {
            RequireCurrent(command);
            if (command.Process.IsFaulted || command.Process.IsClosed || command.Process.CompiledModule == Guid.Empty ||
                !command.Process.IsCollectible || command.RequestKind != WarpCoreCLRInitialEntryProbeWords.Probe ||
                command.ResponseKind != WarpCoreCLRInitialEntryProbeWords.Probed || command.Admission is not null || command.Controller is not null)
            { throw new InvalidOperationException("Only the actual ordinary registered initial probe may issue a receipt."); }
            var receipt = new InitialProbeCheckpoint(RegistryAuthority, command, layout, inputs, capturedInputs, carrier,
                authenticated, request, response, storage);
            IssuedInitialProbes.Add(receipt, InitialProbeMarker);
            return receipt;
        }
    }

    // This receipt records a hook encounter, not an executed quantum. It has no
    // SourceCheckpoint, controller lease, generation-transition or grant role.
    internal sealed class InitialProbeCheckpoint : IDisposable
    {
        private readonly WarpCoreCLRStoppedCommands.Command command;
        private readonly WarpLogicalMachineLayout layout;
        private readonly uint[][] inputs;
        private readonly uint[][] banks;
        private readonly uint[] carrier;
        private readonly WarpCoreCLRAuthenticatedResponse authenticated;
        private readonly byte[] request;
        private readonly byte[] responseDigest;
        private WarpCoreCLRTransferAdmission.Lease? storage;

        internal InitialProbeCheckpoint(object issuer, WarpCoreCLRStoppedCommands.Command command, WarpLogicalMachineLayout layout,
            uint[][] inputs, uint[][] banks, uint[] carrier, WarpCoreCLRAuthenticatedResponse authenticated,
            byte[] request, byte[] response, WarpCoreCLRTransferAdmission.Lease storage)
        {
            ValidateRegistryAuthority(issuer);
            this.command = command; this.layout = layout; this.inputs = inputs; this.banks = (uint[][])banks.Clone();
            this.carrier = carrier; this.authenticated = authenticated; this.request = request; this.storage = storage;
            responseDigest = SHA256.HashData(response);
            Module = command.Process.CompiledModule; ProcessId = command.Process.ProcessId;
            EntryProgramCounter = layout.GetBlockEntry(0, 0);
            _ = RequireTransport();
        }

        internal Guid Module { get; }
        internal int ProcessId { get; }
        internal int EntryFunction => 0;
        internal int EntryProgramCounter { get; }
        internal ulong Ordinal => command.Ordinal;
        internal ulong Sequence => command.Sequence;
        internal string IrHash => command.IrHash;
        internal string RequestHash => Convert.ToHexString(command.Digest);
        internal string ResponseHash => Convert.ToHexString(responseDigest);
        internal bool IsDisposed => Volatile.Read(ref storage) is null;

        internal void ValidateCurrent(WarpLogicalMachineLayout exactLayout, int exactProcessId, Guid exactModule,
            uint[][] exactInputs, uint[] exactCarrier, uint[] exactState, uint[] exactArena)
        {
            // CWT issuance and all exact object identities precede any bank read.
            lock (RegistrySync)
            {
                if (!IssuedInitialProbes.TryGetValue(this, out object? marker) || !ReferenceEquals(marker, InitialProbeMarker) || IsDisposed ||
                    !ReferenceEquals(layout, exactLayout) || Module != exactModule || ProcessId != exactProcessId ||
                    !ReferenceEquals(inputs, exactInputs) || !ReferenceEquals(carrier, exactCarrier) ||
                    !ReferenceEquals(command.State, exactState) || !ReferenceEquals(command.Arena, exactArena) ||
                    command.Process.IsFaulted || command.Process.IsClosed ||
                    RegistryCommands.Values.Any(active => ReferenceEquals(active.State, exactState) || ReferenceEquals(active.Arena, exactArena)))
                { throw new InvalidOperationException("The initial receipt is not the exact live issued command, layout, child and original storage."); }
            }
            WarpCoreCLRWordTransaction.RequireUnquarantinedInitialProbeStorage(exactState, exactArena);
            using WarpOrdinaryArrayAdmission admission = WarpOrdinaryArrayAdmission.Acquire(exactInputs, exactCarrier, exactState, exactArena);
            uint[][] captured = CaptureOrdinaryInputs(admission, exactInputs.Length);
            if (captured.Length != banks.Length || captured.Where((bank, index) => !ReferenceEquals(bank, banks[index])).Any())
            { throw new InvalidOperationException("An original input bank was replaced after the probe."); }
            byte[] verified = RequireTransport();
            WarpCoreCLRWorkerWords.Invocation historical = WarpCoreCLRWorkerWords.ReadRequest(request);
            byte[] currentRequest = WarpCoreCLRWorkerWords.Request(captured, exactCarrier, historical.Worker, exactState,
                historical.Depth, historical.Quantum, exactArena);
            if (!CryptographicOperations.FixedTimeEquals(currentRequest, request))
            { throw new InvalidOperationException("The untouched initial invocation has changed since its genuine entry encounter."); }
            _ = WarpCoreCLRInitialEntryProbeWords.ReadResponse(verified, request, exactState.Length, exactArena.Length, Module, EntryProgramCounter);
        }

        internal byte[] CopyResponsePayload()
        {
            lock (RegistrySync)
            {
                if (!IssuedInitialProbes.TryGetValue(this, out _) || IsDisposed)
                { throw new InvalidOperationException("Only an issued, retained initial receipt has transport history."); }
            }
            return RequireTransport();
        }

        internal WarpCoreCLRWorkerWords.Invocation CopyRequest()
        {
            _ = CopyResponsePayload();
            return WarpCoreCLRWorkerWords.ReadRequest(request);
        }

        private byte[] RequireTransport()
        {
            if (!CryptographicOperations.FixedTimeEquals(SHA256.HashData(request), command.Digest))
            { throw new InvalidOperationException("The initial receipt changed its complete registered request."); }
            byte[] response = authenticated.RequirePayload(command.Process.key, WarpCoreCLRInitialEntryProbeWords.Probed, command.Sequence);
            if (!CryptographicOperations.FixedTimeEquals(SHA256.HashData(response), responseDigest))
            { throw new InvalidOperationException("The full authenticated kind19 response changed."); }
            _ = WarpCoreCLRInitialEntryProbeWords.ReadResponse(response, request, command.State.Length, command.Arena.Length, Module, EntryProgramCounter);
            return response;
        }

        public void Dispose()
        {
            WarpCoreCLRTransferAdmission.Lease? retired;
            lock (RegistrySync)
            {
                if (!IssuedInitialProbes.TryGetValue(this, out object? marker) || !ReferenceEquals(marker, InitialProbeMarker))
                { throw new InvalidOperationException("An unissued or cloned initial receipt cannot retire another receipt's storage."); }
                retired = Interlocked.Exchange(ref storage, null);
            }
            retired?.Dispose();
        }
    }
}
