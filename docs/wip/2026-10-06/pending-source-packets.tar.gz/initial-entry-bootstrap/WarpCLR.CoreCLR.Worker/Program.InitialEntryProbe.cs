using WarpCLR.Backend.CoreCLR;

namespace WarpCLR.CoreCLR.Worker;

internal static partial class Program
{
    private static byte[] ProbeInitialEntry(WarpCoreCLRWorkerProtocol.Frame frame, byte[] key, ulong sequence,
        CoreCLRResumableKernel kernel)
    {
        using CoreCLRInitialEntryProbe.Scope scope = CoreCLRInitialEntryProbe.Begin(frame, key, sequence, kernel);
        return kernel.ProbeInitialEntry(scope);
    }
}
