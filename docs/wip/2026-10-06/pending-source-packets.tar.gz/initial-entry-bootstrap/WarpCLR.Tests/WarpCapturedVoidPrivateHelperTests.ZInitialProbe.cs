using System.Security.Cryptography;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpCapturedVoidPrivateHelperTests
{
    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task AuthenticInitialProbeReturnsBeforeAPrivateLayoutWithoutGrantingOrdinarySource(bool largeQuantum)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(typeof(Guest).GetMethod(nameof(Guest.Empty))!);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
        WarpPortableWordLoweredProgram program = WarpPortableWordLowerer.Lower(graph, typed, schema, new VoidBinding(graph, typed, schema));
        var layout = new WarpLogicalMachineLayout(program.Kernel);
        Assert.IsNotNull(layout.Kernel.Execution!.PrivateControllerProjection);
        CoreCLRResumableKernel core = CoreCLRResumableKernel.Compile(layout);
        uint[] state = layout.CreateInitialState(8, 100), arena = [0x7FC12345, 0x80000000, uint.MaxValue], carrier = [0];
        layout.SetSourceBoundaryMode(state, enabled: true);
        uint[] before = (uint[])state.Clone(), arenaBefore = (uint[])arena.Clone();
        int quantum = largeQuantum ? 4096 : layout.MaximumBlockCost;
        Assert.ThrowsExactly<InvalidOperationException>(() => core.ExecuteManagedQuantum([], carrier, 0, state, 8, quantum, arena));
        byte[] key = RandomNumberGenerator.GetBytes(32), request = WarpCoreCLRWorkerWords.Request([], carrier, 0, state, 8, quantum, arena);
        using var stream = new MemoryStream();
        await WarpCoreCLRWorkerProtocol.WriteAsync(stream, key, WarpCoreCLRInitialEntryProbeWords.Probe, 12, request, CancellationToken.None).ConfigureAwait(false);
        stream.Position = 0;
        var frame = await WarpCoreCLRWorkerProtocol.ReadAsync(stream, key, 12, CancellationToken.None).ConfigureAwait(false);
        ProbePrivateSynchronously(core, frame, key, request, before, arenaBefore);
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        using var receipt = await lease.ProbeInitialEntryAsync([], carrier, 0, state, 8, quantum, arena).ConfigureAwait(false);
        CollectionAssert.AreEqual(before, state); CollectionAssert.AreEqual(arenaBefore, arena);
        Assert.AreEqual(100u, state[WarpLogicalMachineLayout.RemainingStepsLowOffset]);
        Assert.AreEqual(0u, state[WarpLogicalMachineLayout.UsedOperationsLowOffset]);
        Assert.AreEqual(0u, state[WarpLogicalMachineLayout.UsedOperationsHighOffset]);
        // The successful probe does not alter the ordinary private-layout denial.
        Assert.ThrowsExactly<InvalidOperationException>(() => core.ExecuteManagedQuantum([], carrier, 0, state, 8, quantum, arena));
        CollectionAssert.AreEqual(before, state); CollectionAssert.AreEqual(arenaBefore, arena);
    }

    private static void ProbePrivateSynchronously(CoreCLRResumableKernel core, WarpCoreCLRWorkerProtocol.Frame frame,
        byte[] key, byte[] request, uint[] state, uint[] arena)
    {
        using CoreCLRInitialEntryProbe.Scope scope = CoreCLRInitialEntryProbe.Begin(frame, key, 12, core);
        byte[] payload = core.ProbeInitialEntry(scope);
        var result = WarpCoreCLRInitialEntryProbeWords.ReadResponse(payload, request, state.Length, arena.Length,
            core.CompiledEntryPoint.Module.ModuleVersionId, core.Layout.GetBlockEntry(0, 0));
        CollectionAssert.AreEqual(state, result.State); CollectionAssert.AreEqual(arena, result.Arena);
    }
}
