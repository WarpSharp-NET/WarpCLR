using System.Security.Cryptography;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests;

internal sealed partial class WarpCoreCLRWorkerTests
{
    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task ActualInitialEntryChildReturnsBeforeEveryNodeChargeAndPreservesOrdinaryParity(bool largeQuantum)
    {
        var layout = new WarpLogicalMachineLayout(RichKernel());
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        uint[][] inputs = [[17]]; uint[] carrier = [0], arena = [0x80000000, 0x7FC12345, uint.MaxValue];
        uint[] state = layout.CreateInitialState(8, 100);
        uint[] before = (uint[])state.Clone(), arenaBefore = (uint[])arena.Clone();
        int quantum = largeQuantum ? Math.Max(4096, layout.MaximumBlockCost) : layout.MaximumBlockCost;
        using WarpCoreCLRWorkerProcess.InitialProbeCheckpoint receipt = await lease.ProbeInitialEntryAsync(
            inputs, carrier, 0, state, 8, quantum, arena).ConfigureAwait(false);
        Assert.AreNotEqual(Environment.ProcessId, receipt.ProcessId); Assert.AreEqual(lease.CompiledModule, receipt.Module);
        Assert.AreEqual(0, receipt.EntryFunction); Assert.AreEqual(layout.GetBlockEntry(0, 0), receipt.EntryProgramCounter);
        CollectionAssert.AreEqual(before, state); CollectionAssert.AreEqual(arenaBefore, arena); Assert.AreEqual(17u, inputs[0][0]);
        CollectionAssert.AreEqual(new uint[] { 0 }, carrier);
        receipt.ValidateCurrent(layout, lease.ProcessId, lease.CompiledModule, inputs, carrier, state, arena);
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateCurrent(new WarpLogicalMachineLayout(layout.Kernel),
            lease.ProcessId, lease.CompiledModule, inputs, carrier, state, arena));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateCurrent(layout, lease.ProcessId, Guid.NewGuid(),
            inputs, carrier, state, arena));
        byte[] payload = receipt.CopyResponsePayload();
        byte[] request = WarpCoreCLRWorkerWords.Request(inputs, carrier, 0, state, 8, quantum, arena);
        var parsed = WarpCoreCLRInitialEntryProbeWords.ReadResponse(payload, request, state.Length, arena.Length,
            lease.CompiledModule, layout.GetBlockEntry(0, 0));
        CollectionAssert.AreEqual(state, parsed.State); CollectionAssert.AreEqual(arena, parsed.Arena);
        Assert.Throws<InvalidDataException>(() => WarpCoreCLRWorkerWords.ReadResponse(payload, request, state.Length, arena.Length));
        Assert.ThrowsExactly<InvalidOperationException>(() => lease.RequireCommittedWordCheckpoint(state, arena));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateCurrent(layout, lease.ProcessId, lease.CompiledModule,
            (uint[][])inputs.Clone(), carrier, state, arena));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateCurrent(layout, lease.ProcessId, lease.CompiledModule,
            inputs, (uint[])carrier.Clone(), state, arena));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateCurrent(layout, lease.ProcessId, lease.CompiledModule,
            inputs, carrier, (uint[])state.Clone(), arena));
        CoreCLRResumableKernel reference = CoreCLRResumableKernel.Compile(layout);
        uint[] expected = (uint[])state.Clone(), expectedArena = (uint[])arena.Clone();
        for (int attempt = 0; state[0] == WarpLogicalMachineLayout.Runnable && attempt < 100; attempt++)
        {
            await lease.ExecuteManagedQuantumAsync(inputs, [], 0, state, 8, quantum, arena).ConfigureAwait(false);
            reference.ExecuteManagedQuantum(inputs, [], 0, expected, 8, quantum, expectedArena);
            CollectionAssert.AreEqual(expected, state); CollectionAssert.AreEqual(expectedArena, arena);
        }
        Assert.AreEqual(WarpLogicalMachineLayout.Completed, state[0]);
        Assert.AreEqual(17u, state[layout.GetResultWordOffset(0, 8)]); Assert.AreEqual(24u, state[layout.GetResultWordOffset(1, 8)]);
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateCurrent(layout, lease.ProcessId, lease.CompiledModule,
            inputs, carrier, state, arena));
        receipt.Dispose();
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.CopyResponsePayload());
    }

    [TestMethod]
    [DataRow("constructed")]
    [DataRow("clone")]
    [DataRow("key-copy")]
    [DataRow("wrong-kind")]
    [DataRow("sequence")]
    [DataRow("payload")]
    public async Task InitialProbeScopeAuthenticatesFrameSessionKindSequenceBeforeCandidateBanks(string change)
    {
        CoreCLRResumableKernel kernel = CoreCLRResumableKernel.Compile(new(RichKernel()));
        byte[] key = RandomNumberGenerator.GetBytes(32);
        using var stream = new MemoryStream();
        // Deliberately undecodable candidate bytes. Every denial is authentication
        // first, before request decoding or bank validation.
        await WarpCoreCLRWorkerProtocol.WriteAsync(stream, key, WarpCoreCLRInitialEntryProbeWords.Probe, 12, [91], CancellationToken.None).ConfigureAwait(false);
        stream.Position = 0;
        WarpCoreCLRWorkerProtocol.Frame frame = await WarpCoreCLRWorkerProtocol.ReadAsync(stream, key, 12, CancellationToken.None).ConfigureAwait(false);
        if (change == "constructed") { frame = new(frame.Kind, (byte[])frame.Payload.Clone()); }
        if (change == "clone") { frame = frame with { }; }
        if (change == "key-copy") { key = (byte[])key.Clone(); }
        if (change == "payload") { frame.Payload[0] ^= 1; }
        if (change == "wrong-kind")
        {
            using var wrong = new MemoryStream();
            await WarpCoreCLRWorkerProtocol.WriteAsync(wrong, key, WarpCoreCLRWorkerProtocol.Execute, 12, [91], CancellationToken.None).ConfigureAwait(false);
            wrong.Position = 0;
            frame = await WarpCoreCLRWorkerProtocol.ReadAsync(wrong, key, 12, CancellationToken.None).ConfigureAwait(false);
        }
        WarpCoreCLRWorkerProtocol.Frame candidate = frame; byte[] candidateKey = key;
        Assert.Throws<InvalidDataException>(() => CoreCLRInitialEntryProbe.Begin(candidate, candidateKey,
            change == "sequence" ? 13u : 12u, kernel));
    }

    [TestMethod]
    [DataRow(0)]
    [DataRow(1)]
    [DataRow(2)]
    public async Task InitialProbeNeverNormalizesEmptyNonzeroOrExtraRawCarrier(int form)
    {
        var layout = new WarpLogicalMachineLayout(RichKernel());
        CoreCLRResumableKernel kernel = CoreCLRResumableKernel.Compile(layout);
        uint[] carrier = form switch { 0 => [], 1 => [0x13579BDF], _ => [0, 0] };
        uint[] state = layout.CreateInitialState(8, 100), arena = [23];
        byte[] request = WarpCoreCLRWorkerWords.Request([[17]], carrier, 0, state, 8, layout.MaximumBlockCost, arena);
        byte[] key = RandomNumberGenerator.GetBytes(32);
        using var stream = new MemoryStream();
        await WarpCoreCLRWorkerProtocol.WriteAsync(stream, key, WarpCoreCLRInitialEntryProbeWords.Probe, 12, request, CancellationToken.None).ConfigureAwait(false);
        stream.Position = 0;
        var frame = await WarpCoreCLRWorkerProtocol.ReadAsync(stream, key, 12, CancellationToken.None).ConfigureAwait(false);
        DenyCarrier(kernel, frame, key, request);
    }

    private static void DenyCarrier(CoreCLRResumableKernel kernel, WarpCoreCLRWorkerProtocol.Frame frame, byte[] key, byte[] original)
    {
        using CoreCLRInitialEntryProbe.Scope scope = CoreCLRInitialEntryProbe.Begin(frame, key, 12, kernel);
        Assert.Throws<ArgumentException>(() => kernel.ProbeInitialEntry(scope));
        var call = scope.Invocation;
        CollectionAssert.AreEqual(original, WarpCoreCLRWorkerWords.Request(call.Inputs, call.Scalars, call.Worker,
            call.State, call.Depth, call.Quantum, call.Arena));
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task InitialProbeRejectsHeldOrQuarantinedOriginalBanksBeforeAnyWordChanges(bool quarantine)
    {
        CoreCLRResumableKernel kernel = CoreCLRResumableKernel.Compile(new(RichKernel()));
        uint[] state = kernel.Layout.CreateInitialState(8, 100);
        byte[] request = WarpCoreCLRWorkerWords.Request([[17]], [0], 0, state, 8, kernel.Layout.MaximumBlockCost, [23]);
        byte[] key = RandomNumberGenerator.GetBytes(32);
        using var stream = new MemoryStream();
        await WarpCoreCLRWorkerProtocol.WriteAsync(stream, key, WarpCoreCLRInitialEntryProbeWords.Probe, 12, request, CancellationToken.None).ConfigureAwait(false);
        stream.Position = 0;
        var frame = await WarpCoreCLRWorkerProtocol.ReadAsync(stream, key, 12, CancellationToken.None).ConfigureAwait(false);
        DenyHeldProbe(kernel, frame, key, quarantine);
    }

    private static void DenyHeldProbe(CoreCLRResumableKernel kernel, WarpCoreCLRWorkerProtocol.Frame frame, byte[] key, bool quarantine)
    {
        using CoreCLRInitialEntryProbe.Scope scope = CoreCLRInitialEntryProbe.Begin(frame, key, 12, kernel);
        var call = scope.Invocation;
        uint[] before = (uint[])call.State.Clone(), arenaBefore = (uint[])call.Arena.Clone();
        object owner = new(), authority = new();
        WarpOrdinaryArrayOwner handle = WarpOrdinaryArrayRegistry.EnrollOwner(owner, authority, [call.State]);
        WarpOrdinaryArrayRegistry.Hold(handle, owner, authority);
        try
        {
            if (quarantine) { WarpOrdinaryArrayRegistry.Quarantine(handle, owner, authority); }
            Assert.ThrowsExactly<InvalidOperationException>(() => kernel.ProbeInitialEntry(scope));
            CollectionAssert.AreEqual(before, call.State); CollectionAssert.AreEqual(arenaBefore, call.Arena);
        }
        finally { if (!quarantine) { WarpOrdinaryArrayRegistry.ReleaseHold(handle, owner, authority); } }
    }

    [TestMethod]
    public async Task InitialEntryRequiresItsExactSynchronousScopeEmissionAndCannotReplayTheActualRequest()
    {
        var layout = new WarpLogicalMachineLayout(RichKernel());
        CoreCLRResumableKernel kernel = CoreCLRResumableKernel.Compile(layout), other = CoreCLRResumableKernel.Compile(layout);
        Assert.ThrowsExactly<InvalidOperationException>(() => kernel.ProbeInitialEntry(null!));
        Assert.ThrowsExactly<InvalidOperationException>(() => new CoreCLRInitialEntryProbe.Scope(new object(), null!, null!, null!, 0, null!));
        byte[] key = RandomNumberGenerator.GetBytes(32);
        byte[] request = WarpCoreCLRWorkerWords.Request([[17]], [0], 0, layout.CreateInitialState(8, 100), 8, layout.MaximumBlockCost, [23]);
        using var stream = new MemoryStream();
        await WarpCoreCLRWorkerProtocol.WriteAsync(stream, key, WarpCoreCLRInitialEntryProbeWords.Probe, 12, request, CancellationToken.None).ConfigureAwait(false);
        stream.Position = 0;
        var frame = await WarpCoreCLRWorkerProtocol.ReadAsync(stream, key, 12, CancellationToken.None).ConfigureAwait(false);
        CheckScopeLifetime(kernel, other, frame, key);
    }

    private static void CheckScopeLifetime(CoreCLRResumableKernel kernel, CoreCLRResumableKernel other,
        WarpCoreCLRWorkerProtocol.Frame frame, byte[] key)
    {
        using (CoreCLRInitialEntryProbe.Scope scope = CoreCLRInitialEntryProbe.Begin(frame, key, 12, kernel))
        {
            Assert.ThrowsExactly<InvalidOperationException>(() => other.ProbeInitialEntry(scope));
            Assert.ThrowsExactly<InvalidOperationException>(() => CoreCLRInitialEntryProbe.StopAtEntry(new object(), null!, null!, 0, null!, 0, 0, null!));
            // Even the exact public emitted method cannot be called directly
            // within this scope: only the ordinary-admitted internal entry arms it.
            var raw = kernel.CompiledEntryPoint.CreateDelegate<Action<uint[][], uint[], int, uint[], int, int, CancellationToken, uint[]>>();
            var call = scope.Invocation;
            Assert.ThrowsExactly<InvalidOperationException>(() => raw(call.Inputs, call.Scalars, call.Worker, call.State,
                call.Depth, call.Quantum, CancellationToken.None, call.Arena));
            _ = kernel.ProbeInitialEntry(scope);
            Assert.ThrowsExactly<InvalidOperationException>(() => kernel.ProbeInitialEntry(scope));
            Assert.ThrowsExactly<InvalidOperationException>(() => scope.Complete());
        }
        Assert.ThrowsExactly<InvalidOperationException>(() => CoreCLRInitialEntryProbe.Begin(frame, key, 12, kernel));
    }

    [TestMethod]
    public async Task InitialProbeReceiptRejectsWordQuarantineWithTheChildAndEveryBankByteUnchanged()
    {
        var layout = new WarpLogicalMachineLayout(RichKernel());
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        uint[][] inputs = [[17]]; uint[] carrier = [0], state = layout.CreateInitialState(8, 100), arena = [23];
        using var receipt = await lease.ProbeInitialEntryAsync(inputs, carrier, 0, state, 8, layout.MaximumBlockCost, arena).ConfigureAwait(false);
        uint[] stateBefore = (uint[])state.Clone(), arenaBefore = (uint[])arena.Clone();
        WarpCoreCLRWordTransaction.Quarantine(state, arena);
        WarpHostException failure = Assert.ThrowsExactly<WarpHostException>(() => receipt.ValidateCurrent(layout, lease.ProcessId,
            lease.CompiledModule, inputs, carrier, state, arena));
        Assert.AreEqual("WRPCORECLR3002", failure.Code, StringComparer.Ordinal);
        CollectionAssert.AreEqual(stateBefore, state); CollectionAssert.AreEqual(arenaBefore, arena);
        Assert.IsFalse(lease.IsFaulted);
    }

    [TestMethod]
    public void InitialProbeWorstCaseCapacityAndWrongIssuerFailBeforeAnyChildOrBank()
    {
        int maximum = (WarpCoreCLRWorkerWords.MaximumBytes - 40 - WarpCoreCLRInitialEntryProbeWords.TrailerBytes) / sizeof(uint);
        long allowance = WarpCoreCLRWorkerProcess.InitialProbeTransferBytes(WarpCoreCLRWorkerWords.MaximumBytes, maximum, 0);
        Assert.IsLessThan(WarpCoreCLRTransferAdmission.MaximumBytes, allowance);
        Assert.Throws<InvalidDataException>(() => WarpCoreCLRWorkerProcess.InitialProbeTransferBytes(64, maximum + 1, 0));
        Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCoreCLRWorkerProcess.InitialProbeCheckpoint(
            new object(), null!, null!, null!, null!, null!, null!, null!, null!, null!));
    }
}
