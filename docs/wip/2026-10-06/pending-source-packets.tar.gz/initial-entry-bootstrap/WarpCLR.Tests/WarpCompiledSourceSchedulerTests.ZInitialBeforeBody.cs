using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpCompiledSourceSchedulerTests
{
    [TestMethod]
    [DataRow(nameof(Kernels.Recursive))]
    [DataRow(nameof(Kernels.Single))]
    public async Task ActualInitialBeforeBodyReceiptHasNullPreviousCheckpointAndNeverExecutesOrChargesTheTicket(string method)
    {
        var captured = CaptureSource(method);
        var plan = new WarpCompiledSourcePlan(captured.Graph, captured.Schema, captured.Program, 1, 1, 16, 100000, 4096, Services.Value);
        uint[][] arguments = method == nameof(Kernels.Single) ?
            [[BitConverter.SingleToUInt32Bits(1.5f)], [BitConverter.SingleToUInt32Bits(2.25f)]] : [[4]];
        WarpCompiledSourceContext context = Bind(plan, arguments);
        WarpCompiledWorkerTicket ticket = context.Claim(0)!;
        Assert.IsNotNull(ticket);
        WarpCoreCLRWorkerKernel compiled = await WarpCoreCLRWorkerKernel.CompileAsync(plan.Layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var compiledOwner = compiled.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = compiled.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        uint[] state = context.MachineState(ticket.Worker).ToArray(), arena = (uint[])context.Arena.Clone();
        uint failedClaims = context.FailedControllerClaims;
        using WarpCompiledSourceContext.InitialBeforeBodyReceipt receipt = await context.ProbeInitialBeforeBodyAsync(ticket, lease).ConfigureAwait(false);
        receipt.ValidateInitial(context, ticket, lease);
        Assert.IsNull(receipt.PreviousSourceCheckpoint);
        Assert.IsFalse(ticket.Executed); Assert.IsFalse(ticket.Executing); Assert.IsFalse(ticket.Released);
        Assert.AreEqual(0u, context.WorkerQuanta(ticket.Worker));
        Assert.AreEqual(failedClaims, context.FailedControllerClaims);
        CollectionAssert.AreEqual(state, context.MachineState(ticket.Worker).ToArray()); CollectionAssert.AreEqual(arena, context.Arena);
        Assert.AreEqual(0, receipt.EncounterFunction); Assert.AreEqual(plan.Layout.GetBlockEntry(0, 0), receipt.EncounterProgramCounter);
        Assert.AreSame(plan.Layout.Nodes[receipt.EncounterProgramCounter], receipt.Projection.EntryNode);
        Assert.AreSame(plan.CompilerIdentity, receipt.Projection.CompilerIdentity);
        Assert.AreEqual(receipt.Invocation.Function, receipt.Projection.SourceBody.Function);
        Assert.AreSame(plan.Layout.Nodes[plan.Layout.GetBlockEntry(receipt.Invocation.Function, 0)], receipt.Projection.SourceBodyEntryNode);
        // Machine entry, final source-body entry and original CIL sites are distinct.
        // A source-body entry can still belong to the zero-charge invocation prelude.
        WarpPortableWordInvocationPrelude? prelude = receipt.Projection.SourceBody.InvocationPrelude;
        bool preludeOwnsEntry = prelude is not null &&
            prelude.GeneratedBlocks.Contains(receipt.Projection.SourceBodyEntryNode.Block);
        if (preludeOwnsEntry)
        {
            Assert.AreEqual(WarpCompiledInitialEntryProjection.SourceEntryKind.InvocationPrelude,
                receipt.Projection.SourceBodyEntryKind);
            Assert.AreSame(prelude, receipt.Projection.SourceBodyEntryPrelude);
            Assert.AreEqual(0, receipt.Projection.SourceBodyEntryNode.SourceCost);
        }
        else
        {
            Assert.IsNull(receipt.Projection.SourceBodyEntryPrelude);
            bool originalSourceEntry = receipt.Projection.SourceBody.SourceBlocks.Any(
                sourceBlock => sourceBlock.Block == receipt.Projection.SourceBodyEntryNode.Block);
            Assert.AreEqual(originalSourceEntry ? WarpCompiledInitialEntryProjection.SourceEntryKind.OriginalSourceBlock :
                WarpCompiledInitialEntryProjection.SourceEntryKind.GeneratedSetup, receipt.Projection.SourceBodyEntryKind);
        }
        Assert.AreEqual(captured.Graph.EntryIdentity, receipt.Invocation.MethodIdentity, StringComparer.Ordinal);
        Assert.AreEqual(2, receipt.Invocation.OriginKind); Assert.IsNull(receipt.Invocation.SourceOffset);
        Assert.IsNull(receipt.Invocation.SourceOpCode); Assert.IsNull(receipt.Invocation.EffectIndex);
        Assert.IsTrue(receipt.Invocation.Effects.IsEmpty); Assert.IsTrue(receipt.Invocation.ExceptionMemberships.IsEmpty);
        var request = receipt.CopyProbeRequest();
        CollectionAssert.AreEqual(new uint[] { 0 }, request.Scalars);
        CollectionAssert.AreEqual(state, request.State); CollectionAssert.AreEqual(arena, request.Arena);
        foreach (var (actual, expected) in request.Inputs.Zip(arguments)) { CollectionAssert.AreEqual(expected, actual); }
        Assert.ThrowsExactly<InvalidOperationException>(() => context.RequireCommittedSourceCheckpoint(ticket, lease));
        Assert.ThrowsExactly<InvalidOperationException>(() => context.Commit(ticket));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateInitial(null!, ticket, lease));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateInitial(context,
            new(context, ticket.Worker, ticket.Physical, ticket.Generation, ticket.Dispatch), lease));
        WarpCoreCLRWorkerLease retained = lease.Retain();
        await using var retainedOwner = retained.ConfigureAwait(false);
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateInitial(context, ticket, retained));
        await Assert.ThrowsExactlyAsync<InvalidOperationException>(() => context.ProbeInitialBeforeBodyAsync(ticket, lease)).ConfigureAwait(false);
        Assert.IsFalse(plan.HasLocalSourceKernel);
        // This subsequent execution is the existing ordinary development path,
        // never a private permission derived from the before-body receipt.
        context.Execute(ticket);
        Assert.IsTrue(ticket.Executed); Assert.AreEqual(1u, context.WorkerQuanta(ticket.Worker));
        Assert.ThrowsExactly<InvalidOperationException>(() => receipt.ValidateInitial(context, ticket, lease));
        context.Commit(ticket);
        Drain(context);
        uint expectedResult = method == nameof(Kernels.Single) ? BitConverter.SingleToUInt32Bits(Kernels.Single(1.5f, 2.25f)) : 10u;
        Assert.AreEqual(expectedResult, context.Result(0, context.Dispatch)[0]);
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void InitialBeforeBodyIssuersRequireTheExactContextSecretBeforeCandidateFieldsAndBanks(bool corruptDescriptor)
    {
        WarpCompiledSourceContext context = Create(nameof(Kernels.Recursive), 1, 1, [[4]]);
        uint original = context.Arena[WarpPortableSchedulerLayout.HeapDescriptor];
        if (corruptDescriptor) { context.Arena[WarpPortableSchedulerLayout.HeapDescriptor] = uint.MaxValue; }
        try
        {
            Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCompiledSourceContext.InitialProbeAttempt(context, null!, null!, new object()));
            Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCompiledSourceContext.InitialBeforeBodyReceipt(context, null!, null!, null!, null!, new object()));
        }
        finally { context.Arena[WarpPortableSchedulerLayout.HeapDescriptor] = original; }
        var captured = CaptureSource(nameof(Kernels.Recursive));
        Assert.ThrowsExactly<WarpVerificationException>(() => new WarpCompiledSourcePlan(captured.Graph, captured.Schema,
            captured.Program with { }, 1, 1, 16, 100000, 4096, Services.Value));
    }
}
