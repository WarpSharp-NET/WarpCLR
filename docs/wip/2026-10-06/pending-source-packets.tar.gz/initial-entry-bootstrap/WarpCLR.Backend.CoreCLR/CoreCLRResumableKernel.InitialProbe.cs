using System.Reflection.Emit;
using WarpCLR.IR;

namespace WarpCLR.Backend.CoreCLR;

public sealed partial class CoreCLRResumableKernel
{
    internal byte[] ProbeInitialEntry(CoreCLRInitialEntryProbe.Scope scope)
    {
        // Identity checks precede candidate bank validation or reads. This entry
        // has no ordinary/held Source execution mode and no fallback to quantum.
        CoreCLRInitialEntryProbe.RequireInvocation(scope, this);
        WarpCoreCLRWorkerWords.Invocation call = scope.Invocation;
        using WarpOrdinaryArrayAdmission admission = WarpOrdinaryArrayAdmission.Acquire(call.Inputs, call.Scalars, call.State, call.Arena);
        uint[][] capturedInputs = CoreCLROrdinaryArrayEmission.CaptureInputReferences(admission, call.Inputs.Length);
        RequireInitialProbeBanks(capturedInputs, call);
        scope.Enter(capturedInputs);
        entryPoint(capturedInputs, call.Scalars, call.Worker, call.State, call.Depth, call.Quantum, CancellationToken.None, call.Arena);
        return scope.Complete();
    }

    private void RequireInitialProbeBanks(uint[][] inputs, WarpCoreCLRWorkerWords.Invocation call)
    {
        // [0] is a distinct transport carrier. No guest formal scalar is read,
        // normalized or supplied; every instruction is behind the entry return.
        if (call.Scalars.Length != 1 || call.Scalars[0] != 0 || inputs.Length != Layout.Kernel.InputBufferCount ||
            call.Worker < 0 || inputs.Any(input => (uint)call.Worker >= (uint)input.Length) ||
            call.Quantum < Layout.MaximumBlockCost || call.State.Length != Layout.GetStateWords(call.Depth))
        { throw new ArgumentException("The initial probe requires exact raw [0], input bounds and admitted frame capacity.", nameof(call)); }
        uint[] state = call.State;
        if (!Layout.HasValidRuntimeHeader(state) || state[WarpLogicalMachineLayout.StatusOffset] != WarpLogicalMachineLayout.Runnable ||
            state[WarpLogicalMachineLayout.DepthOffset] != 1 ||
            state[WarpLogicalMachineLayout.RemainingStepsHighOffset] > int.MaxValue ||
            state[WarpLogicalMachineLayout.UsedOperationsLowOffset] != 0 || state[WarpLogicalMachineLayout.UsedOperationsHighOffset] != 0 ||
            state[WarpLogicalMachineLayout.HeaderWords + WarpLogicalMachineLayout.FrameFunctionOffset] != 0 ||
            state[WarpLogicalMachineLayout.HeaderWords + WarpLogicalMachineLayout.FrameProgramCounterOffset] != (uint)Layout.GetBlockEntry(0, 0))
        { throw new ArgumentException("The probe requires the untouched initial machine entry.", nameof(call)); }
        ValidateFrames(state);
    }

    private sealed partial class QuantumEmitter
    {
        private void EmitInitialProbeGate()
        {
            Label ordinaryEntry = il.DefineLabel();
            il.Emit(OpCodes.Ldsfld, initialProbeSite);
            il.Emit(OpCodes.Ldarg_0); il.Emit(OpCodes.Ldarg_1); il.Emit(OpCodes.Ldarg_2); il.Emit(OpCodes.Ldarg_3);
            il.Emit(OpCodes.Ldarg_S, (byte)4); il.Emit(OpCodes.Ldarg_S, (byte)5); il.Emit(OpCodes.Ldarg_S, (byte)7);
            il.Emit(OpCodes.Call, typeof(CoreCLRInitialEntryProbe).GetMethod(nameof(CoreCLRInitialEntryProbe.StopAtEntry))!);
            il.Emit(OpCodes.Brfalse, ordinaryEntry);
            il.Emit(OpCodes.Ret);
            il.MarkLabel(ordinaryEntry);
        }
    }
}
