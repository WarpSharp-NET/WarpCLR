using System.Security.Cryptography;

namespace WarpCLR.Backend.CoreCLR;

public static partial class CoreCLRInitialEntryProbe
{
    internal sealed class Scope : IDisposable
    {
        private readonly WarpCoreCLRWorkerProtocol.Frame frame;
        private readonly byte[] key;
        private readonly ulong sequence;
        private readonly byte[] request;
        private readonly int thread = Environment.CurrentManagedThreadId;
        private uint[][]? admittedInputs;
        private bool entered;
        private bool encountered;
        private bool completed;
        private bool disposed;

        internal Scope(object issuer, Emission emission, WarpCoreCLRWorkerProtocol.Frame frame, byte[] key,
            ulong sequence, byte[] request)
        {
            if (!ReferenceEquals(issuer, ScopeIssuer))
            { throw new InvalidOperationException("Only the authenticated initial probe issuer may create a scope."); }
            Emission = emission; this.frame = frame; this.key = key; this.sequence = sequence; this.request = request;
            Invocation = WarpCoreCLRWorkerWords.ReadRequest(request);
            WarpCoreCLRInitialEntryProbeWords.RequireResponseCapacity(Invocation.State.Length, Invocation.Arena.Length);
        }

        internal Emission Emission { get; }
        internal WarpCoreCLRWorkerWords.Invocation Invocation { get; }

        internal void Enter(uint[][] inputs)
        {
            RequireActive();
            if (entered || completed) { throw new InvalidOperationException("The authenticated probe can enter only once."); }
            if (inputs.Length != Invocation.Inputs.Length)
            { throw new InvalidOperationException("The original input bank count changed."); }
            for (int index = 0; index < Invocation.Inputs.Length; index++)
            {
                if (!ReferenceEquals(inputs[index], Invocation.Inputs[index]))
                { throw new InvalidOperationException("The probe requires the captured original input banks."); }
            }
            admittedInputs = inputs; entered = true;
        }

        internal void Encounter(uint[][] inputs, uint[] scalars, int worker, uint[] state, int depth, int quantum, uint[] arena)
        {
            RequireActive();
            if (!entered || encountered || completed || !ReferenceEquals(inputs, admittedInputs) ||
                !ReferenceEquals(scalars, Invocation.Scalars) || !ReferenceEquals(state, Invocation.State) ||
                !ReferenceEquals(arena, Invocation.Arena) || worker != Invocation.Worker || depth != Invocation.Depth || quantum != Invocation.Quantum)
            { throw new InvalidOperationException("The entry encounter differs from the actual ordinary-admitted probe invocation."); }
            encountered = true;
        }

        internal byte[] Complete()
        {
            RequireActive();
            if (!encountered || completed) { throw new InvalidOperationException("An actual entry encounter is required exactly once."); }
            byte[] verified = WarpCoreCLRWorkerProtocol.RequireAuthenticatedFrame(frame, key,
                WarpCoreCLRInitialEntryProbeWords.Probe, sequence);
            byte[] unchanged = WarpCoreCLRWorkerWords.Request(Invocation.Inputs, Invocation.Scalars, Invocation.Worker,
                Invocation.State, Invocation.Depth, Invocation.Quantum, Invocation.Arena);
            if (!CryptographicOperations.FixedTimeEquals(verified, request) || !CryptographicOperations.FixedTimeEquals(unchanged, request))
            { throw new InvalidDataException("The entry probe changed its complete original invocation or authenticated request."); }
            completed = true;
            return WarpCoreCLRInitialEntryProbeWords.Response(request, Invocation.State, Invocation.Arena,
                Emission.Method.Module.ModuleVersionId, Emission.EntryProgramCounter);
        }

        internal void RequireActive()
        {
            if (disposed || Environment.CurrentManagedThreadId != thread || !ReferenceEquals(current, this))
            { throw new InvalidOperationException("The probe must stay on its original synchronous authenticated Worker thread."); }
        }

        public void Dispose()
        {
            if (disposed) { return; }
            RequireActive(); current = null; disposed = true;
        }
    }
}
