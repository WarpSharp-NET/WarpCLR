using System.Buffers.Binary;

namespace WarpCLR.Backend.CoreCLR;

// Data parser only. An actual kind19 ReadAsync receipt plus the exact registered
// process/command is required by Host; these scalar fields confer no authority.
internal static class WarpCoreCLRInitialEntryProbeWords
{
    internal const ushort Probe = 18;
    internal const ushort Probed = 19;
    internal const int TrailerBytes = 32;
    internal const string Version = "warp.coreclr.initial-probe/full-request-digest-unchanged-word-prefix-module-actual-emitted-entry/0.1";
    private const uint Magic = 0x31504549;

    internal static void RequireResponseCapacity(int stateWords, int arenaWords)
    {
        ArgumentOutOfRangeException.ThrowIfNegative(stateWords);
        ArgumentOutOfRangeException.ThrowIfNegative(arenaWords);
        if (40L + ((long)stateWords + arenaWords) * sizeof(uint) + TrailerBytes > WarpCoreCLRWorkerWords.MaximumBytes)
        { throw new InvalidDataException("The complete initial probe response exceeds finite word transfer admission."); }
    }

    internal static byte[] Response(byte[] request, uint[] state, uint[] arena, Guid module, int entryProgramCounter)
    {
        RequireResponseCapacity(state.Length, arena.Length);
        ArgumentOutOfRangeException.ThrowIfNegative(entryProgramCounter);
        byte[] prefix = WarpCoreCLRWorkerWords.Response(request, state, arena);
        byte[] result = new byte[checked(prefix.Length + TrailerBytes)];
        prefix.CopyTo(result, 0);
        Span<byte> trailer = result.AsSpan(prefix.Length);
        BinaryPrimitives.WriteUInt32LittleEndian(trailer, Magic);
        module.TryWriteBytes(trailer[4..20]);
        BinaryPrimitives.WriteInt32LittleEndian(trailer[20..], 0);
        BinaryPrimitives.WriteInt32LittleEndian(trailer[24..], entryProgramCounter);
        BinaryPrimitives.WriteUInt32LittleEndian(trailer[28..], 1);
        return result;
    }

    internal static Result ReadResponse(byte[] payload, byte[] request, int stateWords, int arenaWords,
        Guid module, int entryProgramCounter)
    {
        RequireResponseCapacity(stateWords, arenaWords);
        int prefixBytes = checked(40 + checked(stateWords + arenaWords) * sizeof(uint));
        if (payload.Length != prefixBytes + TrailerBytes)
        { throw new InvalidDataException("The complete kind19 envelope is missing or has trailing data."); }
        ReadOnlySpan<byte> trailer = payload.AsSpan(prefixBytes);
        if (BinaryPrimitives.ReadUInt32LittleEndian(trailer) != Magic || new Guid(trailer[4..20]) != module ||
            BinaryPrimitives.ReadInt32LittleEndian(trailer[20..]) != 0 ||
            BinaryPrimitives.ReadInt32LittleEndian(trailer[24..]) != entryProgramCounter ||
            BinaryPrimitives.ReadUInt32LittleEndian(trailer[28..]) != 1)
        { throw new InvalidDataException("The initial probe changed its actual module or emitted entry encounter."); }
        // This prefix is parsed as data only, never authenticated as a kind5 frame.
        (uint[] state, uint[] arena) = WarpCoreCLRWorkerWords.ReadResponse(payload.AsSpan(0, prefixBytes).ToArray(), request, stateWords, arenaWords);
        return new(state, arena, module, 0, entryProgramCounter);
    }

    internal sealed record Result(uint[] State, uint[] Arena, Guid Module, int EntryFunction, int EntryProgramCounter);
}
