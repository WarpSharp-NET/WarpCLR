using System.Reflection;
using System.Runtime.CompilerServices;
using WarpCLR.IR;

namespace WarpCLR.Backend.CoreCLR;

// Collectible IL needs a public entry. Only the synchronous, authenticated
// internal invocation can activate it; the result conveys no Source permission.
public static partial class CoreCLRInitialEntryProbe
{
    internal const string Semantics = "warp.coreclr/actual-emitted-initial-entry-authenticated-kind18-before-all-nodes-ordinary-banks-zero-carrier-no-source-grant/0.1";
    private static readonly object EmissionIssuer = new();
    private static readonly object ScopeIssuer = new();
    private static readonly ConditionalWeakTable<MethodInfo, Emission> Emissions = new();
    private static readonly ConditionalWeakTable<WarpCoreCLRWorkerProtocol.Frame, object> UsedRequests = new();
    private static readonly Lock RequestGate = new();
    [ThreadStatic]
    private static Scope? current;

    public static bool StopAtEntry(object token, uint[][] inputs, uint[] scalars, int worker, uint[] state,
        int maximumCallDepth, int quantum, uint[] arena)
    {
        Scope? scope = current;
        if (scope is null) { return false; }
        if (!ReferenceEquals(token, scope.Emission) || !Emissions.TryGetValue(scope.Emission.Method, out Emission? actual) ||
            !ReferenceEquals(actual, token))
        { throw new InvalidOperationException("The initial entry belongs to another actual emitted method."); }
        // Scope and emission identities precede any caller bank access.
        scope.Encounter(inputs, scalars, worker, state, maximumCallDepth, quantum, arena);
        return true;
    }

    internal static void RegisterEmission(WarpLogicalMachineLayout layout, MethodInfo method, FieldInfo field)
    {
        if (!ReferenceEquals(field.DeclaringType, method.DeclaringType) || field.FieldType != typeof(object) ||
            !field.IsPrivate || !field.IsStatic || field.GetValue(null) is not null)
        { throw new InvalidOperationException("The entry probe requires its own fresh private emitted field."); }
        var emission = new Emission(EmissionIssuer, layout, method);
        field.SetValue(null, emission);
        Emissions.Add(method, emission);
    }

    internal static void RequireEmission(WarpLogicalMachineLayout layout, MethodInfo method) => _ = FindEmission(layout, method);

    internal static Scope Begin(WarpCoreCLRWorkerProtocol.Frame frame, byte[] sessionKey, ulong sequence,
        CoreCLRResumableKernel kernel)
    {
        byte[] payload = WarpCoreCLRWorkerProtocol.RequireAuthenticatedFrame(frame, sessionKey,
            WarpCoreCLRInitialEntryProbeWords.Probe, sequence);
        Emission emission = FindEmission(kernel.Layout, kernel.CompiledEntryPoint);
        if (current is not null) { throw new InvalidOperationException("An initial entry probe cannot nest."); }
        lock (RequestGate)
        {
            if (UsedRequests.TryGetValue(frame, out _))
            { throw new InvalidOperationException("The actual authenticated probe request has already been consumed."); }
            UsedRequests.Add(frame, new object());
        }
        var scope = new Scope(ScopeIssuer, emission, frame, sessionKey, sequence, payload);
        current = scope;
        return scope;
    }

    private static Emission FindEmission(WarpLogicalMachineLayout layout, MethodInfo method)
    {
        if (!Emissions.TryGetValue(method, out Emission? emission) || !ReferenceEquals(emission.Layout, layout))
        { throw new InvalidOperationException("The probe requires the actual compiler-registered method and layout objects."); }
        return emission;
    }

    internal static void RequireInvocation(Scope scope, CoreCLRResumableKernel kernel)
    {
        if (scope is null || !ReferenceEquals(current, scope) || !ReferenceEquals(FindEmission(kernel.Layout, kernel.CompiledEntryPoint), scope.Emission))
        { throw new InvalidOperationException("Only the active authenticated scope may invoke its exact compiled entry."); }
        scope.RequireActive();
    }

    internal sealed class Emission
    {
        internal Emission(object issuer, WarpLogicalMachineLayout layout, MethodInfo method)
        {
            if (!ReferenceEquals(issuer, EmissionIssuer))
            { throw new InvalidOperationException("The actual emission issuer is required."); }
            Layout = layout; Method = method;
            EntryProgramCounter = layout.GetBlockEntry(0, 0);
        }
        internal WarpLogicalMachineLayout Layout { get; }
        internal MethodInfo Method { get; }
        internal int EntryProgramCounter { get; }
    }
}
