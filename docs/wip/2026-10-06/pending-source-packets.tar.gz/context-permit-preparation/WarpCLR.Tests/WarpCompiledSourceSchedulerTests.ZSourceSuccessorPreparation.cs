using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpCompiledSourceSchedulerTests
{
    [TestMethod]
    public async Task CompleteOrdinarySourceCheckpointNeverBecomesANormalizedParkedSuccessorPermit()
    {
        WarpCompiledSourceContext context = Create(nameof(Kernels.Loop), 1, 1, [[7]]);
        RemoteModules modules = await RemoteModules.CreateAsync(context, new()).ConfigureAwait(false);
        await using var moduleOwner = modules.ConfigureAwait(false);
        WarpCompiledWorkerTicket ticket = context.Claim(0)!;
        var adapter = new WarpCompiledRemoteSourceAdapter(context, modules.Source, modules.CompareExchange, modules.Census);
        Assert.IsNull(await adapter.ExecuteAsync(await adapter.PrepareAsync(ticket).ConfigureAwait(false)).ConfigureAwait(false));
        WarpCompiledSourceContext.SourceCheckpoint checkpoint = context.RequireCommittedSourceCheckpoint(ticket, modules.Source);
        Assert.IsNotNull(checkpoint.Completion);
        Assert.IsEmpty(checkpoint.Completion.CopyHistoricalRequest().Scalars);
        uint[] state = context.MachineState(ticket.Worker).ToArray(), arena = (uint[])context.Arena.Clone();
        Assert.ThrowsExactly<NotSupportedException>(() => context.PrepareCommittedSourceSuccessor(ticket, modules.Source, checkpoint));
        Assert.AreSame(checkpoint, context.RequireCommittedSourceCheckpoint(ticket, modules.Source));
        CollectionAssert.AreEqual(state, context.MachineState(ticket.Worker).ToArray()); CollectionAssert.AreEqual(arena, context.Arena);
        Assert.IsTrue(ticket.Executed); Assert.AreEqual(1u, context.WorkerQuanta(ticket.Worker));
        // Preserve the existing ordinary path and its checkpoint unchanged.
        context.Commit(ticket);
        Assert.ThrowsExactly<InvalidOperationException>(() => context.PrepareCommittedSourceSuccessor(ticket, modules.Source, checkpoint));
    }
}
