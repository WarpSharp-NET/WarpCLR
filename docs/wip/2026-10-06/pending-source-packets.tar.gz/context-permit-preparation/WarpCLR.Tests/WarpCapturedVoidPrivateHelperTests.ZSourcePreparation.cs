using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpCapturedVoidPrivateHelperTests
{
    private static readonly Lazy<WarpCompiledRuntimeServices> SourcePreparationServices = new(static () => new());

    [TestMethod]
    public async Task AuthenticInitialSourcePreparationRetainsAllOriginalBanksWithoutGrantOrWordMutation()
    {
        WarpCompiledSourceContext context = CreateSourcePreparationContext();
        WarpCompiledWorkerTicket ticket = context.Claim(0)!;
        Assert.IsNotNull(ticket);
        WarpCoreCLRWorkerKernel kernel = await WarpCoreCLRWorkerKernel.CompileAsync(context.Plan.Layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var kernelOwner = kernel.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = kernel.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        using var receipt = await context.ProbeInitialBeforeBodyAsync(ticket, lease).ConfigureAwait(false);
        uint[] arena = (uint[])context.Arena.Clone(), state = context.MachineState(0).ToArray();
        uint claims = context.FailedControllerClaims;
        WarpCompiledSourceContext.SourcePermitPreparation preparation = context.PrepareInitialSourcePermit(ticket, lease, receipt);
        preparation.Revalidate(context, ticket, lease);
        Assert.AreEqual(WarpCompiledSourceContext.SourcePermitPreparation.PreparationPhase.ReceiptValidated, preparation.Phase);
        CollectionAssert.AreEqual(arena, context.Arena); CollectionAssert.AreEqual(state, context.MachineState(0).ToArray());
        Assert.AreEqual(claims, context.FailedControllerClaims); Assert.AreEqual(0u, context.WorkerQuanta(0));
        Assert.IsFalse(ticket.Executed); Assert.IsFalse(ticket.Executing); Assert.IsNull(receipt.PreviousSourceCheckpoint);
        Assert.ThrowsExactly<NotSupportedException>(preparation.RequireSourceDispatch);
        Assert.ThrowsExactly<InvalidOperationException>(() => context.PrepareInitialSourcePermit(ticket, lease, receipt));
        Assert.ThrowsExactly<InvalidOperationException>(() => preparation.Revalidate(null!, ticket, lease));
        Assert.ThrowsExactly<InvalidOperationException>(() => preparation.Revalidate(context,
            new(context, ticket.Worker, ticket.Physical, ticket.Generation, ticket.Dispatch), lease));
        WarpCoreCLRWorkerLease otherLease = lease.Retain();
        await using var retainedOwner = otherLease.ConfigureAwait(false);
        Assert.ThrowsExactly<InvalidOperationException>(() => preparation.Revalidate(context, ticket, otherLease));
        CollectionAssert.AreEqual(arena, context.Arena); CollectionAssert.AreEqual(state, context.MachineState(0).ToArray());
        // The independent controller remains ordinary; no Source freeze or CAS
        // is implied by preparing a nonce. This unit has no dispatch permission.
        Assert.AreEqual(0u, context.Arena[context.Scheduler + WarpPortableSchedulerLayout.ControllerOwner]);
    }

    [TestMethod]
    [DataRow("arena")]
    [DataRow("other-state")]
    [DataRow("receipt-disposed")]
    public async Task AChangedOrRetiredInitialLineageKeepsTheExactFirstFailureAfterRestoration(string mutation)
    {
        WarpCompiledSourceContext context = CreateSourcePreparationContext(workers: 2, residents: 2);
        WarpCompiledWorkerTicket ticket = context.Claim(0)!, other = context.Claim(1)!;
        Assert.IsNotNull(ticket); Assert.IsNotNull(other);
        WarpCoreCLRWorkerKernel kernel = await WarpCoreCLRWorkerKernel.CompileAsync(context.Plan.Layout, new(), CancellationToken.None).ConfigureAwait(false);
        await using var kernelOwner = kernel.ConfigureAwait(false);
        WarpCoreCLRWorkerLease lease = kernel.TryAcquireLease()!;
        await using var leaseOwner = lease.ConfigureAwait(false);
        using var receipt = await context.ProbeInitialBeforeBodyAsync(ticket, lease).ConfigureAwait(false);
        WarpCompiledSourceContext.SourcePermitPreparation preparation = context.PrepareInitialSourcePermit(ticket, lease, receipt);
        uint[] bank = mutation == "other-state" ? context.RemoteSourceState(other) : context.Arena;
        int index = bank.Length - 1;
        if (mutation == "receipt-disposed") { receipt.Dispose(); }
        else { bank[index] ^= 1; }
        InvalidOperationException first = Assert.ThrowsExactly<InvalidOperationException>(() => preparation.Revalidate(context, ticket, lease));
        if (mutation != "receipt-disposed") { bank[index] ^= 1; }
        InvalidOperationException repeated = Assert.ThrowsExactly<InvalidOperationException>(() => preparation.Revalidate(context, ticket, lease));
        Assert.AreSame(first, repeated);
        Assert.AreSame(first, Assert.ThrowsExactly<InvalidOperationException>(preparation.RequireSourceDispatch));
        Assert.AreSame(first, Assert.ThrowsExactly<InvalidOperationException>(() => context.PrepareInitialSourcePermit(ticket, lease, receipt)));
        Assert.AreEqual(WarpCompiledSourceContext.SourcePermitPreparation.PreparationPhase.FailedUnknown, preparation.Phase);
        Assert.IsFalse(ticket.Executed); Assert.AreEqual(0u, context.WorkerQuanta(ticket.Worker));
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void SourcePreparationRequiresTheExactContextSecretBeforeCandidateFieldsOrBanks(bool corruptArena)
    {
        WarpCompiledSourceContext context = CreateSourcePreparationContext();
        uint saved = context.Arena[WarpPortableHeapLayout.Context];
        if (corruptArena) { context.Arena[WarpPortableHeapLayout.Context] = uint.MaxValue; }
        try
        {
            Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCompiledSourceContext.SourcePermitPreparation(
                context, null!, null!, null!, new object()));
            Assert.ThrowsExactly<InvalidOperationException>(() => new WarpCompiledSourceContext.SourcePermitPreparation(
                null!, null!, null!, null!, new object()));
        }
        finally { context.Arena[WarpPortableHeapLayout.Context] = saved; }
    }

    private static WarpCompiledSourceContext CreateSourcePreparationContext(uint workers = 1, uint residents = 1)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(typeof(Guest).GetMethod(nameof(Guest.Empty))!);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
        WarpPortableWordLoweredProgram program = WarpPortableWordLowerer.Lower(graph, typed, schema, new VoidBinding(graph, typed, schema));
        var plan = new WarpCompiledSourcePlan(graph, schema, program, workers, residents, 8, 100, 4096, SourcePreparationServices.Value);
        uint[] heap = plan.CreateUnusedHeap(WarpLogicalOwnerNamespace.Next(), 1024, 64, 64, 1024);
        return new(plan, heap, []);
    }
}
