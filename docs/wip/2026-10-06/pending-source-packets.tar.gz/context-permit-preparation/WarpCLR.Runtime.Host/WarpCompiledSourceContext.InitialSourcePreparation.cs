namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    internal sealed partial class InitialBeforeBodyReceipt
    {
        internal uint[] RequireSourcePreparationCarrier(WarpCompiledSourceContext exactContext,
            WarpCompiledWorkerTicket exactTicket, WarpCoreCLRWorkerLease exactSource, object authority)
        {
            if (exactContext is null || !ReferenceEquals(authority, exactContext.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context issuer may consume its retained initial transport lineage."); }
            ValidateInitial(exactContext, exactTicket, exactSource);
            // This is the actual raw array captured by kind18/19, not a copied
            // or normalized []/[TOKEN] argument, nor a general permission.
            if (attempt.Carrier.Length != 1 || attempt.Carrier[0] != 0)
            { throw new InvalidOperationException("The actual before-body SourceBank carrier must still be exact raw[0]."); }
            return attempt.Carrier;
        }
    }
}
