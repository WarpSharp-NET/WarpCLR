using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    internal const string SourcePreparationSemantics =
        "warp.context-source-preparation/exact-initial-kind19-context-compiler-objects-all-bank-snapshots-nonreused128nonce-no-ready-grant-transfer/0.1";
    private SourcePermitPreparation? sourcePreparation;

    // A preparation is retained consistency evidence. It cannot authorize a
    // Source RPC, CAS, controller freeze, guest call or normal release.
    internal SourcePermitPreparation PrepareInitialSourcePermit(WarpCompiledWorkerTicket ticket,
        WarpCoreCLRWorkerLease source, InitialBeforeBodyReceipt receipt)
    {
        SourcePermitPreparation preparation;
        lock (executionIdentityGate)
        {
            if (sourcePreparation is not null)
            { sourcePreparation.RejectDuplicate(this, ticket, source, receipt, sourceCheckpointAuthority); }
            preparation = new(this, ticket, source, receipt, sourceCheckpointAuthority);
            sourcePreparation = preparation;
        }
        try
        {
            // RNG, receipt validation and snapshot hashing are outside the
            // registry gate. No child or asynchronous operation is started.
            preparation.Capture(sourceCheckpointAuthority);
            lock (executionIdentityGate)
            {
                preparation.Revalidate(this, ticket, source, sourceCheckpointAuthority);
                preparation.FinishReceiptValidation(sourceCheckpointAuthority);
            }
            return preparation;
        }
        catch (Exception failure)
        {
            lock (executionIdentityGate) { preparation.RecordFailure(sourceCheckpointAuthority, failure); }
            throw;
        }
    }

    // No current API supplies an authenticated parked successor with raw[0].
    // Preserve the complete existing [] checkpoint and deny, rather than
    // manufacture a new origin from its returned PC or historical call list.
    internal SourcePermitPreparation PrepareCommittedSourceSuccessor(WarpCompiledWorkerTicket ticket,
        WarpCoreCLRWorkerLease source, SourceCheckpoint checkpoint)
    {
        lock (executionIdentityGate)
        {
            RequireSourcePreparationMetadata(ticket, source, initial: false);
            if (checkpoint is null || !sourceCheckpoints.TryGetValue(states[ticket.Worker], out SourceCheckpoint? issued) ||
                !ReferenceEquals(issued, checkpoint))
            { throw new InvalidOperationException("The Source successor must retain its exact Context-issued historical predecessor."); }
            checkpoint.Validate(this, ticket, source);
            if (checkpoint.Completion is not { } completion)
            { throw new InvalidOperationException("The Source successor has no exact retained authenticated completion history."); }
            completion.ValidateHistorical(this, ticket, source, checkpoint);
            throw new NotSupportedException("A committed ordinary [] checkpoint is not an authenticated raw[0] parked successor or Source-purpose origin.");
        }
    }

    private void RequireSourcePreparationMetadata(WarpCompiledWorkerTicket ticket, WarpCoreCLRWorkerLease source, bool initial)
    {
        Plan.RequireCompletionCompilerSeal();
        if (ticket is null || source is null || !ReferenceEquals(ticket.Context, this) || ticket.Worker >= Plan.Workers ||
            !ReferenceEquals(tickets[ticket.Worker], ticket) || ticket.Released || ticket.Executing ||
            source.IsReleased || source.IsFaulted || !source.IsCollectible || source.CompiledModule == Guid.Empty ||
            source.ProcessId <= 1 || !ReferenceEquals(source.Layout, Plan.Layout) || stopped != 0 || remoteCensus is not null ||
            helpers[ticket.Worker] is not null || allocations[ticket.Worker] != 0 || sourceLeases[ticket.Worker] ||
            sourceLoanStarted[ticket.Worker] || initial == ticket.Executed)
        { throw new InvalidOperationException("Source preparation requires exact live compiler, Context, ticket, source lease and original storage metadata."); }
        if (initial && (executionQuanta[ticket.Worker] != 0 || sourceCheckpoints.TryGetValue(states[ticket.Worker], out _)))
        { throw new InvalidOperationException("An initial preparation cannot substitute a previously executed Source outcome."); }
        WarpCoreCLRWordTransaction.RequireUnquarantinedInitialProbeStorage(states[ticket.Worker], Arena);
    }

    private void RequireCurrentSourcePreparation(SourcePermitPreparation preparation, object authority)
    {
        if (!ReferenceEquals(authority, sourceCheckpointAuthority))
        { throw new InvalidOperationException("Only the exact Context secret may inspect its Source preparation."); }
        if (!ReferenceEquals(sourcePreparation, preparation))
        { throw new InvalidOperationException("An unissued, cloned, stale or foreign preparation is not the current exact object."); }
    }
}
