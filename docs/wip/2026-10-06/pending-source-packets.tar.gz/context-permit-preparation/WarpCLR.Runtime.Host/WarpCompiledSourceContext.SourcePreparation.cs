using System.Runtime.ExceptionServices;
using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    internal sealed class SourcePermitPreparation
    {
        private readonly WarpCompiledSourceContext context;
        private readonly WarpCompiledWorkerTicket ticket;
        private readonly WarpCoreCLRWorkerLease source;
        private readonly InitialBeforeBodyReceipt receipt;
        private readonly WarpPortableWordProgramIdentity compiler;
        private readonly WarpCompiledInitialEntryProjection projection;
        private SourcePreparationBanks? banks;
        private SourcePreparationNonce? nonce;
        private ExceptionDispatchInfo? failure;
        private PreparationPhase phase;

        internal SourcePermitPreparation(WarpCompiledSourceContext context, WarpCompiledWorkerTicket ticket,
            WarpCoreCLRWorkerLease source, InitialBeforeBodyReceipt receipt, object authority)
        {
            // Exact issuer first: no caller fields, carrier or bank words yet.
            if (context is null || !ReferenceEquals(authority, context.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context secret may create a Source preparation."); }
            context.RequireSourcePreparationMetadata(ticket, source, initial: true);
            if (receipt is null || !context.initialProbeReceipts.TryGetValue(ticket, out InitialBeforeBodyReceipt? issued) ||
                !ReferenceEquals(issued, receipt))
            { throw new InvalidOperationException("The initial preparation requires its exact privately issued before-body receipt."); }
            // The immutable SourceBank layout is a consistency requirement.
            // Private metadata never changes this object into a dispatch grant.
            if (context.Plan.Layout.Kernel.ScalarArgumentCount != 1 ||
                context.Plan.Layout.Kernel.Execution?.PrivateControllerProjection is not { } privateChannel ||
                !privateChannel.RequiresHelperBoundaries || !privateChannel.RequiresHelperReturnFences)
            { throw new InvalidOperationException("Source preparation requires the exact compiler-sealed one-word SourceBank layout."); }
            if (context.inputs.Length > SourcePreparationBanks.MaximumBanks || context.states.Length > SourcePreparationBanks.MaximumBanks ||
                context.inputs.Length + context.states.Length + 2 > SourcePreparationBanks.MaximumBanks)
            { throw new InvalidOperationException("The bounded preparation cannot retain this original bank union."); }
            this.context = context; this.ticket = ticket; this.source = source; this.receipt = receipt;
            compiler = context.Plan.CompilerIdentity; projection = receipt.Projection;
            if (!ReferenceEquals(compiler, projection.CompilerIdentity) || projection.Invocation.OriginKind != 2 ||
                projection.Invocation.SourceOffset is not null || projection.Invocation.SourceOpCode is not null ||
                projection.Invocation.EffectIndex is not null || !projection.Invocation.Effects.IsEmpty ||
                !projection.Invocation.ExceptionMemberships.IsEmpty || receipt.PreviousSourceCheckpoint is not null)
            { throw new InvalidOperationException("The initial preparation requires a genuine null-predecessor EntryInvocation projection without fabricated CIL/EH."); }
        }

        internal PreparationPhase Phase
        {
            get
            {
                lock (context.executionIdentityGate)
                {
                    context.RequireCurrentSourcePreparation(this, context.sourceCheckpointAuthority);
                    return phase;
                }
            }
        }

        internal void Capture(object authority)
        {
            context.RequireCurrentSourcePreparation(this, authority);
            uint[] carrier = receipt.RequireSourcePreparationCarrier(context, ticket, source, authority);
            banks = new SourcePreparationBanks(context, carrier, authority);
            nonce = context.ReserveSourcePreparationNonce(this, authority);
            banks.CaptureHashes(authority);
        }

        internal void Revalidate(WarpCompiledSourceContext exactContext, WarpCompiledWorkerTicket exactTicket,
            WarpCoreCLRWorkerLease exactSource)
        {
            lock (context.executionIdentityGate)
            {
                Revalidate(exactContext, exactTicket, exactSource, context.sourceCheckpointAuthority);
            }
        }

        internal void Revalidate(WarpCompiledSourceContext exactContext, WarpCompiledWorkerTicket exactTicket,
            WarpCoreCLRWorkerLease exactSource, object authority)
        {
            // Registry identity before candidate fields, then sticky failure.
            context.RequireCurrentSourcePreparation(this, authority);
            if (!ReferenceEquals(context, exactContext) || !ReferenceEquals(ticket, exactTicket) || !ReferenceEquals(source, exactSource))
            { throw new InvalidOperationException("A Source preparation belongs to one exact Context, ticket and source lease."); }
            failure?.Throw();
            try
            {
                context.RequireSourcePreparationMetadata(ticket, source, initial: true);
                if (!ReferenceEquals(compiler, context.Plan.CompilerIdentity) || !ReferenceEquals(projection, receipt.Projection) ||
                    nonce is null || banks is null)
                { throw new InvalidOperationException("An incomplete reservation has no validated Source history or nonce."); }
                nonce.RequireReservation(context, this, authority);
                banks.Validate(context, receipt.RequireSourcePreparationCarrier(context, ticket, source, authority), authority);
            }
            catch (Exception error) { RecordFailure(authority, error); throw; }
        }

        internal void FinishReceiptValidation(object authority)
        {
            context.RequireCurrentSourcePreparation(this, authority);
            failure?.Throw();
            if (phase != PreparationPhase.Reserved || banks is null || nonce is null)
            { throw new InvalidOperationException("A preparation may finish its receipt validation only once."); }
            phase = PreparationPhase.ReceiptValidated;
        }

        internal void RejectDuplicate(WarpCompiledSourceContext exactContext, WarpCompiledWorkerTicket exactTicket,
            WarpCoreCLRWorkerLease exactSource, InitialBeforeBodyReceipt exactReceipt, object authority)
        {
            context.RequireCurrentSourcePreparation(this, authority);
            if (!ReferenceEquals(context, exactContext) || !ReferenceEquals(ticket, exactTicket) ||
                !ReferenceEquals(source, exactSource) || !ReferenceEquals(receipt, exactReceipt))
            { throw new InvalidOperationException("Another lineage cannot replace the Context's retained Source preparation."); }
            failure?.Throw();
            throw new InvalidOperationException("This Context already retains its bounded single Source preparation.");
        }

        internal void RecordFailure(object authority, Exception error)
        {
            context.RequireCurrentSourcePreparation(this, authority);
            failure ??= ExceptionDispatchInfo.Capture(error);
            phase = PreparationPhase.FailedUnknown;
            // Do not drop historical objects or the nonce tombstone. No
            // authenticated unused-ready abort or stopped-release API exists.
        }

        internal void RequireSourceDispatch()
        {
            lock (context.executionIdentityGate)
            {
                context.RequireCurrentSourcePreparation(this, context.sourceCheckpointAuthority);
                failure?.Throw();
                throw new NotSupportedException("A prepared nonce is not Ready/Granted/Transferred: independent CAS, owner hold, private Source RPC and publication/release receipts remain unavailable.");
            }
        }

        internal enum PreparationPhase { Reserved, ReceiptValidated, FailedUnknown }
    }
}
