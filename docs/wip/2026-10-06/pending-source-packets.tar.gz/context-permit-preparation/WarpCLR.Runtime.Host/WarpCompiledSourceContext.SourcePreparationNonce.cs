using System.Buffers.Binary;
using System.Runtime.Loader;
using System.Security.Cryptography;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    private const int MaximumSourceNonceTombstones = 4096;
    private const int MaximumSourceNonceAttempts = 8;
    private static readonly Lock SourceNonceGate = new();
    private static readonly HashSet<SourceNonceKey> SourceNonceTombstones = [];

    private SourcePreparationNonce ReserveSourcePreparationNonce(SourcePermitPreparation preparation, object authority)
    {
        // Exact Context/current object before RNG or candidate fields.
        RequireCurrentSourcePreparation(preparation, authority);
        if (typeof(WarpCompiledSourceContext).Assembly.IsCollectible ||
            !ReferenceEquals(AssemblyLoadContext.GetLoadContext(typeof(WarpCompiledSourceContext).Assembly), AssemblyLoadContext.Default))
        { throw new InvalidOperationException("Nonce tombstones require the exact noncollectible default-context Host issuer lifetime."); }
        Span<byte> bytes = stackalloc byte[16];
        for (int attempt = 0; attempt < MaximumSourceNonceAttempts; attempt++)
        {
            // No RNG, hashing, async or cleanup while the registry gate is held.
            RandomNumberGenerator.Fill(bytes);
            var nonce = new SourceNonceKey(BinaryPrimitives.ReadUInt64LittleEndian(bytes),
                BinaryPrimitives.ReadUInt64LittleEndian(bytes[8..]));
            if (nonce.Low == 0 && nonce.High == 0) { continue; }
            lock (SourceNonceGate)
            {
                if (SourceNonceTombstones.Count >= MaximumSourceNonceTombstones)
                { throw new InvalidOperationException("The process-lifetime Source nonce tombstone bound is exhausted."); }
                if (SourceNonceTombstones.Add(nonce)) { return new(this, preparation, nonce); }
            }
        }
        throw new InvalidOperationException("A fresh nonrepeating 128-bit Source preparation nonce could not be reserved.");
    }

    // Never cleared on collection, Context disposal, failure or later physical
    // containment. This namespace is process-lifetime only; no cross-restart
    // uniqueness or authenticated session transport is claimed here.
    private readonly record struct SourceNonceKey(ulong Low, ulong High);

    private sealed class SourcePreparationNonce
    {
        private readonly WarpCompiledSourceContext context;
        private readonly SourcePermitPreparation preparation;
        private readonly SourceNonceKey key;

        internal SourcePreparationNonce(WarpCompiledSourceContext context, SourcePermitPreparation preparation, SourceNonceKey key)
        { this.context = context; this.preparation = preparation; this.key = key; }

        internal void RequireReservation(WarpCompiledSourceContext exactContext, SourcePermitPreparation exactPreparation, object authority)
        {
            if (exactContext is null || !ReferenceEquals(authority, exactContext.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context issuer may inspect a reserved nonce."); }
            exactContext.RequireCurrentSourcePreparation(exactPreparation, authority);
            if (!ReferenceEquals(context, exactContext) || !ReferenceEquals(preparation, exactPreparation))
            { throw new InvalidOperationException("A nonce reservation belongs to one exact privately issued preparation."); }
            lock (SourceNonceGate)
            {
                if (!SourceNonceTombstones.Contains(key))
                { throw new InvalidOperationException("The process-lifetime nonce reservation is missing."); }
            }
        }
    }
}
