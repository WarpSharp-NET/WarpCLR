using System.Runtime.InteropServices;
using System.Security.Cryptography;
using WarpCLR.IR;

namespace WarpCLR.Runtime.Host;

internal sealed partial class WarpCompiledSourceContext
{
    private sealed class SourcePreparationBanks
    {
        internal const int MaximumBanks = 8192;
        private readonly WarpCompiledSourceContext context;
        private readonly uint[][] outer;
        private readonly uint[][] inputs;
        private readonly uint[][] states;
        private readonly uint[] carrier;
        private readonly uint[] arena;
        private readonly uint[][] union;
        private byte[][]? hashes;

        internal SourcePreparationBanks(WarpCompiledSourceContext context, uint[] carrier, object authority)
        {
            if (context is null || !ReferenceEquals(authority, context.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context may retain its original Source bank objects."); }
            this.context = context; this.carrier = carrier; arena = context.Arena; outer = context.inputs;
            states = (uint[][])context.states.Clone();
            using WarpOrdinaryArrayAdmission admitted = WarpOrdinaryArrayAdmission.Acquire(outer, carrier, [], arena);
            inputs = WarpCoreCLRWorkerProcess.CaptureProbeInputs(admitted, outer.Length);
            var banks = new HashSet<uint[]>(ReferenceEqualityComparer.Instance) { carrier, arena };
            banks.UnionWith(inputs); banks.UnionWith(states);
            if (banks.Count > MaximumBanks)
            { throw new InvalidOperationException("The bounded original Source bank union is exhausted."); }
            union = banks.ToArray();
            // All source workers' original state arrays participate in this
            // ordinary denial ledger. This is not an owner hold or permission.
        }

        internal void CaptureHashes(object authority)
        {
            if (!ReferenceEquals(authority, context.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context may capture its retained Source bank hashes."); }
            if (hashes is not null) { throw new InvalidOperationException("The retained original bank union can be captured only once."); }
            // The preparation retains this object before any digest work or
            // nonce failure, so unknown outcomes cannot discard the bank union.
            using WarpOrdinaryArrayAdmission all = WarpOrdinaryArrayAdmission.Acquire(union, carrier, [], arena);
            hashes = Enumerable.Range(0, union.Length).Select(index => Hash(all.GetInput(index))).ToArray();
        }

        internal void Validate(WarpCompiledSourceContext exactContext, uint[] exactCarrier, object authority)
        {
            if (exactContext is null || !ReferenceEquals(authority, exactContext.sourceCheckpointAuthority))
            { throw new InvalidOperationException("Only the exact Context may revalidate its bank lineage."); }
            // References and shape before candidate bank contents.
            if (!ReferenceEquals(context, exactContext) || !ReferenceEquals(outer, context.inputs) ||
                !ReferenceEquals(carrier, exactCarrier) || !ReferenceEquals(arena, context.Arena) ||
                inputs.Length != outer.Length || states.Length != context.states.Length ||
                inputs.Where((bank, index) => !ReferenceEquals(bank, outer[index])).Any() ||
                states.Where((bank, index) => !ReferenceEquals(bank, context.states[index])).Any())
            { throw new InvalidOperationException("Source preparation replaced an original input, carrier, state or arena object."); }
            if (hashes is null) { throw new InvalidOperationException("The original Source bank reservation has no completed full snapshot."); }
            using WarpOrdinaryArrayAdmission all = WarpOrdinaryArrayAdmission.Acquire(union, carrier, [], arena);
            if (carrier.Length != 1 || carrier[0] != 0)
            { throw new InvalidOperationException("Source preparation never normalizes an empty or nonzero carrier to raw[0]."); }
            for (int index = 0; index < union.Length; index++)
            {
                if (!CryptographicOperations.FixedTimeEquals(hashes[index], Hash(all.GetInput(index))))
                { throw new InvalidOperationException("A complete original Source preparation bank changed after reservation."); }
            }
        }

        private static byte[] Hash(uint[] bank) => SHA256.HashData(MemoryMarshal.AsBytes(bank.AsSpan()));
    }
}
