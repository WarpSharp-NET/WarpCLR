using System.Globalization;
using System.Reflection.Emit;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableFloating16Tests
{
    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task CapturedOriginalCilRunsInAnActualOrdinaryChildAtBothQuanta(bool wide)
    {
        foreach (string name in Names(wide))
        {
            WarpPortableWordLoweredProgram program = Capture(name);
            var layout = new WarpLogicalMachineLayout(program.Kernel);
            string directory = EvidenceDirectory(name);
            RecordOriginalSource(program, Source(name), directory);
            WarpCoreCLRWorkerProcess child = await CompileChildAsync(layout, directory).ConfigureAwait(false);
            try
            {
                int budget = program.Bodies.Sum(body => body.SourceBlocks.Length);
                uint[] initial = layout.CreateInitialState(32, budget);
                int vector = 0;
                foreach (uint[] input in WarpPortableFloating16Seeds.Words(wide))
                {
                    uint[]? prior = null;
                    foreach (int quantum in new[] { layout.MaximumBlockCost, Math.Max(4096, checked(layout.MaximumBlockCost + 1)) })
                    {
                        uint[] completed = await RunChildAsync(child, layout, initial, input, quantum, directory, vector).ConfigureAwait(false);
                        Assert.AreEqual(WarpLogicalMachineLayout.Completed, completed[WarpLogicalMachineLayout.StatusOffset]);
                        Assert.AreEqual(0u, completed[WarpLogicalMachineLayout.RemainingStepsLowOffset]);
                        Assert.AreEqual(0u, completed[WarpLogicalMachineLayout.RemainingStepsHighOffset]);
                        uint[] result = Enumerable.Range(0, layout.ResultWordCount).Select(word => completed[layout.GetResultWordOffset(word, 32)]).ToArray();
                        CollectionAssert.AreEqual(WarpPortableFloating16Oracle.Result(name, input), result);
                        if (prior is not null) { CollectionAssert.AreEqual(prior, completed); }
                        prior = completed;
                    }
                    vector++;
                }
            }
            finally { await StopChildAsync(child, directory).ConfigureAwait(false); }
        }
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task OneShortBudgetStopsAtTheExactOriginalReturnWithoutAConversionFault(bool wide)
    {
        string name = wide ? "DoubleSignedI4" : "SingleSignedI4";
        WarpPortableWordLoweredProgram program = Capture(name);
        WarpPortableWordBody body = EntryBody(program, name);
        var layout = new WarpLogicalMachineLayout(program.Kernel);
        string directory = EvidenceDirectory(name + "-one-short");
        RecordOriginalSource(program, Source(name), directory);
        WarpCoreCLRWorkerProcess child = await CompileChildAsync(layout, directory).ConfigureAwait(false);
        try
        {
            uint[] initial = layout.CreateInitialState(32, program.Bodies.Sum(item => item.SourceBlocks.Length) - 1);
            uint[] input = wide ? [0, 0x7FF00000] : [0x7F800000];
            int vector = 0;
            foreach (int quantum in new[] { layout.MaximumBlockCost, Math.Max(4096, checked(layout.MaximumBlockCost + 1)) })
            {
                uint[] stopped = await RunChildAsync(child, layout, initial, input, quantum, directory, vector++).ConfigureAwait(false);
                Assert.AreEqual(WarpLogicalMachineLayout.Faulted, stopped[WarpLogicalMachineLayout.StatusOffset]);
                Assert.AreEqual(WarpLogicalMachineLayout.StepLimitFault, stopped[WarpLogicalMachineLayout.FaultKindOffset]);
                Assert.AreEqual((uint)body.Function, stopped[WarpLogicalMachineLayout.FaultFunctionOffset]);
                WarpPortableWordSourceBlock ret = body.SourceBlocks.Single(block => block.Instruction.OpCode == OpCodes.Ret.Value);
                Assert.AreEqual((uint)ret.Block, stopped[WarpLogicalMachineLayout.FaultBlockOffset]);
                Assert.AreEqual(0u, stopped[WarpLogicalMachineLayout.RemainingStepsLowOffset]);
            }
        }
        finally { await StopChildAsync(child, directory).ConfigureAwait(false); }
    }

    private static async Task<uint[]> RunChildAsync(WarpCoreCLRWorkerProcess child, WarpLogicalMachineLayout layout,
        uint[] initial, uint[] input, int quantum, string directory, int vector)
    {
        uint[] state = (uint[])initial.Clone();
        uint[][] inputs = input.Select(word => new uint[] { word, 0xDEADBEEF, 0x7F800001 }).ToArray();
        uint[] arena = [0xDEADBEEF, 0x80000000, 0x7F800001, 0xFFF00001, uint.MaxValue, 0, 1, 0x12345678];
        string prefix = "v" + vector.ToString("D4", CultureInfo.InvariantCulture) + "-q" + quantum.ToString(CultureInfo.InvariantCulture);
        WriteEvidence(directory, prefix + "-initial", new { State = state, Inputs = inputs, Arena = arena, OriginalInputWords = input, ControllerAuthority = false });
        for (int step = 0; step < 1024 && state[WarpLogicalMachineLayout.StatusOffset] == WarpLogicalMachineLayout.Runnable; step++)
        {
            uint[] before = (uint[])state.Clone();
            uint[] beforeArena = (uint[])arena.Clone();
            uint[][] beforeInputs = inputs.Select(words => (uint[])words.Clone()).ToArray();
            try { await child.ExecuteManagedQuantumAsync(layout, inputs, [], 0, state, 32, quantum, arena, CancellationToken.None).ConfigureAwait(false); }
            catch (Exception failure)
            {
                WriteEvidence(directory, prefix + "-failed" + step.ToString("D4", CultureInfo.InvariantCulture),
                    new { Before = before, After = state, BeforeArena = beforeArena, AfterArena = arena, BeforeInputs = beforeInputs, AfterInputs = inputs, Error = failure.ToString() });
                CollectionAssert.AreEqual(before, state); CollectionAssert.AreEqual(beforeArena, arena);
                for (int index = 0; index < inputs.Length; index++) { CollectionAssert.AreEqual(beforeInputs[index], inputs[index]); }
                throw;
            }
            WarpCoreCLRWorkerProcess.WordCheckpoint receipt = child.RequireCommittedWordCheckpoint(state, arena);
            child.ValidateCommittedWordCheckpoint(receipt, state, arena);
            WriteEvidence(directory, prefix + "-step" + step.ToString("D4", CultureInfo.InvariantCulture),
                new { Before = before, After = state, BeforeArena = beforeArena, AfterArena = arena, BeforeInputs = beforeInputs, AfterInputs = inputs,
                    receipt.Ordinal, receipt.Sequence, receipt.RequestHash, receipt.ResponseHash, receipt.ProcessId, receipt.Module, receipt.IrHash, RootAuthority = false });
            CollectionAssert.AreEqual(beforeArena, arena);
            for (int index = 0; index < inputs.Length; index++) { CollectionAssert.AreEqual(beforeInputs[index], inputs[index]); }
        }
        Assert.AreNotEqual(WarpLogicalMachineLayout.Runnable, state[WarpLogicalMachineLayout.StatusOffset], "Finite source-only proposed trace cap; incomplete means failure.");
        return state;
    }
}
