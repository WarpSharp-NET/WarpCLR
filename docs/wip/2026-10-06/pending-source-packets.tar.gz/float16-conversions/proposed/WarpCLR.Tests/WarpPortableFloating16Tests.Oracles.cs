using System.Reflection;
using System.Runtime.InteropServices;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableFloating16Tests
{
    [TestMethod]
    public void PinnedOriginalClrOracleMatchesEveryIndependentRawBitVector()
    {
        Assert.AreEqual("10.0.12", Environment.Version.ToString(), StringComparer.Ordinal);
        Assert.AreEqual(Architecture.X64, RuntimeInformation.ProcessArchitecture);
        foreach (bool wide in new[] { false, true })
        {
            foreach (string name in Names(wide))
            {
                MethodInfo source = Source(name);
                Assert.IsNotNull(source.GetMethodBody());
                foreach (uint[] input in WarpPortableFloating16Seeds.Words(wide))
                {
                    uint[] independent = WarpPortableFloating16Oracle.Result(name, input);
                    uint[] original = WarpPortableFloating16Oracle.OriginalResult(source, input);
                    CollectionAssert.AreEqual(independent, original, name + ": pinned CLR profile mismatch is a blocker.");
                }
            }
        }
    }

    [TestMethod]
    public void TheSameOriginalDoubleToInt16DenialIdentityRequiresPositiveCaptureAndOracle()
    {
        // The application contract links the exact frozen coverage fixture,
        // rather than changing the original90 list or testing only a new name.
        Type originalType = typeof(WarpPortableFloating16Tests).Assembly.GetType(
            "WarpCLR.Tests.Production.CurrentCoverage.WarpCurrentNumericSourceCases", throwOnError: true)!;
        MethodInfo original = originalType.GetMethod("DoubleToInt16", BindingFlags.Public | BindingFlags.Static)!;
        Assert.AreEqual(typeof(short), original.ReturnType);
        CollectionAssert.AreEqual(new[] { typeof(double) }, original.GetParameters().Select(parameter => parameter.ParameterType).ToArray());
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(original);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableWordLoweredProgram program = WarpPortableWordLowerer.Lower(graph, typed);
        WarpPortableWordProgramIdentity.Validate(graph, WarpPortableSourceHeapSchema.Create(graph, typed), program);
        Assert.IsTrue(graph.Methods.Single(method => method.Identity == graph.EntryIdentity).Instructions.Any(instruction => instruction.OpCode == System.Reflection.Emit.OpCodes.Conv_I2));
        Assert.IsTrue(program.RequiredServices.Any(identity => identity.Contains(WarpPortableFloating16Conversions.Semantics, StringComparison.Ordinal)));
        Assert.AreEqual(1, new WarpLogicalMachineLayout(program.Kernel).ResultWordCount);
        Assert.AreEqual("10.0.12", Environment.Version.ToString(), StringComparer.Ordinal);
        Assert.AreEqual(Architecture.X64, RuntimeInformation.ProcessArchitecture);
        foreach (uint[] input in WarpPortableFloating16Seeds.Words(wide: true))
        {
            CollectionAssert.AreEqual(WarpPortableFloating16Oracle.Result("DoubleToInt16", input),
                WarpPortableFloating16Oracle.OriginalResult(original, input));
        }
    }

    [TestMethod]
    public void AdversarialResultsDistinguishSaturating16Unsigned32AndLegacyOverflow()
    {
        // +infinity uses Int32.MaxValue then low16, so signed I4 is -1.
        Assert.AreEqual(uint.MaxValue, WarpPortableFloating16Oracle.StackWord([0x7F800000], signed: true));
        Assert.AreEqual(65535u, WarpPortableFloating16Oracle.StackWord([0, 0x7FF00000], signed: false));
        // -infinity uses Int32.MinValue; its low16 is zero for BOTH opcodes.
        Assert.AreEqual(0u, WarpPortableFloating16Oracle.StackWord([0xFF800000], signed: true));
        Assert.AreEqual(0u, WarpPortableFloating16Oracle.StackWord([0, 0xFFF00000], signed: false));
        Assert.AreEqual(0u, WarpPortableFloating16Oracle.StackWord([0x7F800001], signed: true));
        Assert.AreEqual(0u, WarpPortableFloating16Oracle.StackWord([0x12345678, 0xFFF80000], signed: false));
        Assert.AreEqual(0xFFFF8000u, WarpPortableFloating16Oracle.StackWord([0x47000000], signed: true));
        Assert.AreEqual(0u, WarpPortableFloating16Oracle.StackWord([0, 0x40F00000], signed: false));
        // 3*2^30 is within UInt32 yet outside Int32: a UInt32 intermediate
        // would give low16=0, which is observably different from 65535 here.
        Assert.AreEqual(65535u, WarpPortableFloating16Oracle.StackWord([0x4F400000], signed: false));
        Assert.AreEqual(uint.MaxValue, WarpPortableFloating16Oracle.StackWord([0, 0x41E80000], signed: true));
        Assert.AreEqual(1u, WarpPortableFloating16Oracle.StackWord([0x3FC00000], signed: true));
        Assert.AreEqual(0xFFFFFFFEu, WarpPortableFloating16Oracle.StackWord([0, 0xC0040000], signed: true));
    }
}
