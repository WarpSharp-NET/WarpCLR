namespace WarpCLR.Tests.Production;

// Original C# guest sources. Root must retain their actual compiled CIL; no
// opcode substitution or source delegate is used by the portable implementation.
internal static class WarpPortableFloating16SourceKernels
{
    public static short SingleToInt16(float value) => unchecked((short)value);
    public static ushort SingleToUInt16(float value) => unchecked((ushort)value);
    public static short DoubleToInt16(double value) => unchecked((short)value);
    public static ushort DoubleToUInt16(double value) => unchecked((ushort)value);
    public static int SingleSignedI4(float value) => unchecked((short)value);
    public static int SingleUnsignedI4(float value) => unchecked((ushort)value);
    public static int DoubleSignedI4(double value) => unchecked((short)value);
    public static int DoubleUnsignedI4(double value) => unchecked((ushort)value);

    public static int SingleSignedStored(float value) => SignedStorage(unchecked((short)value));
    public static int SingleUnsignedStored(float value) => UnsignedStorage(unchecked((ushort)value));
    public static int DoubleSignedStored(double value) => SignedStorage(unchecked((short)value));
    public static int DoubleUnsignedStored(double value) => UnsignedStorage(unchecked((ushort)value));
    private static int SignedStorage(short value) => value;
    private static int UnsignedStorage(ushort value) => value;

    public static uint SingleRawAfterUnsigned(float value) =>
        BitConverter.SingleToUInt32Bits(value) ^ unchecked((ushort)value);
    public static ulong DoubleRawAfterUnsigned(double value) =>
        BitConverter.DoubleToUInt64Bits(value) ^ unchecked((ushort)value);

    // These remain default-lowering denials; this proposal supplies no fault/EH
    // protocol and no 8-bit floating conversion service.
    public static short CheckedSingleToInt16(float value) => checked((short)value);
    public static ushort CheckedSingleToUInt16(float value) => checked((ushort)value);
    public static short CheckedDoubleToInt16(double value) => checked((short)value);
    public static ushort CheckedDoubleToUInt16(double value) => checked((ushort)value);
    public static sbyte SingleToInt8(float value) => unchecked((sbyte)value);
    public static byte SingleToUInt8(float value) => unchecked((byte)value);
    public static sbyte DoubleToInt8(double value) => unchecked((sbyte)value);
    public static byte DoubleToUInt8(double value) => unchecked((byte)value);
}
