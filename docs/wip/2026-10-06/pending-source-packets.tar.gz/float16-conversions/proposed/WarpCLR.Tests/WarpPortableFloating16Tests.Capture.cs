using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Reflection.Emit;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

[TestClass]
[DoNotParallelize]
[SuppressMessage("Performance", "CA1812:Avoid uninstantiated internal classes", Justification = "MSTest discovers this fixture through reflection.")]
internal sealed partial class WarpPortableFloating16Tests
{
    public TestContext TestContext { get; set; } = null!;

    [TestMethod]
    [DataRow("SingleToInt16", 1)]
    [DataRow("SingleToUInt16", 1)]
    [DataRow("DoubleToInt16", 2)]
    [DataRow("DoubleToUInt16", 2)]
    public void FourExactWordServicesHaveVerifiedPrimitiveClosure(string name, int words)
    {
        MethodInfo service = typeof(WarpPortableFloating16Conversions).GetMethod(name)!;
        Assert.AreEqual(typeof(uint), service.ReturnType);
        CollectionAssert.AreEqual(Enumerable.Repeat(typeof(uint), words).ToArray(), service.GetParameters().Select(parameter => parameter.ParameterType).ToArray());
        WarpIntegerMapKernel verified = new WarpIntegerMapVerifier().Verify(new WarpIntegerMapRequest(service, words));
        Assert.AreEqual(words, verified.ControlFlow.InputBufferCount);
        Assert.AreEqual(0, verified.ControlFlow.ScalarArgumentCount);
        StringAssert.Contains(WarpPortableFloating16Conversions.Semantics, "coreclr-10.0.12-ryujit-x64", StringComparison.Ordinal);
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void DefaultCapturedCilKeepsSourceWidthAndExactI4NarrowExtension(bool wide)
    {
        foreach (string name in Names(wide))
        {
            MethodInfo source = Source(name);
            WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
            WarpPortableMethodGraphMethod captured = graph.Methods.Single(method => method.Identity == graph.EntryIdentity);
            Assert.IsTrue(captured.Instructions.Any(instruction => instruction.OpCode == NarrowOpCode(name)));
            WarpPortableWordLoweredProgram program = Capture(name);
            WarpPortableWordBody body = EntryBody(program, name);
            Assert.AreEqual(wide ? 64 : 32, body.Arguments[0].Type.StorageBits);
            Assert.AreEqual(wide ? WarpPortableStackCategory.Binary64 : WarpPortableStackCategory.Binary32, body.Arguments[0].Type.Category);
            WarpPortableTypedInstruction converted = body.SourceBlocks.Single(block => block.Instruction.OpCode == NarrowOpCode(name).Value).Instruction;
            Assert.AreEqual(WarpPortableStackCategory.I4, converted.ExitStack[^1].Category);
            Assert.AreEqual(WarpPortableMethodGraphIdentity.Type(typeof(int)), converted.ExitStack[^1].TypeIdentity, StringComparer.Ordinal);
            Assert.AreEqual(1, converted.ExitStack[^1].WordCount);
            Assert.AreEqual(WarpPortableMethodGraphIdentity.Type(Unsigned(name) ? typeof(ushort) : typeof(short)), converted.ExitStack[^1].SourceStorageType, StringComparer.Ordinal);
            Assert.IsTrue(program.RequiredServices.Any(identity => identity.Contains(WarpPortableFloating16Conversions.Semantics, StringComparison.Ordinal)));
            Assert.IsTrue(program.Kernel.Execution!.Bodies.Where(metadata => metadata.RuntimeHelper)
                .All(metadata => !metadata.CountsSourceDepth && metadata.SourceBlockCosts.All(cost => cost == 0)));
            Assert.IsNull(program.Kernel.Execution.PrivateControllerProjection);
        }
    }

    [TestMethod]
    public void GuestStorageRoundtripKeepsTheDeclaredSignedOrUnsigned16BitSlot()
    {
        foreach (bool wide in new[] { false, true })
        {
            foreach (string name in Names(wide).Where(name => name.EndsWith("Stored", StringComparison.Ordinal)))
            {
                WarpPortableWordLoweredProgram program = Capture(name);
                WarpPortableWordBody storage = program.Bodies.Single(body => body.MethodIdentity != EntryBody(program, name).MethodIdentity);
                Assert.AreEqual(16, storage.Arguments[0].Type.StorageBits);
                Assert.AreEqual(!Unsigned(name), storage.Arguments[0].Type.IsSigned);
                Assert.AreEqual(1, storage.Arguments[0].Type.WordCount);
                Assert.AreEqual(1, new WarpLogicalMachineLayout(program.Kernel).ResultWordCount);
            }
        }
    }

    [TestMethod]
    [DataRow("CheckedSingleToInt16", true)]
    [DataRow("CheckedSingleToUInt16", true)]
    [DataRow("CheckedDoubleToInt16", true)]
    [DataRow("CheckedDoubleToUInt16", true)]
    [DataRow("SingleToInt8", false)]
    [DataRow("SingleToUInt8", false)]
    [DataRow("DoubleToInt8", false)]
    [DataRow("DoubleToUInt8", false)]
    public void CheckedAndEightBitFloatConversionsKeepTheirNamedDefaultDenial(string name, bool overflow)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(Source(name));
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableTypedInstruction conversion = typed.Methods.Single(method => method.Identity == graph.EntryIdentity).Instructions
            .Single(instruction => instruction.Effects.Contains(WarpPortableTypedEffect.Conversion));
        Assert.AreEqual(overflow, conversion.Effects.Contains(WarpPortableTypedEffect.OverflowCheck));
        WarpVerificationException failure = Assert.ThrowsExactly<WarpVerificationException>(() => WarpPortableWordLowerer.Lower(graph, typed));
        Assert.AreEqual("WRPCLR2300", failure.Code, StringComparer.Ordinal);
        StringAssert.Contains(failure.Message, overflow ? "Checked conversions" : "exact-width portable conversion service", StringComparison.Ordinal);
    }

    [TestMethod]
    public void ExistingProfilesAndNonconversionSourcesKeepTheirUnrelatedContracts()
    {
        Assert.AreEqual("warp.math.binary32-binary64.conversions/rne-gradual-truncate-saturate-nan-zero/0.1", WarpPortableNumericConversions.Semantics, StringComparer.Ordinal);
        Assert.AreEqual("warp.math.binary32.arithmetic/rne-gradual-canonical-nan/0.1|warp.math.binary64.arithmetic/rne-gradual-canonical-nan/0.1|warp.math.overloads/exact-signed-width-enum-fault/0.1",
            WarpPortableMethodGraphIntrinsics.MathContract, StringComparer.Ordinal);
        Assert.AreEqual("warp.logical-machine/0.8", WarpLogicalMachineLayout.Version, StringComparer.Ordinal);
        MethodInfo source = typeof(TestKernels).GetMethod(nameof(TestKernels.ManifestMap))!;
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
        WarpPortableWordLoweredProgram ordinary = WarpPortableWordLowerer.Lower(graph, WarpPortableTypedProgram.Verify(graph));
        Assert.IsFalse(ordinary.RequiredServices.Any(identity => identity.Contains(WarpPortableFloating16Conversions.Semantics, StringComparison.Ordinal)));
        Assert.AreEqual("warp.logical-source-frames/0.6", ordinary.Kernel.Execution!.IdentityVersion, StringComparer.Ordinal);
        Assert.IsNull(ordinary.Kernel.Execution.PrivateControllerProjection);
    }

    private static MethodInfo Source(string name) => typeof(WarpPortableFloating16SourceKernels).GetMethod(name, BindingFlags.Public | BindingFlags.Static)!;
    private static bool Unsigned(string name) => name.Contains("Unsigned", StringComparison.Ordinal) || name.Contains("UInt16", StringComparison.Ordinal);
    private static OpCode NarrowOpCode(string name) => Unsigned(name) ? OpCodes.Conv_U2 : OpCodes.Conv_I2;
    private static string[] Names(bool wide) => wide ?
        ["DoubleToInt16", "DoubleToUInt16", "DoubleSignedI4", "DoubleUnsignedI4", "DoubleSignedStored", "DoubleUnsignedStored", "DoubleRawAfterUnsigned"] :
        ["SingleToInt16", "SingleToUInt16", "SingleSignedI4", "SingleUnsignedI4", "SingleSignedStored", "SingleUnsignedStored", "SingleRawAfterUnsigned"];
    private static WarpPortableWordBody EntryBody(WarpPortableWordLoweredProgram program, string name) =>
        program.Bodies.Single(body => body.MethodIdentity == WarpPortableMethodGraphIdentity.Method(Source(name)));
    private static WarpPortableWordLoweredProgram Capture(string name)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(Source(name));
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableWordLoweredProgram program = WarpPortableWordLowerer.Lower(graph, typed);
        WarpPortableWordProgramIdentity.Validate(graph, WarpPortableSourceHeapSchema.Create(graph, typed), program);
        return program;
    }
}
