using System.Numerics;
using System.Reflection;

namespace WarpCLR.Tests.Production;

// TEST ONLY: integer bit decoding independent of every production conversion
// service. It never evaluates native float math to calculate expected words.
internal static class WarpPortableFloating16Oracle
{
    internal static uint StackWord(uint[] words, bool signed)
    {
        BigInteger integer = TruncatedInteger(words);
        integer = BigInteger.Min(int.MaxValue, BigInteger.Max(int.MinValue, integer));
        uint low16 = (uint)(integer & 0xFFFF);
        return signed && (low16 & 0x8000) != 0 ? low16 | 0xFFFF0000 : low16;
    }

    private static BigInteger TruncatedInteger(uint[] words)
    {
        bool wide = words.Length == 2;
        int precision = wide ? 52 : 23;
        int bias = wide ? 1023 : 127;
        ulong raw = words[0] | (wide ? (ulong)words[1] << 32 : 0);
        bool negative = (raw & (wide ? 1ul << 63 : 1ul << 31)) != 0;
        int exponent = (int)(raw >> precision & (wide ? 0x7FFul : 0xFFul));
        BigInteger fraction = raw & ((1ul << precision) - 1);
        if (exponent == (wide ? 0x7FF : 0xFF))
        {
            return fraction != 0 ? BigInteger.Zero : negative ? int.MinValue : int.MaxValue;
        }
        BigInteger significand = exponent == 0 ? fraction : fraction | BigInteger.One << precision;
        int shift = (exponent == 0 ? 1 : exponent) - bias - precision;
        BigInteger magnitude = shift < 0 ? significand >> -shift : significand << shift;
        return negative ? -magnitude : magnitude;
    }

    internal static uint[] Result(string name, uint[] input)
    {
        bool signed = !name.Contains("Unsigned", StringComparison.Ordinal) && !name.Contains("UInt16", StringComparison.Ordinal);
        uint stack = StackWord(input, signed);
        if (name.EndsWith("RawAfterUnsigned", StringComparison.Ordinal))
        {
            return input.Length == 1 ? [input[0] ^ stack] : [input[0] ^ stack, input[1]];
        }
        bool storage = name.EndsWith("ToInt16", StringComparison.Ordinal) || name.EndsWith("ToUInt16", StringComparison.Ordinal);
        return [storage ? stack & 0xFFFF : stack];
    }

    internal static uint[] OriginalResult(MethodInfo source, uint[] input)
    {
        // Only Root's separately bounded, pinned original CLR TEST process may
        // execute this oracle. The generated worker never calls captured source.
        object argument;
        if (input.Length == 1) { argument = BitConverter.UInt32BitsToSingle(input[0]); }
        else { argument = BitConverter.UInt64BitsToDouble(input[0] | (ulong)input[1] << 32); }
        object result = source.Invoke(null, [argument])!;
        if (result is short signed) { return [unchecked((uint)signed) & 0xFFFF]; }
        if (result is ushort unsigned) { return [unsigned]; }
        if (result is int stack) { return [unchecked((uint)stack)]; }
        if (result is uint raw) { return [raw]; }
        if (result is ulong wide) { return [unchecked((uint)wide), (uint)(wide >> 32)]; }
        throw new InvalidDataException("No exact declared result representation is admitted by this test oracle.");
    }
}
