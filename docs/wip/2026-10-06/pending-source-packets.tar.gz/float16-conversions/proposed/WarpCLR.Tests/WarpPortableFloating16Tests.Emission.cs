using System.Buffers.Binary;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.Compiler;
using WarpCLR.IR;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableFloating16Tests
{
    [TestMethod]
    [DataRow(WarpBackendKind.NVPTX)]
    [DataRow(WarpBackendKind.AMDGPU)]
    [DataRow(WarpBackendKind.SPIRV)]
    public void OrdinaryCodecAndAllSharedEmittersKeepTheExactCommonWordGraph(WarpBackendKind backend)
    {
        foreach (bool wide in new[] { false, true })
        {
            foreach (string name in Names(wide))
            {
                WarpPortableWordLoweredProgram program = Capture(name);
                var layout = new WarpLogicalMachineLayout(program.Kernel);
                string ir = WarpIrHash.Compute(layout.Kernel);
                byte[] bytes = WarpCoreCLRBinaryPlanCodec.Serialize(layout.Kernel);
                Assert.AreEqual(0x57425036u, BinaryPrimitives.ReadUInt32LittleEndian(bytes));
                WarpControlFlowKernel decoded = WarpCoreCLRBinaryPlanCodec.Deserialize(bytes, ir);
                CollectionAssert.AreEqual(bytes, WarpCoreCLRBinaryPlanCodec.Serialize(decoded));
                Assert.AreEqual(ir, WarpIrHash.Compute(decoded), StringComparer.Ordinal);
                Assert.AreEqual("warp.logical-source-frames/0.6", decoded.Execution!.IdentityVersion, StringComparer.Ordinal);
                Assert.IsNull(decoded.Execution.PrivateControllerProjection);
                Assert.IsFalse(decoded.Execution.ManagedExceptionTermination);
                Assert.AreEqual(name.EndsWith("DoubleRawAfterUnsigned", StringComparison.Ordinal) ? 2 : 1, layout.ResultWordCount);
                string llvm = WarpPortableMachineEmitter.Emit(layout, backend);
                StringAssert.Contains(llvm, "load i32", StringComparison.Ordinal);
                Assert.IsFalse(System.Text.RegularExpressions.Regex.IsMatch(llvm,
                    @"\b(fadd|fsub|fmul|fdiv|frem|fptrunc|fpext|sitofp|uitofp|fptosi|fptoui)\b"));
                Assert.IsFalse(llvm.Contains("llvm.trunc", StringComparison.Ordinal));
                Assert.IsTrue(program.RequiredServices.Any(identity => identity.Contains(WarpPortableFloating16Conversions.Semantics, StringComparison.Ordinal)));
            }
        }
    }
}
