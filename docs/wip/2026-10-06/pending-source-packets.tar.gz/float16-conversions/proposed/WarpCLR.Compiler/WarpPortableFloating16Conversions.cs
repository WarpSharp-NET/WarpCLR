namespace WarpCLR.Compiler;

internal static class WarpPortableFloating16Conversions
{
    internal const string Semantics = "warp.cil.float-conv-i2-u2/coreclr-10.0.12-ryujit-x64-truncate-clamp-signed32-low16-i4-extension/0.1";

    // The pinned JIT morphs BOTH unchecked small destinations through signed
    // Int32. Saturation belongs to that intermediate, then low16 is extended
    // for the CIL I4 stack. This is neither saturating16 nor UInt32 for conv.u2.
    // Declared 16-bit stores/returns keep their existing separate storage mask.
    public static uint SingleToInt16(uint bits) =>
        WarpPortableInteger32.ExtendSigned16(WarpPortableNumericConversions.SingleToInt32(bits));

    public static uint SingleToUInt16(uint bits) =>
        WarpPortableInteger32.ExtendUnsigned16(WarpPortableNumericConversions.SingleToInt32(bits));

    public static uint DoubleToInt16(uint low, uint high) =>
        WarpPortableInteger32.ExtendSigned16(WarpPortableNumericConversions.DoubleToInt32(low, high));

    public static uint DoubleToUInt16(uint low, uint high) =>
        WarpPortableInteger32.ExtendUnsigned16(WarpPortableNumericConversions.DoubleToInt32(low, high));
}
