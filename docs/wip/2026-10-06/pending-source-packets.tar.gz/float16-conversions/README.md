This packet proposes default typed lowering of unchecked floating `conv.i2` and `conv.u2` under the explicitly named CoreCLR 10.0.12 RyuJIT x64 contract. It contains source and proposed tests only. No SDK/compiler/analyzer/test/oracle/delegate/child/LLVM/native/GPU execution has run. Root must compile, test and join actual artifacts before admitting this feature or reclassifying the original denial.

The exact base is source plan V5 `d0077e59dc13e95f65d67885e0bdc77cff45075542cbdf34055522e5c4a9ba62`, with the separate RotateLeft proposal `e4f5e8be98c1b3719a7686e934e2fbe78247d74552862cbacd501dadcdc58477`. There is no replacement overlap with RotateLeft. The one replacement preimage is `WarpCLR.Compiler/WarpPortableWordLowerer.Conversions.cs`, SHA256 `bba571bb09c90c95d86777a4e0ddad2601892fc59a11923cc2b74be091a48f8d`. Apply only after matching those exact bytes, with all existing policies enabled.

The new Compiler service class is `WarpPortableFloating16Conversions`. Its four public static entrypoints use uint words exclusively: `SingleToInt16(uint)`, `SingleToUInt16(uint)`, `DoubleToInt16(uint low,uint high)`, and `DoubleToUInt16(uint low,uint high)`. Each returns the complete CIL I4 evaluation word. The separate declared short/ushort storage mask remains where the existing lowerer already applies it. No conversion/opcode/representation is inserted into the captured original CIL.

The service semantic ID is:

`warp.cil.float-conv-i2-u2/coreclr-10.0.12-ryujit-x64-truncate-clamp-signed32-low16-i4-extension/0.1`

For finite values, decode the original binary32/binary64 value, truncate toward zero, clamp the integer to signed Int32, retain low16, then sign-extend for `conv.i2` or zero-extend for `conv.u2`. NaNs yield intermediate zero; infinities use the corresponding Int32 bound. Both destinations use the signed intermediate. The services reuse the existing exact uint-word Int32 conversion and extension helpers. Single's existing bit widening computes the identical numeric value for that helper; it does not change the original Single argument/storage/CIL, and it does not add a guest source charge. Numeric NaN classification never replaces the original transported raw bits.

The source basis is recorded with immutable commit/blob hashes and physical line coordinates in [primary-source-audit.md](primary-source-audit.md) and [primary-source-pins.json](primary-source-pins.json). Source inspection establishes this candidate rule; it is not an executed original CLR oracle. CLR 11, Mono, NativeAOT or another architecture cannot silently inherit this versioned binding. The portable backends all execute the same admitted uint graph and semantic ID.

The distinguishing proposed results below are mathematical predictions, not recorded execution results:

| Original input | `conv.i2` I4 word | `conv.u2` I4 word |
| --- | --- | --- |
| positive infinity | `FFFFFFFF` | `0000FFFF` |
| negative infinity | `00000000` | `00000000` |
| any NaN | `00000000` | `00000000` |
| 32768 | `FFFF8000` | `00008000` |
| 65536 | `00000000` | `00000000` |
| 3 × 2³⁰ | `FFFFFFFF` | `0000FFFF` |
| -1.5 | `FFFFFFFF` | `0000FFFF` |

There are two production files (one new, one exact replacement), eight new test source files, 24 genuine C# fixture declarations (14 positive entries, two guest storage helpers, eight explicit negative entries), 11 proposed MSTest methods and 26 proposed rows. Test definitions are inventoried without execution in [test-inventory.json](test-inventory.json). Four checked narrow conversions and four unchecked floating-to-8-bit conversions remain named default denials. There is no checked fault/EH, Sign, division, source/controller/private-RPC or issuance implementation here.

The input seed inventory freezes 190 binary32 and 230 binary64 raw patterns, including both signs, signaling/quiet NaN payloads, infinities, zeros, subnormals, normal boundaries, integer/fractional ties, 16-bit wrap edges, Int32 edges and extreme magnitudes. Data preparation enumerated integer bit neighbours and sign flips only; no numeric oracle was run. The C# seed file has the exact same literals. Root must separately create and freeze one actual initial complete State/Arena/input bank per compiled plan/vector, then reuse those identical bytes across both quanta and every dialect. No backend may allocate a fresh owner namespace for a supposedly shared seed.

The proposed child tests serialize the genuine default captured program, compile it in an actual ordinary worker, persist every entire State/Arena/input bank before and after each quantum, check exact source budgets and one-short machine faults, retain authentic committed word receipts, and require successful immutable first containment plus complete closure. SourceBodies.Function is already the physical function index: the tests do not add another +1. Helper work consumes no source charge. NaN/raw storage and multiword uint64 transport are exercised by original C# bit-transport expressions, not by float downcasting.

The original CLR test oracle is deliberately separate: exact source MethodInfo invoked in Root's externally bounded pinned 10.0.12 x64 test process, compared with a test-only independent bit/BigInteger model. It is never used by the worker, service, compiler or backend as execution fallback. Actual tests record their current PE/MVID/token/CIL/hash/typed/map/service/worker/module identities. Those observations still require Root's independently issued actual source/artifact/SDK/runtime/tool receipts; no old DLL is a default or a substitute. The actual SDK assembly name is `WarpCLR.Sdk.dll`.

The same original `added-DoubleToInt16` identity requires linking the existing readonly coverage fixture specified in [application-contract.json](application-contract.json). That source remains SHA256 `d462e702b431786ec04f168e8023c130db00d3cd984cc2239c3f02652e9a326e`, with exact declaration `(double value)->short`. A new fixture with a similar method name is supplementary and cannot replace that row. The original90 list and original15-denial packet remain untouched. After actual validation, float-only migration would be 75 numeric + one reference-root consistency + 14 denials; after both actual RotateLeft and float validation it would be 76 + one + 13, still exactly 90 identities. Neither migration is accepted by this source-only packet.

Root must produce actual three-target native images and CPU-retargeted whole-bank comparisons using the finite plan in [future-proof-plan.json](future-proof-plan.json). Emission string/codec tests are not native validation or GPU execution. The future matrix includes all 14 supplementary originals plus the same original denial method, all three native dialects, both quanta, shared seeds, exact and one-short budgets, full input/State/Arena/budget/fault/result words, and retained first stop outcomes. It does not lower numeric width or silently narrow the supported target set.

All existing global MathContract/conversion versions, ordinary/conditional private hashes, machine/frame/word widths and codecs remain unedited. Only the new float-to-16 branches import the new semantic ID. Existing lowerer service identity hashing includes that version in the resulting kernel/cache identity. Integer `conv.i2`/`conv.u2`, every unrelated conversion, and captures that do not need this service keep their prior paths and versions. Main, SDK, every sealed predecessor and lifecycle instruction files are untouched.

One data-only packet preparation assertion wrongly expected the old case inventory to contain a single 90-element list. The actual packet has 74/1/15 lists. Its complete small partial-output/source-hash boundary is retained in `retained-preparation-failure-01`; the inventory traversal was corrected without changing proposed C# source or any frozen input. Read-only lookup misses for an obsolete source filename/filename guesses are recorded in the audit. There has been no failed executable gate to relabel.

The handoff is stopped. All future execution, artifact acceptance, original-case migration, integration, complete production gates and Review belong to Root. Local development only; no GPU, DevOps, lab or deployment claim.
