"""Future direct compiled CPU ABI comparison; no source/interpreter fallback."""
import argparse
import ctypes
import json
import os
import pathlib
import platform
import time
from proof_tools import pin, read, receipt, require, sha, validate_prepared, v4_module, write_new


def array(words):
    return (ctypes.c_uint32 * max(1, len(words)))(*words)


def call(kernel, program, banks, maximum_depth, quantum):
    state, arena, inputs = banks
    state_pin, arena_pin = array(state), array(arena)
    input_pins = [array(words) for words in inputs]
    require(program["scalarCount"] == 0 and len(inputs) == program["inputCount"] and all(len(bank) == 1 for bank in inputs),
            "Ordinary original typed word columns, no private/controller scalar")
    arguments = [state_pin] + input_pins + [1, 0, maximum_depth, quantum]
    if program["requiresManagedMemory"]:
        arguments += [arena_pin, len(arena)]
    kernel(*arguments)
    return list(state_pin)[:len(state)], list(arena_pin)[:len(arena)], [list(pinned)[:len(words)] for pinned, words in zip(input_pins, inputs, strict=True)]


def main():
    parser = argparse.ArgumentParser()
    for name in ["root-inputs", "prepared", "core-case", "image-receipt", "output"]:
        parser.add_argument("--" + name, type=pathlib.Path, required=True)
    args = parser.parse_args()
    prepared, _ = validate_prepared(args.prepared, args.root_inputs)
    vectors_path = args.core_case / "vectors.json"
    vectors = read(vectors_path)
    row = next(case for case in prepared["cases"] if case["name"] == vectors["name"])
    program = read(row["program"]["path"])
    stop = read(args.core_case / "child-stop.json")
    require(stop["hasSuccessfulContainment"] and stop["isClosed"] and stop["cleanupException"] is None,
            "Immutable first containment and complete stop; late observations cannot replace failure")
    image = read(args.image_receipt)
    require(image["format"] == "warp.proof.current-numeric/compiled-cpu-image/0.1" and image["commonIrHash"] == row["irHash"] and
            image["program"] == row["program"] and image["rootInputs"]["sha256"] == sha(args.root_inputs), "Current actual image/source/type/IR join")
    library = pin(image["image"])
    for artifact in [image["object"], image["retarget"], image["toolReceipt"], image["positiveProducerStop"]]:
        pin(artifact)
    require(not args.output.exists(), "Fresh retained CPU comparison output")
    args.output.mkdir(parents=True)
    banks = v4_module("bank_format")
    module = ctypes.CDLL(str(library))
    kernel = module.warp_resume
    kernel.argtypes = [ctypes.POINTER(ctypes.c_uint32)] * (1 + program["inputCount"]) + [ctypes.c_uint32] * 4 + \
        ([ctypes.POINTER(ctypes.c_uint32), ctypes.c_uint32] if program["requiresManagedMemory"] else [])
    kernel.restype = None
    completed = []
    started = time.monotonic()
    try:
        for ordinal, step in enumerate(vectors["rows"]):
            require(step["nativeComparable"] and step["invocationFailure"] is None and step["irHash"] == row["irHash"] and step["scalarWords"] == [],
                    "Every successful actual generated Core step required; no skipped negative/budget/fault bank")
            before = banks.read_bank(step["pre"])
            expected = banks.read_bank(step["post"])
            pre = banks.write_bank(args.output / (f"step{ordinal:08d}.native.pre.bank"), *before)
            actual = call(kernel, program, before, step["maximumDepth"], step["quantum"])
            post = banks.write_bank(args.output / (f"step{ordinal:08d}.native.post.bank"), *actual)
            mismatch = banks.difference(expected, actual)
            witness = {"ordinal": ordinal, "name": step["name"], "trace": step["trace"], "quantum": step["quantum"],
                       "initialSeed": step["initialSeed"], "corePre": step["pre"], "corePost": step["post"], "nativePre": pre, "nativePost": post,
                       "difference": mismatch, "wholeBanksEqual": mismatch is None, "authenticatedCoreCheckpoint": step["authenticatedCheckpoint"],
                       "commonIrHash": row["irHash"], "sourceAuthority": False}
            write_new(args.output / (f"step{ordinal:08d}.comparison.json"), witness)
            completed.append(witness)
            if mismatch is not None:
                raise AssertionError("Full State/Arena/input mismatch; all banks retained, no masked comparison")
        write_new(args.output / "result.json", {"format": "warp.proof.current-numeric/cpu-comparison/0.1", "status": "OFFLINE_CPU_COMPLETE",
                  "case": row["name"], "dialect": image["dialect"], "rows": completed, "comparisons": len(completed),
                  "wholeWordsCompared": sum(x["corePost"]["stateWords"] + x["corePost"]["arenaWords"] + sum(x["corePost"]["inputLengths"]) for x in completed),
                  "initialSeeds": [v["initial"] for v in row["vectors"]], "imageReceipt": receipt(args.image_receipt),
                  "coreVectors": receipt(vectors_path), "coreStop": receipt(args.core_case / "child-stop.json"),
                  "rootInputs": receipt(args.root_inputs), "pid": os.getpid(), "architecture": platform.machine(),
                  "seconds": time.monotonic() - started, "gpu": False, "privateRpc": False, "sourceAuthority": False, "readiness": False})
    except Exception as error:
        write_new(args.output / "failure.json", {"error": repr(error), "completed": completed, "pid": os.getpid(), "image": receipt(library), "overallPass": False})
        raise
    finally:
        del kernel, module


if __name__ == "__main__":
    main()
