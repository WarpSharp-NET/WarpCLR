"""Explicit ordinary case adapter to sealed v4 transform; preserves word graph."""
import argparse
import pathlib
from proof_tools import DIALECTS, read, receipt, require, sha, validate_prepared, v4_module, write_new


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root-inputs", type=pathlib.Path, required=True)
    parser.add_argument("--prepared", type=pathlib.Path, required=True)
    parser.add_argument("--case", required=True)
    parser.add_argument("--dialect", choices=DIALECTS, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()
    prepared, _ = validate_prepared(args.prepared, args.root_inputs)
    row = next(case for case in prepared["cases"] if case["name"] == args.case)
    emitted = read(row["emission"]["path"])
    source = next(value for value in emitted["dialects"] if value["dialect"] == args.dialect)
    require(not args.output.exists(), "Retarget boundary must be fresh; failures remain retained")
    args.output.mkdir(parents=True)
    try:
        transform = v4_module("retarget_cpu")
        cpu, edits = transform.transform(pathlib.Path(source["path"]).read_text(), args.dialect)
        target = args.output / "cpu.ll"
        with target.open("x") as stream:
            stream.write(cpu)
        write_new(args.output / "retarget.json", {"format": "warp.proof.current-numeric/ordinary-v4-retarget-adapter/0.1",
                  "dialect": args.dialect, "case": args.case, "commonIrHash": row["irHash"],
                  "source": source, "cpu": receipt(target), "program": row["program"], "emission": row["emission"],
                  "rootInputs": receipt(args.root_inputs), "prepared": receipt(args.prepared),
                  "reusedFunctionVersion": transform.VERSION, "edits": edits, "scalarCount": 0,
                  "arithmeticOrTypeRewrite": False, "sourceAuthority": False, "gpu": False})
    except Exception as error:
        write_new(args.output / "failure.json", {"error": repr(error), "source": source, "overallPass": False})
        raise


if __name__ == "__main__":
    main()
