"""Future completed-image/stop receipt join. No compiler/native invocation."""
import argparse
import pathlib
import re
import struct
from proof_tools import pin, read, receipt, require, sha, write_new


def stopped(path):
    value = read(path)
    require(value["immutableFirstOutcome"] == "Succeeded" and value["allHeldContainedProcessesTerminal"] is True and
            value["ownedProducerCensusEmpty"] is True and value["registeredPrivateGroupOnly"] is True,
            "Root exact successful first stop and all held positive leader/descendant proofs required")
    # JSON cannot mint OS-handle/runtime authority. Root must authenticate the
    # stopped producer registry and join its actual held-handle proof receipt.
    pin(value["heldIdentityProof"])
    return receipt(path)


def inspect_device(image, dialect):
    data = image.read_bytes()
    if dialect == "NVPTX":
        text = data.decode()
        require(re.search(r"\.version\s+8\.0\b", text) and re.search(r"\.target\s+sm_80\b", text) and
                re.search(r"\.address_size\s+64\b", text) and "warp_resume" in text, "Actual sm_80/PTX8/64bit entry image")
        return {"format": "PTX", "sm": "sm_80", "ptx": "8.0", "addressBits": 64}
    if dialect == "AMDGPU":
        require(len(data) >= 64 and data[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", data, 18)[0] == 224 and b"warp_resume" in data,
                "Actual linked ELF64 AMDGPU image/entry bytes, no CPU object substitution")
        return {"format": "ELF64-AMDGPU", "target": "gfx942", "addressBits": 64, "gpuRuntimeLoadNotClaimed": True}
    require(len(data) >= 20 and len(data) % 4 == 0, "Complete SPIR-V words")
    words = struct.unpack("<" + "I" * (len(data) // 4), data)
    require(words[0] == 0x07230203 and words[1] <= 0x00010200, "Actual SPIR-V <=1.2 module")
    capabilities, memory, integer_types = set(), [], set()
    cursor = 5
    while cursor < len(words):
        count, opcode = words[cursor] >> 16, words[cursor] & 65535
        require(count > 0 and cursor + count <= len(words), "SPIR-V instruction extent")
        operands = words[cursor + 1:cursor + count]
        if opcode == 17:
            capabilities.add(operands[0])
        if opcode == 14:
            memory.append(list(operands))
        if opcode == 21:
            integer_types.add(operands[1])
        require(opcode != 22, "No native floating SPIR-V type replaces strict integer-word math")
        cursor += count
    require({4, 6, 11} <= capabilities and not {1, 12} & capabilities and memory == [[2, 2]] and {32, 64} <= integer_types,
            "Addresses/Kernel/Int64 and Physical64/OpenCL exact model; no Shader/Int64Atomics widening")
    return {"format": "SPIR-V", "version": words[1], "capabilities": sorted(capabilities), "memoryModel": memory,
            "integerTypes": sorted(integer_types), "validatorEnvironment": "opencl2.2"}


def main():
    parser = argparse.ArgumentParser()
    for name in ["plan", "group", "output", "producer-stop"]:
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    plan = read(args.plan)
    require(plan["format"] == "warp.proof.current-numeric/serial-compilation-plan/0.1", "Exact finite image plan")
    pin(plan["rootInputs"]); pin(plan["prepared"]); pin(plan["nativeTools"]); pin(plan["cpuTools"])
    image = next(row for row in plan["images"] if row["group"] == args.group)
    commands = [row for row in plan["commands"] if row["ordinal"] in image["commandOrdinals"]]
    receipts = []
    for row in commands:
        done = read(row["receipt"])
        require(done["argv"] == row["argv"] and done["exitCode"] == 0 and not done["timedOut"] and done["attempt"] == 1,
                "Actual exact successful serial tool command; no retry/default fallback")
        require(done["groupElapsedSeconds"] <= row["deadlineSeconds"], "One shared immutable group quota, not reset per command")
        for output in row["outputs"]:
            require(pathlib.Path(output).is_file(), "Actual output is absent")
        for log in [done["stdout"], done["stderr"]]:
            pin(log)
        receipts.append({"command": receipt(row["receipt"]), "stop": stopped(row["positiveProducerStop"])})
    stop = stopped(args.producer_stop)
    target = pathlib.Path(image["path"])
    if image["kind"] == "ACTUAL_OFFLINE_TARGET_IMAGE":
        write_new(args.output, {"format": "warp.proof.current-numeric/compiled-target-image/0.1", "case": image["case"], "dialect": image["dialect"],
                  "image": receipt(target), "inspection": inspect_device(target, image["dialect"]), "program": image["program"],
                  "source": image["source"], "wordPlan": image["plan"], "commonIrHash": image["commonIrHash"],
                  "tools": plan["nativeTools"], "commandReceipts": receipts, "positiveProducerStop": stop,
                  "rootInputs": plan["rootInputs"], "sourceChanges": 0, "gpu": False, "sourceAuthority": False})
    else:
        directory = target.parent
        retarget = read(directory / "retarget.json")
        require(retarget["commonIrHash"] == image["commonIrHash"] and retarget["program"] == image["program"] and
                retarget["source"] == image["source"] and not retarget["arithmeticOrTypeRewrite"], "Exact explicit v4 function/case adapter")
        pin(retarget["cpu"])
        write_new(args.output, {"format": "warp.proof.current-numeric/compiled-cpu-image/0.1", "case": image["case"], "dialect": image["dialect"],
                  "image": receipt(target), "object": receipt(directory / "cpu.o"), "retarget": receipt(directory / "retarget.json"),
                  "program": image["program"], "commonIrHash": image["commonIrHash"], "rootInputs": plan["rootInputs"],
                  "toolReceipt": plan["cpuTools"], "commandReceipts": receipts, "positiveProducerStop": stop, "gpu": False, "sourceAuthority": False})


if __name__ == "__main__":
    main()
