namespace WarpCLR.Compiler;

// All mathematical 64-bit values retain low/high UInt32 words. Each entry
// returns one raw word; a future source binding must guard the WHOLE tuple
// using its opcode-specific fault selector before publishing either word.
internal static class WarpPortableCilIntegerDivision64
{
    internal const string Semantics = "warp.cil.integer64-divrem/coreclr-10.0.12-ryujit-x64-truncate-dividend-remainder-zero-and-min-negativeone-fault/0.1";

    public static uint DivideUnsignedLow(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        UnsignedPart(leftLow, leftHigh, rightLow, rightHigh, 0);
    public static uint DivideUnsignedHigh(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        UnsignedPart(leftLow, leftHigh, rightLow, rightHigh, 1);
    public static uint RemainderUnsignedLow(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        UnsignedPart(leftLow, leftHigh, rightLow, rightHigh, 2);
    public static uint RemainderUnsignedHigh(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        UnsignedPart(leftLow, leftHigh, rightLow, rightHigh, 3);
    public static uint DivideSignedLow(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        SignedPart(leftLow, leftHigh, rightLow, rightHigh, 0);
    public static uint DivideSignedHigh(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        SignedPart(leftLow, leftHigh, rightLow, rightHigh, 1);
    public static uint RemainderSignedLow(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        SignedPart(leftLow, leftHigh, rightLow, rightHigh, 2);
    public static uint RemainderSignedHigh(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        SignedPart(leftLow, leftHigh, rightLow, rightHigh, 3);

    public static uint DivideUnsignedFault(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        (rightLow | rightHigh) == 0 ? WarpPortableIntegerFault.DivideByZero : WarpPortableIntegerFault.None;
    public static uint RemainderUnsignedFault(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        (rightLow | rightHigh) == 0 ? WarpPortableIntegerFault.DivideByZero : WarpPortableIntegerFault.None;
    public static uint DivideSignedFault(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        (rightLow | rightHigh) == 0 ? WarpPortableIntegerFault.DivideByZero :
        leftLow == 0 && leftHigh == 0x80000000u && rightLow == 0xFFFFFFFFu && rightHigh == 0xFFFFFFFFu ?
            WarpPortableIntegerFault.Overflow : WarpPortableIntegerFault.None;
    public static uint RemainderSignedFault(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh) =>
        (rightLow | rightHigh) == 0 ? WarpPortableIntegerFault.DivideByZero :
        leftLow == 0 && leftHigh == 0x80000000u && rightLow == 0xFFFFFFFFu && rightHigh == 0xFFFFFFFFu ?
            WarpPortableIntegerFault.Overflow : WarpPortableIntegerFault.None;

    private static uint SignedPart(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh, uint word)
    {
        uint fault = word < 2 ? DivideSignedFault(leftLow, leftHigh, rightLow, rightHigh) :
            RemainderSignedFault(leftLow, leftHigh, rightLow, rightHigh);
        if (fault != WarpPortableIntegerFault.None) { return 0; }
        uint sign = word < 2 ? (leftHigh ^ rightHigh) >> 31 : leftHigh >> 31;
        if ((leftHigh >> 31) != 0)
        {
            leftHigh = WarpPortableInteger64.NegateHigh(leftLow, leftHigh);
            leftLow = WarpPortableInteger64.NegateLow(leftLow, leftHigh);
        }
        if ((rightHigh >> 31) != 0)
        {
            rightHigh = WarpPortableInteger64.NegateHigh(rightLow, rightHigh);
            rightLow = WarpPortableInteger64.NegateLow(rightLow, rightHigh);
        }
        uint low = UnsignedPart(leftLow, leftHigh, rightLow, rightHigh, word & 2u);
        if ((word & 1u) == 0) { return sign == 0 ? low : unchecked(0u - low); }
        uint high = UnsignedPart(leftLow, leftHigh, rightLow, rightHigh, word);
        return sign == 0 ? high : WarpPortableInteger64.NegateHigh(low, high);
    }

    // At most 64 restoring iterations per selected unsigned word. The carry
    // preserves the 65th remainder bit. No native UInt64 division or float.
    private static uint UnsignedPart(uint leftLow, uint leftHigh, uint rightLow, uint rightHigh, uint word)
    {
        if ((rightLow | rightHigh) == 0) { return 0; }
        uint quotientLow = 0;
        uint quotientHigh = 0;
        uint remainderLow = 0;
        uint remainderHigh = 0;
        for (uint bit = 0; bit < 64; bit++)
        {
            uint carry = remainderHigh >> 31;
            remainderHigh = remainderHigh << 1 | remainderLow >> 31;
            remainderLow = remainderLow << 1 | leftHigh >> 31;
            leftHigh = leftHigh << 1 | leftLow >> 31;
            leftLow <<= 1;
            quotientHigh = quotientHigh << 1 | quotientLow >> 31;
            quotientLow <<= 1;
            if (carry != 0 || remainderHigh > rightHigh || remainderHigh == rightHigh && remainderLow >= rightLow)
            {
                uint borrow = remainderLow < rightLow ? 1u : 0u;
                remainderHigh = unchecked(remainderHigh - rightHigh - borrow);
                remainderLow = unchecked(remainderLow - rightLow);
                quotientLow |= 1;
            }
        }
        return word == 0 ? quotientLow : word == 1 ? quotientHigh : word == 2 ? remainderLow : remainderHigh;
    }
}
