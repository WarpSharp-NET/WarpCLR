namespace WarpCLR.Compiler;

// A versioned arithmetic/fault selector only. A nonzero selector is NOT a
// machine fault, exception reference, source continuation, or successful zero.
// The exact source fault/EH binding is deliberately not installed by this unit.
internal static class WarpPortableCilIntegerDivision32
{
    internal const string Semantics = "warp.cil.integer32-divrem/coreclr-10.0.12-ryujit-x64-truncate-dividend-remainder-zero-and-min-negativeone-fault/0.1";

    public static uint DivideUnsigned(uint left, uint right) => UnsignedPart(left, right, 0);
    public static uint RemainderUnsigned(uint left, uint right) => UnsignedPart(left, right, 1);
    public static uint DivideSigned(uint left, uint right) => SignedPart(left, right, 0);
    public static uint RemainderSigned(uint left, uint right) => SignedPart(left, right, 1);

    public static uint DivideUnsignedFault(uint left, uint right) =>
        right == 0 ? WarpPortableIntegerFault.DivideByZero : WarpPortableIntegerFault.None;

    public static uint RemainderUnsignedFault(uint left, uint right) =>
        right == 0 ? WarpPortableIntegerFault.DivideByZero : WarpPortableIntegerFault.None;

    public static uint DivideSignedFault(uint left, uint right) =>
        right == 0 ? WarpPortableIntegerFault.DivideByZero :
        left == 0x80000000u && right == 0xFFFFFFFFu ? WarpPortableIntegerFault.Overflow : WarpPortableIntegerFault.None;

    // The mathematical remainder at MinValue/-1 is zero. The pinned x64 CLR
    // nevertheless throws, including a literal -1 divisor. Do not replace this
    // opcode-specific selector with a zero-only remainder rule or native srem.
    public static uint RemainderSignedFault(uint left, uint right) =>
        right == 0 ? WarpPortableIntegerFault.DivideByZero :
        left == 0x80000000u && right == 0xFFFFFFFFu ? WarpPortableIntegerFault.Overflow : WarpPortableIntegerFault.None;

    private static uint SignedPart(uint left, uint right, uint remainder)
    {
        uint fault = remainder == 0 ? DivideSignedFault(left, right) : RemainderSignedFault(left, right);
        if (fault != WarpPortableIntegerFault.None) { return 0; }
        uint sign = remainder == 0 ? (left ^ right) >> 31 : left >> 31;
        uint leftMagnitude = (left >> 31) == 0 ? left : unchecked(0u - left);
        uint rightMagnitude = (right >> 31) == 0 ? right : unchecked(0u - right);
        uint result = UnsignedPart(leftMagnitude, rightMagnitude, remainder);
        return sign == 0 ? result : unchecked(0u - result);
    }

    // Restoring long division. The carry is the 33rd remainder bit, so a large
    // divisor or high-bit dividend never loses the comparison's high bit.
    private static uint UnsignedPart(uint left, uint right, uint selectRemainder)
    {
        if (right == 0) { return 0; }
        uint quotient = 0;
        uint remainder = 0;
        for (uint bit = 0; bit < 32; bit++)
        {
            uint carry = remainder >> 31;
            remainder = remainder << 1 | left >> 31;
            left <<= 1;
            quotient <<= 1;
            if (carry != 0 || remainder >= right)
            {
                remainder = unchecked(remainder - right);
                quotient |= 1;
            }
        }
        return selectRemainder == 0 ? quotient : remainder;
    }
}
