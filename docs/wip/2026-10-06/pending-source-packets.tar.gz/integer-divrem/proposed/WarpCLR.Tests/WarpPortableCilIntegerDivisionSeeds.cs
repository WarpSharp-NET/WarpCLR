namespace WarpCLR.Tests.Production;

internal static class WarpPortableCilIntegerDivisionSeeds
{
    internal static readonly uint[] Edges32 =
    [
        0x00000000, 0x00000001, 0x00000002, 0x00000003,
        0x00000007, 0x0000001F, 0x00000100, 0x0000FFFF,
        0x00010000, 0x3F800000, 0x7F800000, 0x7FC01234,
        0x7FFFFFFF, 0x80000000, 0xFFFFFFFE, 0xFFFFFFFF,
    ];

    internal static readonly ulong[] Edges64 =
    [
        0x0000000000000000, 0x0000000000000001, 0x0000000000000002, 0x0000000000000003,
        0x0000000000000007, 0x000000000000001F, 0x00000000FFFFFFFF, 0x0000000100000000,
        0x0000000100000001, 0x00000001FFFFFFFF, 0x0010000000000000, 0x3FF0000000000000,
        0x7FF0000000000000, 0x7FF8000000001234, 0x7FFFFFFFFFFFFFFF, 0x8000000000000000,
        0x8000000000000001, 0xFFFFFFFFFFFFFFFE, 0xFFFFFFFFFFFFFFFF, 0xFFFF0000FFFFFFFF,
    ];

    // These are integer storage bits, including patterns that would spell a
    // floating NaN if transported elsewhere. No float interpretation is made.
    internal static IEnumerable<uint[]> Pairs(bool wide)
    {
        if (wide)
        {
            foreach (ulong left in Edges64)
            {
                foreach (ulong right in Edges64)
                {
                    yield return [unchecked((uint)left), (uint)(left >> 32), unchecked((uint)right), (uint)(right >> 32)];
                }
            }
        }
        else
        {
            foreach (uint left in Edges32)
            {
                foreach (uint right in Edges32) { yield return [left, right]; }
            }
        }
    }
}
