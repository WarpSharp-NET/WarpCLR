using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableCilIntegerDivisionTests
{
    private static readonly JsonSerializerOptions EvidenceOptions = new() { WriteIndented = true };

    private string EvidenceDirectory(string name)
    {
        string directory = Path.Combine(TestContext.TestResultsDirectory!, "cil-divrem-" + name + "-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        return directory;
    }

    private static void WriteEvidence<T>(string directory, string name, T value) =>
        File.WriteAllText(Path.Combine(directory, name + ".json"), JsonSerializer.Serialize(value, EvidenceOptions));

    private static void RecordOriginalSource(MethodInfo source, string directory, string name)
    {
        byte[] cil = source.GetMethodBody()!.GetILAsByteArray()!;
        WriteEvidence(directory, name + "-exact-cil", new { SourceType = source.DeclaringType!.FullName, source.Name, source.MetadataToken,
            Mvid = source.Module.ModuleVersionId, Assembly = source.Module.Assembly.FullName, DeclaredResult = source.ReturnType.FullName,
            DeclaredArguments = source.GetParameters().Select(parameter => parameter.ParameterType.FullName), CilBytes = Convert.ToHexString(cil),
            CilSha256 = Convert.ToHexString(SHA256.HashData(cil)), AssemblyPath = source.Module.Assembly.Location,
            AssemblySha256 = HashFile(source.Module.Assembly.Location), Runtime = Environment.Version.ToString(),
            CoreLib = typeof(object).Assembly.Location, CoreLibSha256 = HashFile(typeof(object).Assembly.Location),
            OriginalOracleIsSeparate = true, SourceGrant = false });
    }

    private static string HashFile(string path)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        return Convert.ToHexString(SHA256.HashData(stream));
    }

    private static async Task<WarpCoreCLRWorkerProcess> CompileChildAsync(WarpLogicalMachineLayout layout, string directory)
    {
        byte[] plan = WarpCoreCLRBinaryPlanCodec.Serialize(layout.Kernel);
        File.WriteAllBytes(Path.Combine(directory, "exact-plan.bin"), plan);
        var options = new WarpCoreCLRWorkerOptions { CompilationTimeout = TimeSpan.FromSeconds(120), QuantumTimeout = TimeSpan.FromSeconds(30), CleanupTimeout = TimeSpan.FromSeconds(2) };
        string host = WarpCoreCLRWorkerProcess.GetDotnetHost(options);
        string worker = Path.Combine(AppContext.BaseDirectory, "WarpCLR.CoreCLR.Worker.dll");
        WriteEvidence(directory, "actual-test-deployment", new { Runtime = Environment.Version.ToString(), Host = host, HostSha256 = HashFile(host),
            Worker = worker, WorkerSha256 = HashFile(worker), CoreClr = typeof(CoreCLRResumableKernel).Assembly.Location,
            CoreClrSha256 = HashFile(typeof(CoreCLRResumableKernel).Assembly.Location), Ir = typeof(WarpLogicalMachineLayout).Assembly.Location,
            IrSha256 = HashFile(typeof(WarpLogicalMachineLayout).Assembly.Location), ActualRootSourceSdkRuntimeReceiptStillMandatory = true });
        WarpCoreCLRWorkerProcess child = await WarpCoreCLRWorkerProcess.CompileAsync(plan, WarpIrHash.Compute(layout.Kernel), options,
            CancellationToken.None).ConfigureAwait(false);
        try
        {
            Assert.AreNotEqual(Environment.ProcessId, child.ProcessId);
            Assert.IsTrue(child.IsCollectible);
            Assert.IsFalse(AppDomain.CurrentDomain.GetAssemblies().Any(assembly => assembly.ManifestModule.ModuleVersionId == child.CompiledModule));
            WriteEvidence(directory, "actual-child", new { child.ProcessId, child.CompiledModule, child.IrHash, child.IsCollectible,
                ParentJit = false, SourceDelegateFallback = false, PrivateRpc = false, SourceGrant = false, WorkerEnvelope = "worker/0.3" });
            return child;
        }
        catch
        {
            await StopChildAsync(child, directory).ConfigureAwait(false);
            throw;
        }
    }

    private static async Task StopChildAsync(WarpCoreCLRWorkerProcess child, string directory)
    {
        Exception? failure = null;
        try { await child.DisposeAsync().ConfigureAwait(false); }
        catch (Exception error) { failure = error; }
        WriteEvidence(directory, "actual-child-stop", new { child.ProcessId, child.CompiledModule, child.IrHash, child.IsClosed, child.IsFaulted,
            child.HasSuccessfulContainment, Error = failure?.ToString(), CleanupQuotaSeconds = 2, SignalOrPidExitIsNotStop = true,
            NoRetry = true, NoLateSuccessPromotion = true, RootExternalProducerCensusStillRequired = true });
        if (failure is not null) { throw new InvalidDataException("Exact child first containment failed; this boundary cannot pass.", failure); }
        Assert.IsTrue(child.HasSuccessfulContainment);
    }
}
