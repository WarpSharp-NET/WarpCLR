using System.Numerics;
using System.Reflection;

namespace WarpCLR.Tests.Production;

// Independent test arithmetic: BigInteger never calls a portable division
// service. The mathematical result and pinned CLR fault profile stay separate.
internal static class WarpPortableCilIntegerDivisionOracle
{
    internal sealed record Result(uint Fault, uint[] Words, BigInteger? MathematicalValue);
    internal sealed record Original(uint[]? Words, string? ExceptionType, int? HResult, string? Message, string? StackTrace);

    internal static Result Calculate(bool wide, bool signed, bool remainder, uint[] input)
    {
        int width = wide ? 64 : 32;
        BigInteger leftBits = wide ? ((BigInteger)input[1] << 32) | input[0] : input[0];
        BigInteger rightBits = wide ? ((BigInteger)input[3] << 32) | input[2] : input[1];
        BigInteger left = Interpret(leftBits, width, signed);
        BigInteger right = Interpret(rightBits, width, signed);
        if (right.IsZero) { return new(1, wide ? [0, 0] : [0], null); }
        BigInteger quotient = BigInteger.Abs(left) / BigInteger.Abs(right);
        if (left.Sign != right.Sign) { quotient = -quotient; }
        BigInteger mathematical = remainder ? left - quotient * right : quotient;
        bool overflow = signed && left == -(BigInteger.One << (width - 1)) && right == -1;
        if (overflow) { return new(2, wide ? [0, 0] : [0], mathematical); }
        BigInteger raw = mathematical & ((BigInteger.One << width) - 1);
        return new(0, wide ? [(uint)(raw & uint.MaxValue), (uint)(raw >> 32)] : [(uint)raw], mathematical);
    }

    // Test-only ORIGINAL method invocation. Root must run this finite oracle
    // in its separately bounded pinned CLR process, never as a product fallback.
    internal static Original Invoke(MethodInfo source, uint[] input)
    {
        object?[] arguments = Arguments(source, input);
        try
        {
            object value = source.Invoke(null, arguments)!;
            uint[] words = value switch
            {
                int number => [unchecked((uint)number)], uint number => [number],
                long number => [unchecked((uint)number), (uint)(unchecked((ulong)number) >> 32)],
                ulong number => [unchecked((uint)number), (uint)(number >> 32)],
                _ => throw new InvalidOperationException("The original div/rem fixture changed its exact result width."),
            };
            return new(words, null, null, null, null);
        }
        catch (TargetInvocationException failure) when (failure.InnerException is not null)
        {
            Exception original = failure.InnerException;
            return new(null, original.GetType().AssemblyQualifiedName, original.HResult, original.Message, original.StackTrace);
        }
    }

    private static object?[] Arguments(MethodInfo source, uint[] input)
    {
        ParameterInfo[] parameters = source.GetParameters();
        var result = new object?[parameters.Length];
        int word = 0;
        for (int index = 0; index < parameters.Length; index++)
        {
            Type type = parameters[index].ParameterType;
            if (type == typeof(int)) { result[index] = unchecked((int)input[word++]); }
            else if (type == typeof(uint)) { result[index] = input[word++]; }
            else
            {
                ulong bits = (ulong)input[word + 1] << 32 | input[word]; word += 2;
                if (type == typeof(long)) { result[index] = unchecked((long)bits); }
                else if (type == typeof(ulong)) { result[index] = bits; }
                else { throw new InvalidOperationException("The original argument is not an exact declared integer width."); }
            }
        }
        return result;
    }

    private static BigInteger Interpret(BigInteger bits, int width, bool signed) =>
        signed && (bits & (BigInteger.One << (width - 1))) != 0 ? bits - (BigInteger.One << width) : bits;
}
