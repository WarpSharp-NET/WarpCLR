using System.Runtime.InteropServices;
using WarpCLR.Compiler;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableCilIntegerDivisionTests
{
    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void MinNegativeOneKeepsSeparateMathematicalAndPinnedCilDivRemResults(bool wide)
    {
        uint[] words = wide ? [0, 0x80000000, uint.MaxValue, uint.MaxValue] : [0x80000000, uint.MaxValue];
        WarpPortableCilIntegerDivisionOracle.Result division = WarpPortableCilIntegerDivisionOracle.Calculate(wide, signed: true, remainder: false, words);
        WarpPortableCilIntegerDivisionOracle.Result remainder = WarpPortableCilIntegerDivisionOracle.Calculate(wide, signed: true, remainder: true, words);
        Assert.AreEqual(2u, division.Fault);
        Assert.AreEqual(2u, remainder.Fault);
        Assert.AreEqual<System.Numerics.BigInteger?>(System.Numerics.BigInteger.One << (wide ? 63 : 31), division.MathematicalValue);
        Assert.AreEqual<System.Numerics.BigInteger?>(System.Numerics.BigInteger.Zero, remainder.MathematicalValue);
        Assert.AreEqual(division.Fault, InvokeService(wide, "DivideSignedFault", words));
        Assert.AreEqual(remainder.Fault, InvokeService(wide, "RemainderSignedFault", words));
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void IndependentArithmeticChecksAllRawSignedUnsignedAndZeroDivisorWords(bool wide)
    {
        foreach (uint[] input in WarpPortableCilIntegerDivisionSeeds.Pairs(wide))
        {
            foreach (bool signed in new[] { false, true })
            {
                foreach (bool remainder in new[] { false, true })
                {
                    WarpPortableCilIntegerDivisionOracle.Result expected = WarpPortableCilIntegerDivisionOracle.Calculate(wide, signed, remainder, input);
                    string name = (remainder ? "Remainder" : "Divide") + (signed ? "Signed" : "Unsigned");
                    Assert.AreEqual(expected.Fault, InvokeService(wide, name + "Fault", input));
                    uint[] actual = wide ? [InvokeService(true, name + "Low", input), InvokeService(true, name + "High", input)] : [InvokeService(false, name, input)];
                    CollectionAssert.AreEqual(expected.Words, actual);
                }
            }
        }
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void FutureBoundedOriginalClrOracleRetainsEveryActualExceptionAndDeclaredWidth(bool wide)
    {
        RequirePinnedOriginalClr();
        string directory = EvidenceDirectory("original-cil-" + (wide ? "64" : "32"));
        foreach (string name in Names(wide))
        {
            RecordOriginalSource(Source(name), directory, name);
            int vector = 0;
            foreach (uint[] input in WarpPortableCilIntegerDivisionSeeds.Pairs(wide))
            {
                WarpPortableCilIntegerDivisionOracle.Result expected = WarpPortableCilIntegerDivisionOracle.Calculate(wide, !Unsigned(name), name.Contains("Remainder", StringComparison.Ordinal), input);
                WarpPortableCilIntegerDivisionOracle.Original original = WarpPortableCilIntegerDivisionOracle.Invoke(Source(name), input);
                WriteEvidence(directory, name + "-" + vector++, new { Input = input, expected, original, OriginalClrIsTestOracleOnly = true });
                AssertOriginal(expected, original);
            }
        }
    }

    [TestMethod]
    [DataRow("Int32DivideLiteralMinusOne")]
    [DataRow("Int32RemainderLiteralMinusOne")]
    [DataRow("Int64DivideLiteralMinusOne")]
    [DataRow("Int64RemainderLiteralMinusOne")]
    public void ActualLiteralMinusOneOracleNeverRelabelsMinimumRemainderAsSuccess(string name)
    {
        RequirePinnedOriginalClr();
        uint[] input = Wide(name) ? [0, 0x80000000] : [0x80000000];
        WarpPortableCilIntegerDivisionOracle.Original original = WarpPortableCilIntegerDivisionOracle.Invoke(Source(name), input);
        string directory = EvidenceDirectory(name);
        RecordOriginalSource(Source(name), directory, name);
        WriteEvidence(directory, "minimum-original-exception", new { Input = input, original });
        Assert.IsNull(original.Words);
        Assert.AreEqual(typeof(OverflowException).AssemblyQualifiedName, original.ExceptionType, StringComparer.Ordinal);
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void OriginalFilterPrecedesFinallyAndReplacementFaultKeepsItsNewCilOrigin(bool wide)
    {
        RequirePinnedOriginalClr();
        string prefix = wide ? "Int64" : "Int32";
        uint[] zero = wide ? [1, 0, 0, 0] : [1, 0];
        uint[] minimum = wide ? [0, 0x80000000, uint.MaxValue, uint.MaxValue] : [0x80000000, uint.MaxValue];
        string directory = EvidenceDirectory(prefix + "-two-pass-original-only");
        foreach (string suffix in new[] { "FilterFinally", "Rethrow", "ReplaceInFinally" })
        {
            string name = prefix + suffix;
            RecordOriginalSource(Source(name), directory, name);
            WarpPortableCilIntegerDivisionOracle.Original original = WarpPortableCilIntegerDivisionOracle.Invoke(Source(name), suffix == "FilterFinally" ? zero : minimum);
            WriteEvidence(directory, name, new { original, GeneratedGuestEhStillBlocked = true });
            if (suffix == "FilterFinally") { CollectionAssert.AreEqual(wide ? new uint[] { 12, 0 } : [12], original.Words); }
            else
            {
                Assert.IsNull(original.Words);
                Assert.AreEqual((suffix == "Rethrow" ? typeof(OverflowException) : typeof(DivideByZeroException)).AssemblyQualifiedName, original.ExceptionType, StringComparer.Ordinal);
            }
        }
    }

    private static uint InvokeService(bool wide, string name, uint[] input) =>
        (uint)(wide ? typeof(WarpPortableCilIntegerDivision64) : typeof(WarpPortableCilIntegerDivision32))
            .GetMethod(name)!.Invoke(null, input.Select(word => (object)word).ToArray())!;

    private static void RequirePinnedOriginalClr()
    {
        Assert.AreEqual(new Version(10, 0, 12), Environment.Version);
        Assert.AreEqual(Architecture.X64, RuntimeInformation.ProcessArchitecture);
        // The surrounding Root driver must authenticate the actual host, runtime
        // modules and finite process deadline before starting this oracle suite.
    }

    private static void AssertOriginal(WarpPortableCilIntegerDivisionOracle.Result expected, WarpPortableCilIntegerDivisionOracle.Original original)
    {
        if (expected.Fault == 0) { CollectionAssert.AreEqual(expected.Words, original.Words); Assert.IsNull(original.ExceptionType); }
        else
        {
            Assert.IsNull(original.Words);
            Assert.AreEqual((expected.Fault == 1 ? typeof(DivideByZeroException) : typeof(OverflowException)).AssemblyQualifiedName, original.ExceptionType, StringComparer.Ordinal);
            Assert.AreEqual<int?>(expected.Fault == 1 ? unchecked((int)0x80020012u) : unchecked((int)0x80131516u), original.HResult);
            Assert.IsNotNull(original.Message);
            Assert.IsNotNull(original.StackTrace);
        }
    }
}
