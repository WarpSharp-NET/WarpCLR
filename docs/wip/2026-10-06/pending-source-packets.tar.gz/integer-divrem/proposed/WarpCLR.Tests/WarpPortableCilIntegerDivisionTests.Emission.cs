using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableCilIntegerDivisionTests
{
    [TestMethod]
    [DataRow(WarpBackendKind.NVPTX)]
    [DataRow(WarpBackendKind.AMDGPU)]
    [DataRow(WarpBackendKind.SPIRV)]
    public void TwentyPrimitivePlansEmitExactWordAlgorithmsAndCodecIdentityForEachDialect(WarpBackendKind backend)
    {
        foreach (bool wide in new[] { false, true })
        {
            foreach (System.Reflection.MethodInfo service in Services(wide))
            {
                WarpLogicalMachineLayout layout = ServiceLayout(service, wide);
                string ir = WarpIrHash.Compute(layout.Kernel);
                byte[] bytes = WarpCoreCLRBinaryPlanCodec.Serialize(layout.Kernel);
                WarpControlFlowKernel decoded = WarpCoreCLRBinaryPlanCodec.Deserialize(bytes, ir);
                CollectionAssert.AreEqual(bytes, WarpCoreCLRBinaryPlanCodec.Serialize(decoded));
                Assert.AreEqual(ir, WarpIrHash.Compute(decoded), StringComparer.Ordinal);
                string llvm = WarpCLR.Compiler.WarpPortableMachineEmitter.Emit(layout, backend);
                Assert.IsFalse(System.Text.RegularExpressions.Regex.IsMatch(llvm, @"\b(sdiv|udiv|srem|urem|fadd|fsub|fmul|fdiv|frem|fptosi|fptoui|sitofp|uitofp)\b"));
                string directory = EvidenceDirectory(service.Name + "-" + (wide ? "64" : "32") + "-" + backend);
                File.WriteAllBytes(Path.Combine(directory, "exact-plan.bin"), bytes);
                File.WriteAllText(Path.Combine(directory, "exact.gpu.ll"), llvm);
                WriteEvidence(directory, "common-ir-identity", new { service.Name, Wide = wide, Backend = backend, IrHash = ir,
                    SourceDivisionAdmission = false, ActualNativeCompilationStillRequired = true, GpuExecution = false });
            }
        }
    }
}
