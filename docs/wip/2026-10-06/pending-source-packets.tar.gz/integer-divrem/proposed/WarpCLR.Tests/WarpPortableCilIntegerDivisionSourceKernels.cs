using System.Runtime.CompilerServices;

namespace WarpCLR.Tests.Production;

internal static class WarpPortableCilIntegerDivisionSourceKernels
{
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static int Int32Divide(int left, int right) => unchecked(left / right);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static int Int32Remainder(int left, int right) => unchecked(left % right);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static uint UInt32Divide(uint left, uint right) => left / right;
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static uint UInt32Remainder(uint left, uint right) => left % right;
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static long Int64Divide(long left, long right) => unchecked(left / right);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static long Int64Remainder(long left, long right) => unchecked(left % right);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static ulong UInt64Divide(ulong left, ulong right) => left / right;
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static ulong UInt64Remainder(ulong left, ulong right) => left % right;

    [MethodImpl(MethodImplOptions.NoInlining)]
    public static int Int32DivideLiteralMinusOne(int value) => unchecked(value / -1);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static int Int32RemainderLiteralMinusOne(int value) => unchecked(value % -1);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static long Int64DivideLiteralMinusOne(long value) => unchecked(value / -1L);
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static long Int64RemainderLiteralMinusOne(long value) => unchecked(value % -1L);

    public static int Int32CatchDivide(int left, int right)
    {
        try { return unchecked(left / right); }
        catch (DivideByZeroException) { return unchecked((int)0xDEAD0001u); }
    }
    public static uint UInt32CatchDivide(uint left, uint right)
    {
        try { return left / right; }
        catch (DivideByZeroException) { return 0xDEAD0002u; }
    }
    public static long Int64CatchDivide(long left, long right)
    {
        try { return unchecked(left / right); }
        catch (DivideByZeroException) { return unchecked((long)0xDEAD0003FEDCBA98ul); }
    }
    public static ulong UInt64CatchDivide(ulong left, ulong right)
    {
        try { return left / right; }
        catch (DivideByZeroException) { return 0xDEAD0004FEDCBA98ul; }
    }
    public static int Int32CatchOverflow(int left, int right)
    {
        try { return unchecked(left / right); }
        catch (OverflowException) { return unchecked((int)0xDEAD0005u); }
    }
    public static long Int64CatchOverflow(long left, long right)
    {
        try { return unchecked(left / right); }
        catch (OverflowException) { return unchecked((long)0xDEAD0006FEDCBA98ul); }
    }

    // On a fault the search pass runs the filter before the unwind pass runs
    // finally: trace becomes 1, then 12. The catch reads that same original local.
    public static int Int32FilterFinally(int left, int right)
    {
        int trace = 0;
        try
        {
            try { return unchecked(left / right); }
            finally { trace = unchecked(trace * 10 + 2); }
        }
        catch (DivideByZeroException) when (FilterTrace(ref trace)) { return trace; }
    }
    public static long Int64FilterFinally(long left, long right)
    {
        int trace = 0;
        try
        {
            try { return unchecked(left / right); }
            finally { trace = unchecked(trace * 10 + 2); }
        }
        catch (DivideByZeroException) when (FilterTrace(ref trace)) { return trace; }
    }
    public static int Int32Rethrow(int left, int right)
    {
        try { return unchecked(left / right); }
        catch (OverflowException) { throw; }
    }
    public static long Int64Rethrow(long left, long right)
    {
        try { return unchecked(left / right); }
        catch (OverflowException) { throw; }
    }
    public static int Int32ReplaceInFinally(int left, int right)
    {
        try { return unchecked(left / right); }
        finally { _ = Int32Remainder(1, 0); }
    }
    public static long Int64ReplaceInFinally(long left, long right)
    {
        try { return unchecked(left / right); }
        finally { _ = Int64Remainder(1, 0); }
    }

    private static bool FilterTrace(ref int trace)
    {
        trace = unchecked(trace * 10 + 1);
        return true;
    }
}
