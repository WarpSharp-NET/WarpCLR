using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Reflection.Emit;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

[TestClass]
[DoNotParallelize]
[SuppressMessage("Performance", "CA1812:Avoid uninstantiated internal classes", Justification = "MSTest discovers this fixture through reflection.")]
internal sealed partial class WarpPortableCilIntegerDivisionTests
{
    public TestContext TestContext { get; set; } = null!;

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void TwentyServicesHaveExactWordSignaturesAndVerifiedNondivisionClosure(bool wide)
    {
        MethodInfo[] services = Services(wide);
        Assert.AreEqual(wide ? 12 : 8, services.Length);
        foreach (MethodInfo service in services)
        {
            Assert.AreEqual(typeof(uint), service.ReturnType);
            CollectionAssert.AreEqual(Enumerable.Repeat(typeof(uint), wide ? 4 : 2).ToArray(), service.GetParameters().Select(parameter => parameter.ParameterType).ToArray());
            WarpLogicalMachineLayout layout = ServiceLayout(service, wide);
            Assert.AreEqual(1, layout.ResultWordCount);
            Assert.AreEqual(wide ? 4 : 2, layout.Kernel.InputBufferCount);
            Assert.AreEqual(0, layout.Kernel.ScalarArgumentCount);
            Assert.IsTrue(layout.Kernel.Execution!.Bodies.All(body => body.RuntimeHelper && !body.CountsSourceDepth && body.SourceBlockCosts.All(cost => cost == 0)));
            Assert.IsNull(layout.Kernel.Execution.PrivateControllerProjection);
            Assert.IsFalse(layout.Kernel.Execution.ManagedExceptionTermination);
        }
    }

    [TestMethod]
    [DataRow("Int32Divide")]
    [DataRow("Int32Remainder")]
    [DataRow("UInt32Divide")]
    [DataRow("UInt32Remainder")]
    [DataRow("Int64Divide")]
    [DataRow("Int64Remainder")]
    [DataRow("UInt64Divide")]
    [DataRow("UInt64Remainder")]
    public void GenuineUncheckedSourceKeepsItsNamedImplicitFaultDenial(string name)
    {
        MethodInfo source = Source(name);
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        RecordOriginalSource(source, EvidenceDirectory(name + "-capture-denial"), name);
        WarpPortableMethodGraphMethod captured = graph.Methods.Single(method => method.Identity == graph.EntryIdentity);
        Assert.IsTrue(captured.Instructions.Any(instruction => instruction.OpCode == SourceOpcode(name)));
        WarpPortableTypedInstruction operation = typed.Methods.Single(method => method.Identity == graph.EntryIdentity).Instructions
            .Single(instruction => instruction.OpCode == SourceOpcode(name).Value);
        Assert.AreEqual(Wide(name) ? WarpPortableStackCategory.I8 : WarpPortableStackCategory.I4, operation.EntryStack[0].Category);
        Assert.AreEqual(Wide(name) ? 2 : 1, operation.EntryStack[0].WordCount);
        Assert.AreEqual(Unsigned(name) ? 1 : 2, operation.Faults.Length);
        Assert.AreEqual(WarpPortableTypedFaultKind.DivideByZero, operation.Faults[0].Kind);
        Assert.AreEqual(0, operation.Faults[0].EffectIndex);
        if (!Unsigned(name)) { Assert.AreEqual(WarpPortableTypedFaultKind.Overflow, operation.Faults[1].Kind); Assert.AreEqual(1, operation.Faults[1].EffectIndex); }
        AssertDefaultDenied(graph, typed, requireNumericMessage: true);
    }

    [TestMethod]
    [DataRow("Int32CatchDivide")]
    [DataRow("UInt32CatchDivide")]
    [DataRow("Int64CatchDivide")]
    [DataRow("UInt64CatchDivide")]
    [DataRow("Int32CatchOverflow")]
    [DataRow("Int64CatchOverflow")]
    [DataRow("Int32FilterFinally")]
    [DataRow("Int64FilterFinally")]
    [DataRow("Int32Rethrow")]
    [DataRow("Int64Rethrow")]
    [DataRow("Int32ReplaceInFinally")]
    [DataRow("Int64ReplaceInFinally")]
    public void GenuineHandlersPreserveOriginalEhRegionsWhileImplicitAdmissionStaysDenied(string name)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(Source(name));
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        RecordOriginalSource(Source(name), EvidenceDirectory(name + "-eh-capture-denial"), name);
        Assert.IsTrue(graph.Methods.Any(method => !method.ExceptionRegions.IsEmpty));
        Assert.IsTrue(typed.Methods.SelectMany(method => method.Instructions).Any(instruction =>
            instruction.Faults.Any(fault => fault.Kind == WarpPortableTypedFaultKind.DivideByZero)));
        AssertDefaultDenied(graph, typed, requireNumericMessage: false);
    }

    [TestMethod]
    [DataRow("Int32DivideLiteralMinusOne")]
    [DataRow("Int32RemainderLiteralMinusOne")]
    [DataRow("Int64DivideLiteralMinusOne")]
    [DataRow("Int64RemainderLiteralMinusOne")]
    public void LiteralMinusOneRetainsItsRealDivOrRemAndOverflowEffect(string name)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(Source(name));
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        RecordOriginalSource(Source(name), EvidenceDirectory(name + "-literal-capture-denial"), name);
        Assert.IsTrue(graph.Methods.Single(method => method.Identity == graph.EntryIdentity).Instructions.Any(instruction => instruction.OpCode == SourceOpcode(name)));
        Assert.IsTrue(typed.Methods.Single(method => method.Identity == graph.EntryIdentity).Instructions.Any(instruction =>
            instruction.OpCode == SourceOpcode(name).Value && instruction.Faults.Any(fault => fault.Kind == WarpPortableTypedFaultKind.Overflow)));
        AssertDefaultDenied(graph, typed, requireNumericMessage: true);
    }

    [TestMethod]
    [DataRow("WarpCLR.Tests.TestKernels", "Divide")]
    [DataRow("WarpCLR.Tests.Production.CurrentCoverage.WarpCurrentNumericSourceCases", "SignedDivide32")]
    [DataRow("WarpCLR.Tests.Production.CurrentCoverage.WarpCurrentNumericSourceCases", "SignedDivide64")]
    public void TheSameThreeOriginalDenialIdentitiesStayOpen(string type, string method)
    {
        MethodInfo source = typeof(TestKernels).Assembly.GetType(type, throwOnError: true)!.GetMethod(method)!;
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(source);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        RecordOriginalSource(source, EvidenceDirectory(method + "-same-original-denial"), method);
        Assert.IsTrue(typed.Methods.SelectMany(item => item.Instructions).Any(instruction => instruction.Faults.Any(fault => fault.Kind == WarpPortableTypedFaultKind.DivideByZero)));
        AssertDefaultDenied(graph, typed, requireNumericMessage: true);
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public void FiniteFactoryRowsDescribeExactSourceFaultsButCannotCreateAnOperationGrant(bool wide)
    {
        foreach (string name in Names(wide))
        {
            WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(Source(name));
            WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
            WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
            WarpPortableSourceFaultFactoryContract factory = WarpPortableSourceFaultFactoryContract.CaptureFinite(graph, typed, schema);
            Assert.AreEqual(Unsigned(name) ? 1 : 2, factory.Rows.Length);
            foreach (WarpPortableSourceFaultFactoryRow row in factory.Rows)
            {
                WarpPortableSourceHeapFault fault = schema.Faults.Single(item => item.MethodIdentity == row.MethodIdentity && item.SourceOffset == row.SourceOffset && item.EffectIndex == row.EffectIndex);
                Assert.AreEqual(fault.ExceptionType, row.ExceptionType);
                Assert.IsGreaterThan(0u, row.ExceptionType);
                Assert.AreEqual(fault.SourceOpCode, row.OpCode);
                Assert.AreEqual(0u, row.FaultDescriptor);
                Assert.AreEqual(row.Kind == WarpPortableTypedFaultKind.DivideByZero ? "Arg_DivideByZero" : "Arg_OverflowException", row.ResourceKey, StringComparer.Ordinal);
            }
            AssertDefaultDenied(graph, typed, requireNumericMessage: true);
        }
    }

    [TestMethod]
    public void ExistingOrdinaryMathAndLogicalContractsAreNotReversionedByTheUnusedServices()
    {
        Assert.AreEqual("warp.integer32/wrap-checked-divrem/0.1", WarpPortableInteger32.Semantics, StringComparer.Ordinal);
        Assert.AreEqual("warp.logical-machine/0.8", WarpLogicalMachineLayout.Version, StringComparer.Ordinal);
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(typeof(TestKernels).GetMethod(nameof(TestKernels.ManifestMap))!);
        WarpPortableWordLoweredProgram ordinary = WarpPortableWordLowerer.Lower(graph, WarpPortableTypedProgram.Verify(graph));
        Assert.IsFalse(ordinary.RequiredServices.Any(identity => identity.Contains("warp.cil.integer", StringComparison.Ordinal)));
        Assert.IsNull(ordinary.Kernel.Execution!.PrivateControllerProjection);
    }

    private static MethodInfo Source(string name) => typeof(WarpPortableCilIntegerDivisionSourceKernels).GetMethod(name)!;
    private static bool Wide(string name) => name.Contains("64", StringComparison.Ordinal);
    private static bool Unsigned(string name) => name.StartsWith("UInt", StringComparison.Ordinal);
    private static OpCode SourceOpcode(string name) => name.Contains("Remainder", StringComparison.Ordinal) ?
        Unsigned(name) ? OpCodes.Rem_Un : OpCodes.Rem : Unsigned(name) ? OpCodes.Div_Un : OpCodes.Div;
    private static string[] Names(bool wide) => wide ? ["Int64Divide", "Int64Remainder", "UInt64Divide", "UInt64Remainder"] :
        ["Int32Divide", "Int32Remainder", "UInt32Divide", "UInt32Remainder"];
    private static MethodInfo[] Services(bool wide) => (wide ? typeof(WarpPortableCilIntegerDivision64) : typeof(WarpPortableCilIntegerDivision32))
        .GetMethods(BindingFlags.Public | BindingFlags.Static).OrderBy(method => method.Name, StringComparer.Ordinal).ToArray();

    private static WarpLogicalMachineLayout ServiceLayout(MethodInfo service, bool wide)
    {
        WarpControlFlowKernel original = new WarpIntegerMapVerifier().Verify(new WarpIntegerMapRequest(service, wide ? 4 : 2)).ControlFlow;
        WarpLogicalBodyMetadata[] bodies = [new(0, true, new int[original.Blocks.Count]),
            .. original.Functions.Select(function => new WarpLogicalBodyMetadata(0, true, new int[function.Blocks.Count]))];
        var metadata = new WarpLogicalExecutionMetadata(bodies, recursiveCalls: false);
        string semantics = wide ? WarpPortableCilIntegerDivision64.Semantics : WarpPortableCilIntegerDivision32.Semantics;
        return new(new WarpControlFlowKernel(original.Name + "/" + semantics, original.InputBufferCount,
            original.ScalarArgumentCount, original.Blocks, original.Reduction, original.Functions, metadata));
    }

    private void AssertDefaultDenied(WarpPortableMethodGraph graph, WarpPortableTypedProgram typed, bool requireNumericMessage)
    {
        WarpVerificationException failure = Assert.ThrowsExactly<WarpVerificationException>(() => WarpPortableWordLowerer.Lower(graph, typed));
        WriteEvidence(EvidenceDirectory("default-denial-" + graph.GraphHash), "exact-source-fault-denial", new
        {
            graph.EntryIdentity, graph.GraphHash, typed.VerifiedHash, failure.Code, failure.Message,
            SourceMethods = typed.Methods.Select(method => new { method.Identity, method.Instructions }),
            DefaultSourceLoweringSucceeded = false, OperationTicketIssued = false, SourceGrant = false,
        });
        Assert.AreEqual("WRPCLR2300", failure.Code, StringComparer.Ordinal);
        if (requireNumericMessage) { StringAssert.Contains(failure.Message, "generated fault/EH continuation", StringComparison.Ordinal); }
    }
}
