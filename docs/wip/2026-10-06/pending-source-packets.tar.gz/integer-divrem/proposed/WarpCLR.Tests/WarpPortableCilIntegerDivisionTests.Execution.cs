using System.Globalization;
using WarpCLR.Backend.CoreCLR;
using WarpCLR.IR;
using WarpCLR.Runtime.Host;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableCilIntegerDivisionTests
{
    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task ActualOrdinaryChildKeepsAllPrimitiveBitsBanksAndZeroSourceChargesAtBothQuanta(bool wide)
    {
        foreach (System.Reflection.MethodInfo service in Services(wide))
        {
            WarpLogicalMachineLayout layout = ServiceLayout(service, wide);
            string directory = EvidenceDirectory(service.Name + "-" + (wide ? "64" : "32") + "-child");
            RecordOriginalSource(service, directory, "uint-word-primitive-not-guest-division");
            WarpCoreCLRWorkerProcess child = await CompileChildAsync(layout, directory).ConfigureAwait(false);
            try
            {
                int vector = 0;
                foreach (uint[] input in WarpPortableCilIntegerDivisionSeeds.Pairs(wide))
                {
                    // Allocate this exact initial bank ONCE, before choosing a
                    // quantum or backend. Future LLVM comparisons reuse its bytes.
                    uint[] initial = layout.CreateInitialState(32, 1);
                    uint[]? prior = null;
                    foreach (int quantum in new[] { layout.MaximumBlockCost, Math.Max(4096, checked(layout.MaximumBlockCost + 1)) })
                    {
                        uint[] completed = await RunChildAsync(child, layout, initial, input, quantum, directory, vector).ConfigureAwait(false);
                        Assert.AreEqual(WarpLogicalMachineLayout.Completed, completed[WarpLogicalMachineLayout.StatusOffset]);
                        Assert.AreEqual(1u, completed[WarpLogicalMachineLayout.RemainingStepsLowOffset]);
                        Assert.AreEqual(0u, completed[WarpLogicalMachineLayout.RemainingStepsHighOffset]);
                        Assert.AreEqual(ExpectedService(wide, service.Name, input), completed[layout.GetResultWordOffset(0, 32)]);
                        if (prior is not null) { CollectionAssert.AreEqual(prior, completed); }
                        prior = completed;
                    }
                    vector++;
                }
            }
            finally { await StopChildAsync(child, directory).ConfigureAwait(false); }
        }
    }

    [TestMethod]
    [DataRow(false)]
    [DataRow(true)]
    public async Task ACompiledFaultSelectorIsDataAndNeverPretendsToRaiseTheOriginalGuestException(bool wide)
    {
        System.Reflection.MethodInfo service = Services(wide).Single(method => method.Name == "RemainderSignedFault");
        WarpLogicalMachineLayout layout = ServiceLayout(service, wide);
        string directory = EvidenceDirectory("fault-selector-is-not-eh-" + (wide ? "64" : "32"));
        WarpCoreCLRWorkerProcess child = await CompileChildAsync(layout, directory).ConfigureAwait(false);
        try
        {
            uint[][] vectors = wide ? [[0, 0x80000000, uint.MaxValue, uint.MaxValue], [1, 0, 0, 0]] : [[0x80000000, uint.MaxValue], [1, 0]];
            for (int index = 0; index < vectors.Length; index++)
            {
                uint[] initial = layout.CreateInitialState(32, 1);
                uint[] state = await RunChildAsync(child, layout, initial, vectors[index], layout.MaximumBlockCost, directory, index).ConfigureAwait(false);
                Assert.AreEqual(index == 0 ? 2u : 1u, state[layout.GetResultWordOffset(0, 32)]);
                Assert.AreEqual(WarpLogicalMachineLayout.Completed, state[WarpLogicalMachineLayout.StatusOffset]);
                Assert.AreEqual(0u, state[WarpLogicalMachineLayout.FaultKindOffset]);
                Assert.IsFalse(layout.Kernel.Execution!.ManagedExceptionTermination);
            }
        }
        finally { await StopChildAsync(child, directory).ConfigureAwait(false); }
    }

    private static uint ExpectedService(bool wide, string name, uint[] input)
    {
        bool signed = !name.Contains("Unsigned", StringComparison.Ordinal);
        WarpPortableCilIntegerDivisionOracle.Result expected = WarpPortableCilIntegerDivisionOracle.Calculate(wide, signed, name.StartsWith("Remainder", StringComparison.Ordinal), input);
        if (name.EndsWith("Fault", StringComparison.Ordinal)) { return expected.Fault; }
        return expected.Words[wide && name.EndsWith("High", StringComparison.Ordinal) ? 1 : 0];
    }

    private static async Task<uint[]> RunChildAsync(WarpCoreCLRWorkerProcess child, WarpLogicalMachineLayout layout,
        uint[] initial, uint[] input, int quantum, string directory, int vector)
    {
        uint[] state = (uint[])initial.Clone();
        uint[][] inputs = input.Select(word => new uint[] { word, 0xDEADBEEF, 0x7FC01234 }).ToArray();
        uint[] arena = [0xDEADBEEF, 0x80000000, 0x7F800001, 0xFFF00001, uint.MaxValue, 0, 1, 0x12345678];
        string prefix = "v" + vector.ToString("D4", CultureInfo.InvariantCulture) + "-q" + quantum.ToString(CultureInfo.InvariantCulture);
        WriteEvidence(directory, prefix + "-initial", new { State = state, Inputs = inputs, Arena = arena, OriginalInputWords = input,
            SharedExactSeedForAllDialectsRequired = true, SourceDivisionAdmission = false, ControllerAuthority = false });
        for (int step = 0; step < 4096 && state[WarpLogicalMachineLayout.StatusOffset] == WarpLogicalMachineLayout.Runnable; step++)
        {
            uint[] before = (uint[])state.Clone();
            uint[] beforeArena = (uint[])arena.Clone();
            uint[][] beforeInputs = inputs.Select(words => (uint[])words.Clone()).ToArray();
            try { await child.ExecuteManagedQuantumAsync(layout, inputs, [], 0, state, 32, quantum, arena, CancellationToken.None).ConfigureAwait(false); }
            catch (Exception failure)
            {
                WriteEvidence(directory, prefix + "-failed" + step.ToString("D4", CultureInfo.InvariantCulture), new
                { Before = before, After = state, BeforeArena = beforeArena, AfterArena = arena, BeforeInputs = beforeInputs, AfterInputs = inputs, Error = failure.ToString() });
                CollectionAssert.AreEqual(before, state); CollectionAssert.AreEqual(beforeArena, arena);
                for (int index = 0; index < inputs.Length; index++) { CollectionAssert.AreEqual(beforeInputs[index], inputs[index]); }
                throw;
            }
            WarpCoreCLRWorkerProcess.WordCheckpoint receipt = child.RequireCommittedWordCheckpoint(state, arena);
            child.ValidateCommittedWordCheckpoint(receipt, state, arena);
            WriteEvidence(directory, prefix + "-step" + step.ToString("D4", CultureInfo.InvariantCulture), new
            { Before = before, After = state, BeforeArena = beforeArena, AfterArena = arena, BeforeInputs = beforeInputs, AfterInputs = inputs,
                receipt.Ordinal, receipt.Sequence, receipt.RequestHash, receipt.ResponseHash, receipt.ProcessId, receipt.Module, receipt.IrHash, SourceGrant = false });
            CollectionAssert.AreEqual(beforeArena, arena);
            for (int index = 0; index < inputs.Length; index++) { CollectionAssert.AreEqual(beforeInputs[index], inputs[index]); }
        }
        Assert.AreNotEqual(WarpLogicalMachineLayout.Runnable, state[WarpLogicalMachineLayout.StatusOffset], "Finite declared trace cap exhausted; no partial success.");
        return state;
    }
}
