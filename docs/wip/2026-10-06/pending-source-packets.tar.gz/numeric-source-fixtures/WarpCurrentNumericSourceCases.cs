namespace WarpCLR.Tests.Production.CurrentCoverage;

// SOURCE ONLY. Root must compile this file with pinned Release settings, retain
// the actual PE/MVID/token/CIL, and discover/verify the original typed methods.
// These are guest numeric sources, never production word helper substitutes.
// Tests/semantic IDs/oracle grounding are pinned by coverage-matrix.json.
internal static class WarpCurrentNumericSourceCases
{
    public static int AddInt32(int left, int right) => unchecked(left + right);
    public static uint AddUInt32(uint left, uint right) => unchecked(left + right);
    public static long AddInt64(long left, long right) => unchecked(left + right);
    public static ulong AddUInt64(ulong left, ulong right) => unchecked(left + right);
    public static int ShiftSigned32(int value, int count) => value >> count;
    public static long ShiftSigned64(long value, int count) => value >> count;

    public static float Remainder32(float left, float right) => left % right;
    public static double Remainder64(double left, double right) => left % right;
    public static bool Less32(float left, float right) => left < right;
    public static bool Less64(double left, double right) => left < right;
    public static bool LessOrEqual32(float left, float right) => left <= right;
    public static bool LessOrEqual64(double left, double right) => left <= right;
    public static bool Equal32(float left, float right) => left == right;
    public static bool Equal64(double left, double right) => left == right;
    public static bool NotEqual32(float left, float right) => left != right;
    public static bool NotEqual64(double left, double right) => left != right;
    public static float Negate32(float value) => -value;
    public static double Negate64(double value) => -value;

    public static double Widen32To64(float value) => value;
    public static float Int32ToSingle(int value) => value;
    public static double Int32ToDouble(int value) => value;
    public static float UInt32ToSingle(uint value) => value;
    public static double UInt32ToDouble(uint value) => value;
    public static float Int64ToSingle(long value) => value;
    public static double Int64ToDouble(long value) => value;
    public static float UInt64ToSingle(ulong value) => value;
    public static double UInt64ToDouble(ulong value) => value;

    // The portable unchecked profile is explicit truncation/saturation/NaN0.
    // Actual pinned CoreCLR source-cast outputs are a separate required oracle.
    // A mismatch is a blocker; neither these casts nor expected bits are edited
    // to disguise a runtime/architecture discrepancy.
    public static int SingleToInt32(float value) => unchecked((int)value);
    public static uint SingleToUInt32(float value) => unchecked((uint)value);
    public static long SingleToInt64(float value) => unchecked((long)value);
    public static ulong SingleToUInt64(float value) => unchecked((ulong)value);
    public static int DoubleToInt32(double value) => unchecked((int)value);
    public static uint DoubleToUInt32(double value) => unchecked((uint)value);
    public static long DoubleToInt64(double value) => unchecked((long)value);
    public static ulong DoubleToUInt64(double value) => unchecked((ulong)value);

    public static float Minimum32(float left, float right) => System.MathF.Min(left, right);
    public static double Minimum64(double left, double right) => System.Math.Min(left, right);
    public static float Maximum32(float left, float right) => System.MathF.Max(left, right);
    public static double Maximum64(double left, double right) => System.Math.Max(left, right);
    public static float Sqrt32(float value) => System.MathF.Sqrt(value);
    public static double Sqrt64(double value) => System.Math.Sqrt(value);
    public static float Fma32(float left, float right, float addend) => System.MathF.FusedMultiplyAdd(left, right, addend);
    public static double Fma64(double left, double right, double addend) => System.Math.FusedMultiplyAdd(left, right, addend);

    // Thirteen default-lowering denials. Do not omit faulting inputs, widen the
    // operations or replace faults with value/fault-descriptor success tuples.
    public static int CheckedAddInt32(int left, int right) => checked(left + right);
    public static uint CheckedAddUInt32(uint left, uint right) => checked(left + right);
    public static long CheckedAddInt64(long left, long right) => checked(left + right);
    public static ulong CheckedAddUInt64(ulong left, ulong right) => checked(left + right);
    public static int CheckedDoubleToInt32(double value) => checked((int)value);
    public static uint CheckedDoubleToUInt32(double value) => checked((uint)value);
    public static long CheckedDoubleToInt64(double value) => checked((long)value);
    public static ulong CheckedDoubleToUInt64(double value) => checked((ulong)value);
    public static int SignedDivide32(int left, int right) => left / right;
    public static long SignedDivide64(long left, long right) => left / right;
    public static int Sign32(float value) => System.MathF.Sign(value);
    public static int Sign64(double value) => System.Math.Sign(value);
    public static short DoubleToInt16(double value) => unchecked((short)value);
}
