from pathlib import Path
import argparse
import hashlib
import json
import os
import time
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('boundary')
parser.add_argument('destination')
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[2]
base = workspace / '.supervisor-evidence' / args.boundary
read = lambda path: json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


preparation = read(base / 'preparation.json')
root = Path(preparation['root'])
commands_file = base / 'commands.json'
if commands_file.exists():
    commands = read(commands_file)
else:
    preflight = read(base / 'validation-preflight-failure.json')
    assert preflight['exit_code'] == 1 and preflight['actual_dotnet_command_started'] is False
    assert not (base / 'owned-build-output').exists()
    commands = [preflight]
assert commands and all(row['state'] == 'complete' for row in commands)
assert all(digest(base / (row['label'] + '.log')) == row['log_sha256'] for row in commands)
baseline = Path(preparation['baseline_manifest'])
assert digest(baseline) == preparation['baseline_manifest_sha256']
parent = read(baseline)
references = {}


def add(path, role):
    path = path.resolve()
    assert path.is_file() and not path.is_symlink(), path
    references.setdefault(str(path), dict(path=str(path), role=role, sha256=digest(path), bytes=path.stat().st_size))


for row in parent['source']:
    path = Path(row['readonly_reference'])
    assert digest(path) == row['sha256'] and not path.stat().st_mode & 0o222
    add(path, 'complete-exact-Core-and-SDK-prerequisite')
for row in preparation['build_inputs']:
    path = Path(row['path'])
    assert digest(path) == row['sha256']
    add(path, 'complete-effective-actual-project-source-policy-input')
for row in preparation['owned_files']:
    path = Path(row['absolute_path'])
    assert digest(path) == row['sha256']
    add(path, 'exact-owned-product-delta')
    if row.get('preimage'):
        path = Path(row['preimage'])
        assert digest(path) == row['preimage_sha256']
        add(path, 'exact-owned-product-preimage')
for row in preparation.get('component_manifests', []):
    path = Path(row['path'])
    assert digest(path) == row['sha256']
    add(path, 'exact-component-application-and-provenance-manifest')
# Preserve referenced source-only packet files as well as the linked actual build.
component_file_paths = set()

def collect_component_paths(value):
    if isinstance(value, dict):
        for entry in value.values():
            collect_component_paths(entry)
    elif isinstance(value, list):
        for entry in value:
            collect_component_paths(entry)
    elif isinstance(value, str) and value.startswith(str(workspace) + '/'):
        path = Path(value)
        if path.is_file():
            component_file_paths.add(path.resolve())

pending_components = [Path(row['path']) for row in preparation.get('component_manifests', [])]
seen_components = set()
while pending_components:
    component = pending_components.pop()
    if component.resolve() in seen_components:
        continue
    seen_components.add(component.resolve())
    packet = read(component)
    before_paths = set(component_file_paths)
    collect_component_paths(packet)
    for candidate in component_file_paths - before_paths:
        if candidate.name in ('prepared-application-manifest.json', 'source-application-manifest.json',
                              'prepared-source-delta.json', 'prepared-component-manifest.json'):
            pending_components.append(candidate)
frozen_main_sources = {str(workspace / ('WarpCLR' if row['repository'] == 'core' else 'WarpCLR.CSharp.SDK') / row['path']): row
                       for row in parent['source']}
component_live_main_witnesses = []
for path in component_file_paths:
    # A packet's product target can name live Main; preserve its exact immutable baseline.
    if path.is_relative_to(workspace / 'WarpCLR') or path.is_relative_to(workspace / 'WarpCLR.CSharp.SDK'):
        source = frozen_main_sources[str(path)]
        assert digest(path) == source['sha256'], path
        component_live_main_witnesses.append(dict(actual_path=str(path), sha256=source['sha256'],
                                                   readonly_reference=source['readonly_reference']))
        path = Path(source['readonly_reference'])
    add(path, 'complete-source-only-component-file-preimage-patch-policy-or-provenance')
for row in preparation['owned_files']:
    if row.get('failed_boundary_preimage'):
        path = Path(row['failed_boundary_preimage'])
        assert digest(path) == row['failed_boundary_preimage_sha256']
        add(path, 'exact-retained-prior-build-preimage')

for key in ('retained_failed_boundary', 'metadata_only_oracle'):
    if key in preparation:
        path = Path(preparation[key])
        assert digest(path) == preparation[key + '_sha256']
        add(path, 'complete-prior-failure-or-verified-metadata-provenance')
for directory in (root, base):
    for path in directory.rglob('*'):
        if path.is_file():
            add(path, 'complete-physical-source-project-bin-obj-output-log-trx-witness-and-tool')
add(baseline, 'complete-sealed-baseline-manifest')
add(Path(__file__).resolve(), 'preservation-tool')
for attempt in sorted(base.glob('preservation-attempt-*.json')):
    saved = read(attempt)
    path = Path(saved['tool'])
    assert digest(path) == saved['tool_sha256']
    add(path, 'exact-failed-preservation-attempt-tool')
add(Path(preparation.get('validation_driver', str(Path(__file__).with_name('validate_linked_core_boundary.py')))), 'exact-validation-driver')
extra_tool_provenance = base / 'additional-execution-tool-provenance.json'
if extra_tool_provenance.exists():
    add(extra_tool_provenance, 'exact-additional-execution-tool-provenance')
    for tool in read(extra_tool_provenance)['tools']:
        path = Path(tool['path'])
        assert digest(path) == tool['sha256'] and path.stat().st_size == tool['bytes']
        assert not path.stat().st_mode & 0o222
        add(path, 'exact-interrupted-phase-recovery-and-containment-observer-tool')
for path in Path(__file__).parent.glob('prepare_owned_cleanup_prewarming_envelope*.py'):
    add(path, 'exact-source-composition-preparation-tool')
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
summaries = []
failures = []
for path in sorted(base.rglob('*.trx')):
    tree = ET.parse(path)
    counts = tree.find('.//t:ResultSummary/t:Counters', ns)
    assert counts is not None
    summaries.append(dict(path=str(path), sha256=digest(path), tests=dict(counts.attrib)))
    for row in tree.findall('.//t:UnitTestResult', ns):
        if row.get('outcome') != 'Passed':
            error = row.find('t:Output/t:ErrorInfo', ns)
            failures.append(dict(test=row.get('testName'), outcome=row.get('outcome'),
                error_xml=ET.tostring(error, encoding='unicode') if error is not None else ''))
ancestors = set()
pid = os.getpid()
while pid > 1:
    ancestors.add(pid)
    try:
        pid = int(Path('/proc/' + str(pid) + '/stat').read_text().rsplit(')', 1)[1].split()[1])
    except (OSError, ValueError):
        break
groups = {row['pgid'] for row in commands if row.get('pgid') is not None}
live = []
for directory in Path('/proc').iterdir():
    if not directory.name.isdigit() or int(directory.name) in ancestors:
        continue
    try:
        pid = int(directory.name)
        command = (directory / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
        if os.getpgid(pid) in groups or str(root) in command or str(base) in command:
            live.append(dict(pid=pid, pgid=os.getpgid(pid), command=command))
    except (OSError, ValueError):
        pass
assert not live, live
for row in references.values():
    path = Path(row['path'])
    if path.stat().st_mode & 0o222:
        path.chmod(path.stat().st_mode & ~0o222)
    assert not path.stat().st_mode & 0o222, path
destination = base / args.destination
assert not destination.exists()
destination.parent.mkdir(exist_ok=True)
owner_pause = read(base / 'owner-requested-pause-cancellation.json')
assert owner_pause['owner_instruction'] == 'Commit your current work as wip and sign off for now.'
stop_receipt = read(base / 'owner-requested-pause-descendant-stop.json')
assert not stop_receipt['after']
actual_test_driver = read(base / 'tests-persistent-completion.json')
assert actual_test_driver['actual_driver_exit_code'] != 0
observed_failure_headers = sum(line.lstrip().startswith('Failed ')
    for line in (base / 'checkpoint-tests.log').read_text(errors='replace').splitlines())
assert observed_failure_headers > 0
failed = True
receipt = dict(owner_requested_pause=True,
    validation_outcome='INTERRUPTED at owner request with observed failures; not a validated checkpoint',
    actual_tests_driver_exit_code=actual_test_driver['actual_driver_exit_code'],
    observed_failure_headers_before_cancellation=observed_failure_headers,
    targeted_tests_completed=False, owner_cancellation=owner_pause, owner_stop=stop_receipt,
    baseline_preservation_tool=str(original) if False else str(Path(__file__).with_name('preserve_linked_core_boundary_v5.py')),
    boundary=args.boundary, effective_core_source_files=preparation['source_files'],
    complete_core_sdk_prerequisite_source_files=parent['source_files'], owned_source=preparation['owned_files'],
    commands=commands, test_summaries=summaries, test_failures=failures,
    correction_not_yet_applied=failed, all_actual_outputs_and_intermediates_preserved=True,
    full_tests_ran=any(row['label'] == 'full-tests' for row in commands),
    actual_fresh_projects=preparation['actual_project_names'], source_quota_and_quarantine_not_relaxed=True,
    owned_finished_command_groups=sorted(groups), owned_live_producers=live,
    new_source_artifact_or_proof_copies=0, private_source_grant_issuer=False,
    full_production_readiness=False, review_handoff=False, generated_unix_seconds=time.time(),
    component_live_main_hash_to_frozen_source_witnesses=component_live_main_witnesses,
    references=sorted(references.values(), key=lambda row: row['path']))
destination.write_text(json.dumps(receipt, indent=2) + '\n')
destination.chmod(0o444)
print(json.dumps(dict(boundary=args.boundary, manifest_sha256=digest(destination), references=len(references),
    effective_core_source_files=preparation['source_files'], full_tests_ran=receipt['full_tests_ran'],
    test_summaries=summaries, failed=failed)), flush=True)
