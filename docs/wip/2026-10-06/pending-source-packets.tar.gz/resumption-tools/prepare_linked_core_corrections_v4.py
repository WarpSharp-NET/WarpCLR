from pathlib import Path
import argparse
import hashlib
import json
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('prior_boundary')
parser.add_argument('new_boundary')
parser.add_argument('retained_failure_sha256')
parser.add_argument('--retained-manifest', default='retained-complete-release-build-failure-1/manifest.json')
parser.add_argument('component_manifest', nargs='*')
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[2]
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text())
prior_base = workspace / '.supervisor-evidence' / args.prior_boundary
failed = prior_base / args.retained_manifest
assert digest(failed) == args.retained_failure_sha256
failure = read(failed)
assert failure['owned_live_producers'] == []
successful_fixture_boundary = failure['correction_not_yet_applied'] is False
if successful_fixture_boundary:
    assert args.retained_manifest == 'retained-complete-token-relocation-build-1.json'
    assert not failure['full_tests_ran'] and len(failure['commands']) == 4
    assert all(row['exit_code'] == row['diagnostic_occurrences'] == 0 for row in failure['commands'])
else:
    assert failure['correction_not_yet_applied'] is True
prior = read(prior_base / 'preparation.json')
master = Path(prior['baseline_manifest'])
assert digest(master) == prior['baseline_manifest_sha256']
main_sources = {row['path']: Path(row['readonly_reference']) for row in read(master)['source'] if row['repository'] == 'core'}
source = {row['logical_path']: Path(row['path']) for row in prior['build_inputs']}
owned = {row['path']: dict(row) for row in prior['owned_files']}
for row in prior['build_inputs']:
    path = Path(row['path'])
    assert digest(path) == row['sha256'] and not path.stat().st_mode & 0o222
components = []
corrections = []
sites = []
seen = set()
for argument in args.component_manifest:
    manifest_path = Path(argument).resolve()
    assert not manifest_path.stat().st_mode & 0o222
    packet = read(manifest_path)
    if successful_fixture_boundary:
        assert packet['fixture_declaration_changes_only'] and not packet['relaxed_hash_allowance']
        assert packet['retained_complete_build_sha256'] == digest(failed)
        oracle = read(Path(packet['metadata_oracle']))
        assert digest(Path(packet['metadata_oracle'])) == packet['metadata_oracle_sha256']
        assert oracle['SourceMethodsAndInitializersExecuted'] is False
        assert all(row['AllOriginalCilSemanticsEqual'] and row['BaselineMethodCount'] == row['CandidateMethodCount'] == 19 for row in oracle['Comparisons'])
        assert {row['path'] for row in packet['owned_source']} == {'WarpCLR.Tests/AssemblyInfo.cs', 'WarpCLR.Tests/ManifestAssemblyFixture.cs'}
    components.append(dict(path=str(manifest_path), sha256=digest(manifest_path), bytes=manifest_path.stat().st_size))
    sites.extend(packet.get('necessary_suppressions', []))
    for correction in packet['owned_source']:
        relative = correction['path']
        assert relative in source and relative.endswith('.cs') and relative not in seen
        seen.add(relative)
        before = source[relative]
        assert before.resolve() == Path(correction['failed_boundary_preimage']).resolve()
        assert digest(before) == correction['failed_boundary_preimage_sha256']
        path = Path(correction['absolute_path'])
        assert digest(path) == correction['sha256'] and path.stat().st_size == correction['bytes'] and not path.stat().st_mode & 0o222
        if relative not in owned:
            assert digest(main_sources[relative]) == digest(before)
            owned[relative] = dict(path=relative, preimage=str(main_sources[relative]), preimage_sha256=digest(before),
                                   actual_production_assembly=Path(relative).parts[0])
        owned[relative].update(absolute_path=str(path), sha256=digest(path), bytes=path.stat().st_size,
            failed_boundary_preimage=str(before), failed_boundary_preimage_sha256=digest(before))
        source[relative] = path
        corrections.append(dict(correction))
base = workspace / '.supervisor-evidence' / args.new_boundary
root = workspace / '.supervisor-stage' / args.new_boundary
assert not base.exists() and not root.exists()
base.mkdir()
root.mkdir()
for name in ('.editorconfig', 'Directory.Build.props', 'Directory.Packages.props', 'BannedSymbols.txt', 'global.json'):
    path = root / name
    path.write_bytes(source[name].read_bytes())
    source[name] = path
projects = []
solution = ET.Element('Solution')
for relative, original_path in sorted(main_sources.items()):
    if not relative.endswith('.csproj'):
        continue
    name = Path(relative).stem
    projects.append(name)
    directory = root / name
    directory.mkdir(exist_ok=True)
    project = ET.parse(original_path).getroot()
    properties = ET.SubElement(project, 'PropertyGroup')
    for key, value in {'EnableDefaultCompileItems': 'false', 'RuntimeFrameworkVersion': '10.0.12', 'RollForward': 'Disable'}.items():
        ET.SubElement(properties, key).text = value
    group = ET.SubElement(project, 'ItemGroup')
    for logical, physical in sorted(source.items()):
        if not logical.startswith(name + '/'):
            continue
        if logical.endswith('.cs'):
            ET.SubElement(group, 'Compile', {'Include': str(physical), 'Link': str(Path(logical).relative_to(name))})
        elif Path(logical).name in ('PublicAPI.Shipped.txt', 'PublicAPI.Unshipped.txt'):
            ET.SubElement(group, 'AdditionalFiles', {'Include': str(physical)})
    target = directory / original_path.name
    ET.indent(project, space='  ')
    target.write_text(ET.tostring(project, encoding='unicode') + '\n')
    source[relative] = target
    ET.SubElement(solution, 'Project', {'Path': str(target.relative_to(root))})
assert len(projects) == 12 and len(source) == prior['source_files'] and len(owned) == len(prior['owned_files']) + len(seen - {row['path'] for row in prior['owned_files']})
target = root / 'WarpCLR.slnx'
ET.indent(solution, space='  ')
target.write_text(ET.tostring(solution, encoding='unicode') + '\n')
source['WarpCLR.slnx'] = target
provenance = base / 'source-only-composition-inputs.json'
provenance.write_text(json.dumps(dict(components=components,
    preparation_tool=str(Path(__file__).resolve()), preparation_tool_sha256=digest(Path(__file__)),
    extra_root_source_preparation_tool=str(Path(__file__).with_name('prepare_tool_resource_test_analyzers.py')),
    new_source_or_artifact_copies=0), indent=2) + '\n')
components.append(dict(path=str(provenance), sha256=digest(provenance), bytes=provenance.stat().st_size))
package_cache = Path('/home/codex/.nuget/packages')
assert package_cache.is_dir()
validation_driver = Path(__file__).with_name('validate_linked_core_boundary_v2.py')
assert validation_driver.is_file() and not validation_driver.stat().st_mode & 0o222
for package, version in [('meziantou.analyzer', '3.0.294'), ('roslynator.analyzers', '5.0.0'),
                         ('microsoft.visualstudio.threading.analyzers', '18.7.23'),
                         ('microsoft.codeanalysis.bannedapianalyzers', '5.6.0'),
                         ('microsoft.codeanalysis.publicapianalyzers', '5.6.0'),
                         ('netfabric.hyperlinq.analyzer', '2.3.0'), ('mstest.testframework', '4.0.2')]:
    assert (package_cache / package / version).is_dir(), (package, version)
preparation = dict(prior, root=str(root), package_cache=str(package_cache),
    package_cache_provenance='Reuse existing populated user-global cache; no new package/source/proof copies.',
    validation_driver=str(validation_driver), validation_driver_sha256=digest(validation_driver),
    build_inputs=[dict(logical_path=relative, path=str(path), sha256=digest(path), bytes=path.stat().st_size)
                  for relative, path in sorted(source.items())],
    owned_files=sorted(owned.values(), key=lambda row: row['path']), actual_project_names=projects,
    retained_failed_boundary=str(failed), retained_failed_boundary_sha256=digest(failed),
    component_manifests=prior['component_manifests'] + [dict(path=str(prior_base / 'preparation.json'),
        sha256=digest(prior_base / 'preparation.json'), bytes=(prior_base / 'preparation.json').stat().st_size)] + components,
    analyzer_corrections=corrections, necessary_suppressions=prior.get('necessary_suppressions', []) + sites,
    pending_tasks_and_first_outcome_deadline_unchanged=True)
(base / 'preparation.json').write_text(json.dumps(preparation, indent=2) + '\n')
Path(__file__).chmod(0o444)
print(json.dumps(dict(boundary=str(base), source_files=prior['source_files'], corrected_source_files=len(seen),
    owned_source=len(owned), actual_projects=len(projects), targeted_rows=prior['new_distinct_test_rows_expected'],
    full_rows=prior['full_tests_expected'], compiled=False, tests_executed=False)))
