from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser()
parser.add_argument('boundary')
parser.add_argument('--phase', choices=('all', 'build', 'tests'), default='all')
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[2]
base = workspace / '.supervisor-evidence' / args.boundary
read = lambda path: json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


preparation = read(base / 'preparation.json')
root = Path(preparation['root'])
inputs = preparation['build_inputs']
assert len(inputs) == preparation['source_files']
assert all(digest(Path(row['path'])) == row['sha256'] for row in inputs)
assert digest(Path(preparation['baseline_manifest'])) == preparation['baseline_manifest_sha256']
env = dict(os.environ, DOTNET_ROOT='/home/codex/.dotnet', MSBUILDDISABLENODEREUSE='1',
    DOTNET_CLI_TELEMETRY_OPTOUT='1', DOTNET_NOLOGO='1')
env['PATH'] = '/home/codex/.dotnet:' + env['PATH']
profiler = workspace / '.supervisor-stage/numeric-worker/frozen-bounded-worker-component/evidence-snapshot/evidence/profiler-source/libwarpclr-jit-block-profiler.so'
assert digest(profiler) == 'a251e701021f44cdebe34b2be73063a66f61ad46c1d4034ed8e800dcced4e260'
assert not profiler.stat().st_mode & 0o222
env['WARP_JIT_TEST_PROFILER'] = str(profiler)
output = base / 'owned-build-output'
common = ['--nologo', '--disable-build-servers', '-m:1', '-nr:false', '-p:UseSharedCompilation=false',
    '-p:UseArtifactsOutput=true', '-p:ArtifactsPath=' + str(output)]
packages = Path(preparation['package_cache'])
assert digest(Path(preparation['validation_driver'])) == preparation['validation_driver_sha256']
assert packages.is_dir()
solution = 'WarpCLR.slnx'
commands_path = base / 'commands.json'
if args.phase == 'tests':
    commands = read(commands_path)
    assert [row['label'] for row in commands] == ['restore-assets', 'clean', 'restore', 'release-build']
    assert all(row['state'] == 'complete' and row['exit_code'] == row['diagnostic_occurrences'] == 0 for row in commands)
    assert all(digest(base / (row['label'] + '.log')) == row['log_sha256'] for row in commands)
else:
    assert not commands_path.exists(), 'Preserve a failure and prepare a new boundary before correction.'
    commands = []
for variable, name in [('WARP_CLEANUP_EVIDENCE', 'cleanup-witnesses'), ('WARP_COMPILED_HOST_EVIDENCE', 'source-host-witnesses')]:
    directory = base / name
    if args.phase != 'tests':
        directory.mkdir()
    assert directory.is_dir()
    env[variable] = str(directory)
env['WARP_PACKAGE_TEST_RETAIN_FAILURES'] = '1'
env['WARP_SOURCE_EVENTS_REFS'] = str(output / 'bin')
env['WARP_SOURCE_END_WITNESSES'] = str(base / 'source-end-witnesses')
if args.phase != 'tests':
    (base / 'source-end-witnesses').mkdir()
ns = {'t': 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}


def run(label, arguments):
    command = ['/home/codex/.dotnet/dotnet', *arguments, *common]
    log = base / (label + '.log')
    assert not log.exists()
    started = time.monotonic()
    print('starting', args.boundary, label, flush=True)
    with log.open('x') as capture:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=capture, stderr=subprocess.STDOUT, start_new_session=True)
        row = dict(label=label, command=command, cwd=str(root), pid=process.pid, pgid=process.pid,
            state='running', timeout_seconds=2400)
        commands.append(row)
        commands_path.write_text(json.dumps(commands, indent=2) + '\n')
        try:
            code = process.wait(timeout=2400)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 124
    diagnostics = re.findall(r'\b(?:warning|error) [A-Za-z]+[0-9]+\b|AD0001', log.read_text(errors='replace'))
    row.update(exit_code=code, state='complete', seconds=time.monotonic() - started,
        diagnostic_occurrences=len(diagnostics), log_sha256=digest(log))
    commands_path.write_text(json.dumps(commands, indent=2) + '\n')
    (base / (label + '-command.json')).write_text(json.dumps(row, indent=2) + '\n')
    assert all(digest(Path(item['path'])) == item['sha256'] for item in inputs), 'Build inputs changed during the boundary.'
    print(json.dumps({key: row[key] for key in ('label', 'exit_code', 'seconds', 'diagnostic_occurrences')}), flush=True)
    if code or diagnostics:
        raise SystemExit(code or 1)


if args.phase != 'tests':
    restore = ['restore', solution, '--force', '--no-cache', '--packages', str(packages)]
    for label, arguments in [('restore-assets', restore), ('clean', ['clean', solution, '-c', 'Release']),
        ('restore', restore), ('release-build', ['build', solution, '-c', 'Release', '--no-restore', '--no-incremental'])]:
        run(label, arguments)
if args.phase == 'build':
    print('Actual fresh build gates passed; targeted and full tests have not run.', flush=True)
    raise SystemExit(0)
run('checkpoint-tests', ['test', solution, '-c', 'Release', '--no-build', '--no-restore', '--filter', preparation['targeted_filter'],
    '--logger', 'trx', '--results-directory', str(base / 'checkpoint-tests')])
targeted = list((base / 'checkpoint-tests').glob('*.trx'))
assert len(targeted) == 1
counts = dict(ET.parse(targeted[0]).find('.//t:ResultSummary/t:Counters', ns).attrib)
assert int(counts['total']) == int(counts['passed']) == preparation['new_distinct_test_rows_expected']
assert int(counts['failed']) == int(counts['notExecuted']) == 0
run('full-tests', ['test', solution, '-c', 'Release', '--no-build', '--no-restore', '--logger', 'trx',
    '--results-directory', str(base / 'tests')])
full = list((base / 'tests').glob('*.trx'))
assert len(full) == 1
counts = dict(ET.parse(full[0]).find('.//t:ResultSummary/t:Counters', ns).attrib)
assert int(counts['total']) == int(counts['passed']) == preparation['full_tests_expected']
assert int(counts['failed']) == int(counts['notExecuted']) == 0
execution = []
for project in preparation['actual_project_names']:
    directory = output / 'bin' / project / 'release'
    assert (directory / (project + '.dll')).is_file()
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            execution.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)})
(base / 'execution-artifacts.json').write_text(json.dumps(execution, indent=2) + '\n')
receipt = dict(freshly_compiled_actual_production_assemblies=preparation['actual_project_names'], source_files=preparation['source_files'],
    tests=counts, trx=str(full[0]), trx_sha256=digest(full[0]), targeted_tests=preparation['new_distinct_test_rows_expected'],
    cleanup_quota_seconds_unchanged=2, actual_authenticated_envelope_round_trips=True, actual_prewarmed_child_roles=5,
    private_source_grant_issuer_or_positive_private_worker_rpc=False, gpu_execution=False,
    full_production_readiness=False, review_handoff=False)
(base / 'validation-summary.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
