from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys
import time


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def identity(pid):
    fields = Path('/proc', str(pid), 'stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=pid, pgid=int(fields[2]), start_ticks=int(fields[19]))


parser = argparse.ArgumentParser()
parser.add_argument('boundary', nargs='?')
parser.add_argument('--phase', choices=('all', 'build', 'tests'))
parser.add_argument('--run-plan')
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[2]
if args.run_plan:
    assert args.boundary is None and args.phase is None
    plan_path = Path(args.run_plan).resolve()
    plan = json.loads(plan_path.read_text())
    assert digest(Path(__file__)) == plan['supervisor_tool_sha256']
    assert digest(Path(plan['driver'])) == plan['driver_sha256']
    assert digest(Path(plan['preparation'])) == plan['preparation_sha256']
    started = time.monotonic()
    log = Path(plan['driver_output_log'])
    assert not log.exists()
    with log.open('x') as capture:
        process = subprocess.Popen(plan['driver_command'], cwd=workspace,
            stdin=subprocess.DEVNULL, stdout=capture, stderr=subprocess.STDOUT)
        active = dict(plan_sha256=digest(plan_path), driver_identity=identity(process.pid),
            supervisor_identity=identity(os.getpid()), started_unix_seconds=time.time(),
            started_monotonic_seconds=started, actual_driver_exit_code=None)
        active_path = plan_path.with_name(plan['phase'] + '-persistent-active.json')
        assert not active_path.exists()
        active_path.write_text(json.dumps(active, indent=2) + '\n')
        # Every dotnet command still has the unchanged 2400-second limit in the
        # immutable driver. This cap only bounds the supervisor's whole lifetime.
        code = process.wait(timeout=plan['whole_phase_cap_seconds'])
    completion = dict(active, actual_driver_exit_code=code,
        completed_unix_seconds=time.time(), elapsed_seconds=time.monotonic() - started,
        driver_output_log_sha256=digest(log), production_timeout_changed=False,
        full_production_readiness=False, review_handoff=False)
    completion_path = plan_path.with_name(plan['phase'] + '-persistent-completion.json')
    assert not completion_path.exists()
    completion_path.write_text(json.dumps(completion, indent=2) + '\n')
    print(json.dumps(completion), flush=True)
    raise SystemExit(code)

assert args.boundary is not None and args.phase is not None
base = workspace / '.supervisor-evidence' / args.boundary
preparation_path = base / 'preparation.json'
preparation = json.loads(preparation_path.read_text())
driver = Path(preparation['validation_driver'])
assert digest(driver) == preparation['validation_driver_sha256']
assert not driver.stat().st_mode & 0o222
plan_path = base / (args.phase + '-persistent-plan.json')
assert not plan_path.exists()
plan = dict(boundary=args.boundary, phase=args.phase, driver=str(driver),
    driver_sha256=digest(driver), preparation=str(preparation_path),
    preparation_sha256=digest(preparation_path),
    supervisor_tool=str(Path(__file__).resolve()), supervisor_tool_sha256=digest(Path(__file__)),
    driver_command=[sys.executable, '-B', str(driver), args.boundary, '--phase', args.phase],
    driver_output_log=str(base / (args.phase + '-persistent-driver.log')),
    whole_phase_cap_seconds={'build': 9630, 'tests': 4830, 'all': 14430}[args.phase],
    dotnet_per_command_timeout_seconds=2400, production_cleanup_timeout_seconds=2,
    new_source_or_artifact_copies=0, full_production_readiness=False)
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
wrapper_log = base / (args.phase + '-persistent-supervisor.log')
assert not wrapper_log.exists()
with wrapper_log.open('x') as capture:
    supervisor = subprocess.Popen([sys.executable, '-B', str(Path(__file__).resolve()),
        '--run-plan', str(plan_path)], cwd=workspace, stdin=subprocess.DEVNULL,
        stdout=capture, stderr=subprocess.STDOUT, start_new_session=True)
launch = dict(plan=str(plan_path), plan_sha256=digest(plan_path),
    supervisor_identity=identity(supervisor.pid), wrapper_log=str(wrapper_log),
    launched_unix_seconds=time.time(), actual_validation_completed=False)
launch_path = base / (args.phase + '-persistent-launch.json')
assert not launch_path.exists()
launch_path.write_text(json.dumps(launch, indent=2) + '\n')
print(json.dumps(launch), flush=True)
