from pathlib import Path
import argparse
import hashlib
import json

parser = argparse.ArgumentParser()
parser.add_argument('retained_failure_sha256')
args = parser.parse_args()
workspace = Path(__file__).resolve().parents[2]
base = workspace / '.supervisor-evidence/root-cumulative-private-guards-1082-gate9-abi08'
retained = base / 'retained-complete-targeted-runtime-failure-1.json'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(retained) == args.retained_failure_sha256
failure = json.loads(retained.read_text())
assert failure['correction_not_yet_applied'] and failure['owned_live_producers'] == []
assert any(row['label'] == 'checkpoint-tests' and row['exit_code'] != 0 for row in failure['commands'])
source = {row['logical_path']: row for row in json.loads((base / 'preparation.json').read_text())['build_inputs']}
stage = workspace / '.supervisor-stage/root-cumulative1082-runtime-fixture-corrections-v1'
evidence = workspace / '.supervisor-evidence/root-cumulative1082-runtime-fixture-corrections-v1'
assert not stage.exists() and not evidence.exists()
changed = {}

def load(logical):
    if logical not in changed:
        row = source[logical]
        path = Path(row['path'])
        assert digest(path) == row['sha256'] and not path.stat().st_mode & 0o222
        changed[logical] = path.read_text()
    return changed[logical]

def replace(logical, before, after, count=1):
    text = load(logical)
    assert text.count(before) == count, (logical, before, text.count(before), count)
    changed[logical] = text.replace(before, after)

fixture = 'WarpCLR.Tests/WarpPrivateHelperReturnFenceFixture.cs'
replace(fixture, 'new WarpTupleReturnTerminator([11, 12, 13, 14]);', 'new WarpTupleReturnTerminator([6, 7, 8, 9]);')
replace(fixture, '''new(1, [], [new(8, WarpPrivateControllerOpCode.LoadController),
                new(9, WarpIrOpCode.Constant, immediate: 0x7FC12345), new(10, WarpIrOpCode.Constant, immediate: 0x80000000),
                new(11, 1, [8, 9, 10], 4), new(15, WarpManagedFrameOpCode.StorePrivateWord, 11, immediate: 0),
                new(16, WarpManagedFrameOpCode.StorePrivateWord, 12, immediate: 1)], end),
                new(2, [], [new(17, 3, [], 1), new(18, WarpManagedFrameOpCode.LoadPrivateWord, immediate: 0),
                    new(19, WarpManagedFrameOpCode.LoadPrivateWord, immediate: 1), new(20, WarpIrOpCode.Constant, immediate: 0x80000000),
                    new(21, WarpIrOpCode.Constant, immediate: uint.MaxValue)], new WarpTupleReturnTerminator([18, 19, 20, 21]))]),''',
'''new(1, [], [new(3, WarpPrivateControllerOpCode.LoadController),
                new(4, WarpIrOpCode.Constant, immediate: 0x7FC12345), new(5, WarpIrOpCode.Constant, immediate: 0x80000000),
                new(6, 1, [3, 4, 5], 4), new(10, WarpManagedFrameOpCode.StorePrivateWord, 6, immediate: 0),
                new(11, WarpManagedFrameOpCode.StorePrivateWord, 7, immediate: 1)], end),
                new(2, [], [new(12, 3, [], 1), new(13, WarpManagedFrameOpCode.LoadPrivateWord, immediate: 0),
                    new(14, WarpManagedFrameOpCode.LoadPrivateWord, immediate: 1), new(15, WarpIrOpCode.Constant, immediate: 0x80000000),
                    new(16, WarpIrOpCode.Constant, immediate: uint.MaxValue)], new WarpTupleReturnTerminator([13, 14, 15, 16]))]),''')
replace(fixture, 'new([new(1, 1, 8, 1, 0, 11, Service)]', 'new([new(1, 1, 3, 1, 0, 6, Service)]')
tuple_test = 'WarpCLR.Tests/WarpPrivateHelperReturnTupleTests.cs'
replace(tuple_test, 'int after = 1 + Math.Max(1, words);', 'int after = 1 + words;')

void_test = 'WarpCLR.Tests/WarpCapturedVoidPrivateHelperTests.cs'
replace(void_test, '        Assert.ThrowsExactly<ArgumentException>(() => new WarpControlFlowKernel("void-marker/nonzero-denial", 0, 1, blocks, null, functions, metadata));',
'''        ArgumentOutOfRangeException failure = Assert.ThrowsExactly<ArgumentOutOfRangeException>(() =>
            new WarpControlFlowKernel("void-marker/nonzero-denial", 0, 1, blocks, null, functions, metadata));
        Assert.AreEqual("value", failure.ParamName, StringComparer.Ordinal);''')

observation = 'WarpCLR.Tests/WarpCoreCLRWorkerTests.ZCallUseObservation.cs'
changed[observation] = 'using WarpCLR.Compiler;\n' + load(observation)
replace(observation, '''    private static WarpLogicalMachineLayout ObservationLayout() => new(new WarpIntegerMapVerifier().Verify(
        new WarpIntegerMapRequest(typeof(TestKernels).GetMethod(nameof(TestKernels.Call))!, 1)).ControlFlow);''',
'''    private static WarpLogicalMachineLayout ObservationLayout()
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(typeof(TestKernels).GetMethod(nameof(TestKernels.Call))!);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
        WarpPortableWordLoweredProgram program = WarpPortableWordLowerer.Lower(graph, typed, schema,
            new ObservationOwnerBinding(graph, typed, schema));
        WarpPortableWordProgramIdentity.Validate(graph, schema, program);
        var layout = new WarpLogicalMachineLayout(program.Kernel);
        Assert.IsTrue(layout.HasFrameOwners);
        Assert.IsNull(layout.Kernel.Execution!.PrivateControllerProjection);
        return layout;
    }

    // Only the actual compiler-created frame-owner profile is enabled. This
    // binds no private controller, service replacement or source permission.
    private sealed class ObservationOwnerBinding : WarpPortableWordExecutionBinding
    {
        internal ObservationOwnerBinding(WarpPortableMethodGraph graph, WarpPortableTypedProgram typed,
            WarpPortableSourceHeapSchema schema) : base(graph.GraphHash, typed.VerifiedHash, schema.SchemaHash,
                "warp.proof.call-use-observation/exact-source-frame-owners/0.1", graph.GraphHash,
                new(FrameOwners: true)) { }
        internal override WarpBlockTerminator? LowerInstruction(WarpPortableWordInstructionContext context) => null;
        internal override string Complete(WarpPortableWordBindingCompletion context) => WarpIrHash.Compute(context.StructuralKernel);
    }''')

stage.mkdir()
evidence.mkdir()
owned = []
for logical, content in sorted(changed.items()):
    before = Path(source[logical]['path'])
    assert content.count('[TestMethod]') == before.read_text().count('[TestMethod]')
    assert content.count('[DataRow(') == before.read_text().count('[DataRow(')
    target = stage / logical
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)
    target.chmod(0o444)
    owned.append(dict(path=logical, absolute_path=str(target), sha256=digest(target), bytes=target.stat().st_size,
        failed_boundary_preimage=str(before), failed_boundary_preimage_sha256=digest(before)))
manifest = evidence / 'prepared-source-application-manifest.json'
manifest.write_text(json.dumps(dict(owned_source=owned, retained_failed_boundary=str(retained),
    retained_failed_boundary_sha256=digest(retained), preparation_tool=str(Path(__file__).resolve()),
    preparation_tool_sha256=digest(Path(__file__)), necessary_suppressions=[],
    fixture_ssa_alpha_renaming={str(value): value - 5 for value in range(8, 22)},
    void_call_defines_zero_ssa_values=True, malformed_nonzero_sentinel_exact_parameter='value',
    observation_uses_genuine_typed_compiler_frame_owner_binding=True, nonzero_activation_assertion_preserved=True,
    source_kernel_cil_and_product_implementation_unchanged=True, source_charges_and_mathematical_bits_unchanged=True,
    original_test_names_and_expanded_rows_unchanged=True, source_or_artifact_copies=0,
    compiled=False, tests_executed=0, readiness=False), indent=2) + '\n')
manifest.chmod(0o444)
Path(__file__).chmod(0o444)
print(json.dumps(dict(manifest=str(manifest), sha256=digest(manifest), corrected_files=len(owned))))
