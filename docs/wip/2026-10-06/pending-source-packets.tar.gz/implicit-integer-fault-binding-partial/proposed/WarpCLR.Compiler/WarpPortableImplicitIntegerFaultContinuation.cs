using WarpCLR.IR;

namespace WarpCLR.Compiler;

// A compiler emission interface, NOT a runtime capability. This packet supplies
// no concrete implementation. Root must provide its genuinely prepared source
// binding and separately authenticate actual runtime operations/checkpoints.
internal abstract class WarpPortableImplicitIntegerFaultContinuation
{
    internal const string Semantics = "warp.source-implicit-integer/root-supplied-compiler-fault-continuation-exact-pool-ticket-take-raise-root-ack-no-default-emitter/0.1";

    // Validate immutable compiler recipe availability without emitting any IR.
    // Final function/PC/root/alias hashes are sealed by the actual lowerer later;
    // the Root runtime independently binds them before any private command.
    internal abstract void RequireEmissionPrepared(WarpPortableImplicitIntegerArithmeticPlan plan,
        WarpPortableImplicitIntegerArithmeticSite site);

    // Both callbacks run only during compilation inside a zero-charge block.
    // The fault callback must emit the existing fixed Take/RaiseTaken/Ack and EH
    // protocol via fresh pure helper bridges, never manufacture Granted or use
    // an arithmetic selector as machine FaultKind or an exception reference.
    internal abstract WarpBlockTerminator EmitPreparedFault(WarpPortableWordInstructionContext context,
        WarpPortableImplicitIntegerArithmeticPlan plan, WarpPortableImplicitIntegerArithmeticSite site,
        WarpPortableSourceFaultFactoryRow exactRow);

    // Unknown selectors are consistency/containment failures, never invented
    // source exceptions or successful zero results. Root owns that stopped path.
    internal abstract WarpBlockTerminator EmitRejectedSelector(WarpPortableWordInstructionContext context,
        WarpPortableImplicitIntegerArithmeticPlan plan, WarpPortableImplicitIntegerArithmeticSite site);
}
