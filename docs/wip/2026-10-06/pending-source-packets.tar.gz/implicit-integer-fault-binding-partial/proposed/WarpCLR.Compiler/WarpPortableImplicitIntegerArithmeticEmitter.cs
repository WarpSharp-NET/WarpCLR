using WarpCLR.IR;

namespace WarpCLR.Compiler;

// Additive compiler hook only. No concrete WordExecutionBinding installs it;
// ordinary Lower still reaches Numeric.cs's unchanged implicit-fault denial.
internal static class WarpPortableImplicitIntegerArithmeticEmitter
{
    internal const string Semantics = "warp.source-implicit-integer/owned-instruction-selector-first-whole-tuple-success-zero-charge-reload-block-local-operands-root-fault-emitter-required/0.1";

    internal static WarpBlockTerminator Emit(WarpPortableImplicitIntegerArithmeticPlan plan,
        WarpPortableImplicitIntegerArithmeticSite site, WarpPortableWordInstructionContext context,
        WarpPortableImplicitIntegerFaultContinuation? faults)
    {
        ArgumentNullException.ThrowIfNull(plan); plan.RequireOwnedSite(site);
        if (faults is null) { throw WarpPortableImplicitIntegerArithmeticPlan.Invalid("The actual Root implicit-fault continuation is unavailable; source division stays denied.", site.SourceOffset); }
        plan.RequireContext(site, context);
        if (!context.PrivateHelperBoundaries)
        { throw WarpPortableImplicitIntegerArithmeticPlan.Invalid("Implicit source fault emission requires its separately admitted private helper profile.", site.SourceOffset); }
        faults.RequireEmissionPrepared(plan, site);
        context.RequireService(Semantics + "/" + plan.PlanHash);
        context.RequireService(WarpPortableImplicitIntegerFaultContinuation.Semantics);
        int success = context.ReserveGeneratedBlock();
        int nonzero = context.ReserveGeneratedBlock();
        int divide = context.ReserveGeneratedBlock();
        int rejected = context.ReserveGeneratedBlock();
        int overflow = site.Signed ? context.ReserveGeneratedBlock() : rejected;
        context.EmitGeneratedBlock(success, stage => Success(stage, site));
        context.EmitGeneratedBlock(divide, stage => Fault(stage, plan, site, site.DivideByZeroRow, faults));
        if (site.OverflowRow is { } row) { context.EmitGeneratedBlock(overflow, stage => Fault(stage, plan, site, row, faults)); }
        context.EmitGeneratedBlock(rejected, stage => faults.EmitRejectedSelector(stage, plan, site));
        context.EmitGeneratedBlock(nonzero, stage => Nonzero(stage, site, divide, overflow, rejected));
        int selector = Selector(context, site);
        int zero = context.Emit(WarpIrOpCode.Equal, selector, context.Constant(0));
        return new WarpConditionalBranchTerminator(zero, new(success, []), new(nonzero, []));
    }

    private static WarpBlockTerminator Success(WarpPortableWordInstructionContext context, WarpPortableImplicitIntegerArithmeticSite site)
    {
        // Each generated block reloads original stack words. No caller block
        // SSA or uint selector is carried across the branch or a guest boundary.
        int[] operands = Operands(context);
        int[] result = site.ArithmeticServices.Select(service =>
            context.Call(context.Services.Import(service, site.ArithmeticSemantics, WarpPortableGeneratedServiceKind.Words).Function, operands)[0]).ToArray();
        int destination = context.StackWordOffset(context.Instruction.EntryStack.Length - 2);
        // Both wide words have returned before either original stack word is
        // stored. Root's operation lease forbids observation mid-transaction.
        for (int word = 0; word < result.Length; word++) { context.StorePrivateWord(destination + word, result[word]); }
        return context.Next();
    }

    private static WarpBlockTerminator Nonzero(WarpPortableWordInstructionContext context, WarpPortableImplicitIntegerArithmeticSite site,
        int divide, int overflow, int rejected)
    {
        int next = rejected;
        if (site.Signed)
        {
            next = context.ReserveGeneratedBlock();
            context.EmitGeneratedBlock(next, stage =>
            {
                int exact = stage.Emit(WarpIrOpCode.Equal, Selector(stage, site), stage.Constant(2));
                return new WarpConditionalBranchTerminator(exact, new(overflow, []), new(rejected, []));
            });
        }
        int match = context.Emit(WarpIrOpCode.Equal, Selector(context, site), context.Constant(1));
        return new WarpConditionalBranchTerminator(match, new(divide, []), new(next, []));
    }

    private static WarpBlockTerminator Fault(WarpPortableWordInstructionContext context, WarpPortableImplicitIntegerArithmeticPlan plan,
        WarpPortableImplicitIntegerArithmeticSite site, WarpPortableSourceFaultFactoryRow row, WarpPortableImplicitIntegerFaultContinuation faults)
    {
        plan.RequireFaultRow(site, row);
        return faults.EmitPreparedFault(context, plan, site, row);
    }

    private static int Selector(WarpPortableWordInstructionContext context, WarpPortableImplicitIntegerArithmeticSite site) =>
        context.Call(context.Services.Import(site.SelectorService, site.ArithmeticSemantics, WarpPortableGeneratedServiceKind.Words).Function, Operands(context))[0];

    private static int[] Operands(WarpPortableWordInstructionContext context)
    {
        int left = context.Instruction.EntryStack.Length - 2;
        return [.. context.LoadStackValue(left), .. context.LoadStackValue(left + 1)];
    }
}
