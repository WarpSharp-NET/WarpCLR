using System.Collections.Immutable;
using WarpCLR.Verifier;

namespace WarpCLR.Compiler;

// A compiler consistency plan. Capture never issues a runtime operation,
// private invocation, controller grant, exception reference or source permit.
internal sealed partial class WarpPortableImplicitIntegerArithmeticPlan
{
    internal const string Semantics = "warp.source-implicit-integer/closed-cil-div-rem-i4-i8-selector-zero-words-one-two-descriptor-zero-factory-row-no-runtime-issuance/0.1";
    private readonly WarpPortableMethodGraph graph;
    private readonly WarpPortableTypedProgram program;
    private readonly WarpPortableSourceHeapSchema schema;
    private readonly WarpPortableSourceFaultFactoryContract factory;

    private WarpPortableImplicitIntegerArithmeticPlan(WarpPortableMethodGraph graph, WarpPortableTypedProgram program,
        WarpPortableSourceHeapSchema schema, WarpPortableSourceFaultFactoryContract factory,
        ImmutableArray<WarpPortableImplicitIntegerArithmeticSite> sites)
    {
        this.graph = graph; this.program = program; this.schema = schema; this.factory = factory; Sites = sites;
        PlanHash = WarpPortableSnapshotIdentity.Hash(new
        {
            Semantics, graph.GraphHash, program.VerifiedHash, schema.SchemaHash, factory.ContractHash,
            Sites = sites.Select(site => site.Snapshot()),
            Emit = WarpPortableImplicitIntegerArithmeticEmitter.Semantics,
            RequiredRootEmission = WarpPortableImplicitIntegerFaultContinuation.Semantics,
            Authority = "none;actual-Root-private-checkpoint-operation-ticket-controller-and-root-publication-required",
        });
    }

    internal ImmutableArray<WarpPortableImplicitIntegerArithmeticSite> Sites { get; }
    internal string PlanHash { get; }
    internal string GraphHash => graph.GraphHash;
    internal string VerifiedHash => program.VerifiedHash;
    internal string SchemaHash => schema.SchemaHash;
    internal string FactoryHash => factory.ContractHash;

    internal WarpPortableImplicitIntegerArithmeticSite RequireSite(string methodIdentity, int sourceOffset) =>
        Sites.SingleOrDefault(site => string.Equals(site.MethodIdentity, methodIdentity, StringComparison.Ordinal) && site.SourceOffset == sourceOffset)
        ?? throw Invalid("The exact original arithmetic instruction is outside this compiler plan.", sourceOffset);

    internal void RequireOwnedSite(WarpPortableImplicitIntegerArithmeticSite site)
    {
        ArgumentNullException.ThrowIfNull(site);
        if (!Sites.Any(owned => ReferenceEquals(owned, site)))
        { throw Invalid("A structurally equal site from another capture is not this compiler-owned consistency object.", site.SourceOffset); }
    }

    internal WarpPortableSourceFaultFactoryRow? SelectFault(WarpPortableImplicitIntegerArithmeticSite site, uint selector)
    {
        RequireOwnedSite(site);
        return selector switch
        {
            0 => null,
            1 => site.DivideByZeroRow,
            2 when site.OverflowRow is not null => site.OverflowRow,
            _ => throw Invalid("The uint selector is outside the exact opcode-specific implicit fault map.", site.SourceOffset),
        };
    }

    internal void RequireFaultRow(WarpPortableImplicitIntegerArithmeticSite site, WarpPortableSourceFaultFactoryRow row)
    {
        RequireOwnedSite(site); ArgumentNullException.ThrowIfNull(row);
        if (row.FaultDescriptor != 0 || !ReferenceEquals(row, site.DivideByZeroRow) && !ReferenceEquals(row, site.OverflowRow))
        { throw Invalid("An implicit source fault requires its exact owned descriptor-zero factory row.", site.SourceOffset); }
    }

    internal void RequireContext(WarpPortableImplicitIntegerArithmeticSite site, WarpPortableWordInstructionContext context)
    {
        RequireOwnedSite(site); ArgumentNullException.ThrowIfNull(context);
        if (!ReferenceEquals(context.Graph, graph) || !ReferenceEquals(context.Program, program) ||
            !ReferenceEquals(context.SourceMethod, site.SourceMethod) || !ReferenceEquals(context.SourceInstruction, site.SourceInstruction) ||
            !ReferenceEquals(context.Instruction, site.Instruction))
        { throw Invalid("Arithmetic emission needs the actual compiler context for the exact captured typed instruction.", site.SourceOffset); }
    }

    internal static WarpVerificationException Invalid(string message, int offset) => new("WRPCLR2300", message, offset);
}
