using WarpCLR.Verifier;

namespace WarpCLR.Compiler;

internal sealed partial class WarpPortableImplicitIntegerArithmeticSite
{
    internal WarpPortableImplicitIntegerArithmeticSite(WarpPortableMethodGraphMethod source, WarpPortableMethodGraphInstruction captured,
        WarpPortableTypedInstruction instruction, int capturedMethodIndex, int resultWords, bool signed, bool remainder,
        WarpPortableSourceFaultFactoryRow divideByZero, WarpPortableSourceFaultFactoryRow? overflow)
    {
        SourceMethod = source; SourceInstruction = captured; Instruction = instruction; CapturedMethodIndex = capturedMethodIndex;
        ResultWords = resultWords; Signed = signed; Remainder = remainder; DivideByZeroRow = divideByZero; OverflowRow = overflow;
        SelectorService = Service((remainder ? "Remainder" : "Divide") + (signed ? "Signed" : "Unsigned") + "Fault");
        string result = (remainder ? "Remainder" : "Divide") + (signed ? "Signed" : "Unsigned");
        ArithmeticServices = resultWords == 1 ? [Service(result)] : [Service(result + "Low"), Service(result + "High")];
        SiteHash = WarpPortableSnapshotIdentity.Hash(Snapshot());
    }

    internal WarpPortableMethodGraphMethod SourceMethod { get; }
    internal WarpPortableMethodGraphInstruction SourceInstruction { get; }
    internal WarpPortableTypedInstruction Instruction { get; }
    internal string MethodIdentity => SourceMethod.Identity;
    internal int SourceOffset => Instruction.Offset;
    internal short SourceOpCode => Instruction.OpCode;
    // This is the one-based typed metadata index, NEVER a physical function or PC.
    internal int CapturedMethodIndex { get; }
    internal int ResultWords { get; }
    internal bool Signed { get; }
    internal bool Remainder { get; }
    internal int SourceCharge => 1;
    internal int GeneratedCharge => 0;
    internal string SiteHash { get; }
    internal WarpPortableSourceFaultFactoryRow DivideByZeroRow { get; }
    internal WarpPortableSourceFaultFactoryRow? OverflowRow { get; }

    internal object Snapshot() => new
    {
        MethodIdentity, CapturedMethodIndex, Instruction, ResultWords, Signed, Remainder, SourceCharge, GeneratedCharge,
        DivideByZeroRow, OverflowRow, ArithmeticSemantics,
        Selector = WarpPortableMethodGraphIdentity.Method(SelectorService),
        Results = ArithmeticServices.Select(WarpPortableMethodGraphIdentity.Method),
        Transport = "raw-UInt32;I8-low-high;no-native-floating-or-original-source-invocation",
    };
}
