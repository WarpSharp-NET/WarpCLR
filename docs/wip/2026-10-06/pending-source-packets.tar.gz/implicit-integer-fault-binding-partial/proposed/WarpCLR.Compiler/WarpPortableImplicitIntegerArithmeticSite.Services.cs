using System.Collections.Immutable;
using System.Reflection;

namespace WarpCLR.Compiler;

internal sealed partial class WarpPortableImplicitIntegerArithmeticSite
{
    internal MethodInfo SelectorService { get; }
    internal ImmutableArray<MethodInfo> ArithmeticServices { get; }
    internal string ArithmeticSemantics => ResultWords == 1 ? WarpPortableCilIntegerDivision32.Semantics : WarpPortableCilIntegerDivision64.Semantics;

    private MethodInfo Service(string name)
    {
        Type implementation = ResultWords == 1 ? typeof(WarpPortableCilIntegerDivision32) : typeof(WarpPortableCilIntegerDivision64);
        Type[] arguments = Enumerable.Repeat(typeof(uint), ResultWords * 2).ToArray();
        MethodInfo method = implementation.GetMethod(name, BindingFlags.Public | BindingFlags.Static, null, arguments, null)
            ?? throw WarpPortableImplicitIntegerArithmeticPlan.Invalid("The exact word service signature is absent.", SourceOffset);
        if (method.DeclaringType != implementation || method.Module != typeof(WarpPortableImplicitIntegerArithmeticSite).Module ||
            !method.IsStatic || method.ContainsGenericParameters || method.ReturnType != typeof(uint) ||
            !method.GetParameters().Select(parameter => parameter.ParameterType).SequenceEqual(arguments))
        { throw WarpPortableImplicitIntegerArithmeticPlan.Invalid("Only the closed compiler-module UInt32 service may implement this instruction.", SourceOffset); }
        return method;
    }
}
