using System.Collections.Immutable;
using System.Reflection.Emit;
using WarpCLR.Verifier;

namespace WarpCLR.Compiler;

internal sealed partial class WarpPortableImplicitIntegerArithmeticPlan
{
    internal static WarpPortableImplicitIntegerArithmeticPlan Capture(WarpPortableMethodGraph graph,
        WarpPortableTypedProgram program, WarpPortableSourceHeapSchema schema, WarpPortableSourceFaultFactoryContract factory)
    {
        ArgumentNullException.ThrowIfNull(graph); ArgumentNullException.ThrowIfNull(program);
        ArgumentNullException.ThrowIfNull(schema); ArgumentNullException.ThrowIfNull(factory);
        RequireInputs(graph, program, schema, factory);
        var sites = ImmutableArray.CreateBuilder<WarpPortableImplicitIntegerArithmeticSite>();
        for (int methodIndex = 0; methodIndex < program.Methods.Length; methodIndex++)
        {
            WarpPortableTypedMethod method = program.Methods[methodIndex];
            WarpPortableMethodGraphMethod source = graph.Methods.Single(candidate => string.Equals(candidate.Identity, method.Identity, StringComparison.Ordinal));
            foreach (WarpPortableTypedInstruction instruction in method.Instructions.Where(instruction => instruction.Reachable && IsOperation(instruction.OpCode)))
            {
                if (instruction.EntryStack.Length < 2) { throw Invalid("Integer div/rem needs its original two operands.", instruction.Offset); }
                WarpPortableStackCategory category = instruction.EntryStack[^2].Category;
                if (category is not (WarpPortableStackCategory.I4 or WarpPortableStackCategory.I8)) { continue; }
                sites.Add(CaptureSite(source, instruction, methodIndex + 1, schema, factory));
            }
        }
        return new(graph, program, schema, factory, sites.ToImmutable());
    }

    private static void RequireInputs(WarpPortableMethodGraph graph, WarpPortableTypedProgram program,
        WarpPortableSourceHeapSchema schema, WarpPortableSourceFaultFactoryContract factory)
    {
        if (graph.GraphHash != program.GraphHash || graph.GraphHash != schema.GraphHash || program.VerifiedHash != schema.VerifiedHash ||
            factory.GraphHash != graph.GraphHash || factory.VerifiedHash != program.VerifiedHash || factory.TypeSchemaHash != schema.SchemaHash)
        { throw Invalid("The arithmetic candidate requires the exact captured graph, typed program, schema and factory.", 0); }
        WarpPortableTypedProgram verified = WarpPortableTypedProgram.Verify(graph, program.CliSizes);
        if (verified.VerifiedHash != program.VerifiedHash ||
            WarpPortableSnapshotIdentity.Hash(new { verified.Types, verified.Methods }) != WarpPortableSnapshotIdentity.Hash(new { program.Types, program.Methods }) ||
            WarpPortableSourceHeapSchema.Create(graph, verified).SchemaHash != schema.SchemaHash ||
            WarpPortableSourceFaultFactoryContract.CaptureFinite(graph, verified, schema).ContractHash != factory.ContractHash)
        { throw Invalid("The arithmetic candidate must match fresh source verification and finite factory data.", 0); }
    }

    private static WarpPortableImplicitIntegerArithmeticSite CaptureSite(WarpPortableMethodGraphMethod source,
        WarpPortableTypedInstruction instruction, int capturedMethodIndex, WarpPortableSourceHeapSchema schema,
        WarpPortableSourceFaultFactoryContract factory)
    {
        WarpPortableMethodGraphInstruction captured = source.Instructions.Single(item => item.Offset == instruction.Offset);
        bool signed = instruction.OpCode == OpCodes.Div.Value || instruction.OpCode == OpCodes.Rem.Value;
        bool remainder = instruction.OpCode == OpCodes.Rem.Value || instruction.OpCode == OpCodes.Rem_Un.Value;
        int words = instruction.EntryStack[^2].Category == WarpPortableStackCategory.I8 ? 2 : 1;
        WarpPortableTypedEffect[] effects = signed ? [WarpPortableTypedEffect.DivideByZeroCheck, WarpPortableTypedEffect.OverflowCheck] : [WarpPortableTypedEffect.DivideByZeroCheck];
        int prefix = instruction.EntryStack.Length - 2;
        if (captured.OpCode.Value != instruction.OpCode || captured.NextOffset != instruction.NextOffset || instruction.EntryStack[^1].Category != instruction.EntryStack[^2].Category ||
            instruction.EntryStack[^1].WordCount != words || instruction.EntryStack[^2].WordCount != words ||
            instruction.ExitStack.Length != prefix + 1 || instruction.ExitStack[^1].WordCount != words ||
            instruction.ExitStack[^1].Category != instruction.EntryStack[^2].Category ||
            !instruction.EntryStack.Take(prefix).SequenceEqual(instruction.ExitStack.Take(prefix)) ||
            !instruction.Effects.SequenceEqual(effects) || instruction.Faults.Length != effects.Length || instruction.Successors.Length != 1)
        { throw Invalid("The div/rem candidate has altered opcode, widths, stack shape, effects or source continuation.", instruction.Offset); }
        WarpPortableSourceFaultFactoryRow divide = FaultRow(source.Identity, instruction, 0, WarpPortableTypedFaultKind.DivideByZero, schema, factory);
        WarpPortableSourceFaultFactoryRow? overflow = signed ? FaultRow(source.Identity, instruction, 1, WarpPortableTypedFaultKind.Overflow, schema, factory) : null;
        return new(source, captured, instruction, capturedMethodIndex, words, signed, remainder, divide, overflow);
    }

    private static WarpPortableSourceFaultFactoryRow FaultRow(string method, WarpPortableTypedInstruction instruction,
        int effect, WarpPortableTypedFaultKind kind, WarpPortableSourceHeapSchema schema, WarpPortableSourceFaultFactoryContract factory)
    {
        WarpPortableTypedFault typed = instruction.Faults[effect];
        WarpPortableSourceHeapFault fault = schema.Faults.Single(item => item.MethodIdentity == method && item.SourceOffset == instruction.Offset && item.EffectIndex == effect);
        WarpPortableSourceFaultFactoryRow row = factory.Rows.Single(item => item.MethodIdentity == method && item.SourceOffset == instruction.Offset && item.EffectIndex == effect);
        string operation = "warp.source-cil-implicit/" + unchecked((ushort)instruction.OpCode).ToString("X4", System.Globalization.CultureInfo.InvariantCulture);
        if (typed.Kind != kind || typed.SourceOffset != instruction.Offset || typed.EffectIndex != effect || fault.Kind != kind || fault.SourceOpCode != instruction.OpCode ||
            fault.UncatchableRuntimeTermination || fault.ExceptionType == 0 || row.Id == 0 || row.OpCode != instruction.OpCode ||
            row.Kind != kind || row.ExceptionType != fault.ExceptionType || row.FaultDescriptor != 0 || row.OperationIdentity != operation ||
            row.ParamName is not null || row.ResourceKey != (kind == WarpPortableTypedFaultKind.DivideByZero ? "Arg_DivideByZero" : "Arg_OverflowException"))
        { throw Invalid("The selector must name the genuine ordered descriptor-zero implicit fault/type/factory row.", instruction.Offset); }
        return row;
    }

    private static bool IsOperation(short opcode) => opcode == OpCodes.Div.Value || opcode == OpCodes.Div_Un.Value || opcode == OpCodes.Rem.Value || opcode == OpCodes.Rem_Un.Value;
}
