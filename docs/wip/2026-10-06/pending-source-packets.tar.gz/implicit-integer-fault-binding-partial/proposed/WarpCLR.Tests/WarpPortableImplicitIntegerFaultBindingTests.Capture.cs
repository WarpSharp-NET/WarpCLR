using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

[TestClass]
[DoNotParallelize]
[SuppressMessage("Performance", "CA1812:Avoid uninstantiated internal classes", Justification = "MSTest discovers this proposed fixture through reflection.")]
internal sealed partial class WarpPortableImplicitIntegerFaultBindingTests
{
    [TestMethod]
    [DataRow("Int32Divide")]
    [DataRow("Int32Remainder")]
    [DataRow("UInt32Divide")]
    [DataRow("UInt32Remainder")]
    [DataRow("Int64Divide")]
    [DataRow("Int64Remainder")]
    [DataRow("UInt64Divide")]
    [DataRow("UInt64Remainder")]
    public void CapturePreservesRealOpcodeWidthsEffectsAndDescriptorZeroRows(string name)
    {
        Inputs input = Capture(name);
        WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        Assert.IsTrue(input.Graph.Methods.Single(method => method.Identity == input.Graph.EntryIdentity).Instructions.Any(instruction => ReferenceEquals(instruction, site.SourceInstruction)));
        Assert.AreEqual(name.Contains("64", StringComparison.Ordinal) ? 2 : 1, site.ResultWords);
        Assert.AreEqual(!name.StartsWith("UInt", StringComparison.Ordinal), site.Signed);
        Assert.AreEqual(name.Contains("Remainder", StringComparison.Ordinal), site.Remainder);
        Assert.AreEqual(1, site.SourceCharge); Assert.AreEqual(0, site.GeneratedCharge);
        Assert.AreEqual(site.Signed ? 2 : 1, site.Instruction.Faults.Length);
        Assert.AreEqual(0u, site.DivideByZeroRow.FaultDescriptor);
        Assert.AreEqual(WarpPortableTypedFaultKind.DivideByZero, site.DivideByZeroRow.Kind);
        Assert.AreEqual(0, site.DivideByZeroRow.EffectIndex);
        Assert.IsNull(input.Plan.SelectFault(site, 0));
        Assert.AreSame(site.DivideByZeroRow, input.Plan.SelectFault(site, 1));
        if (site.Signed)
        {
            Assert.AreSame(site.OverflowRow, input.Plan.SelectFault(site, 2));
            Assert.AreEqual(WarpPortableTypedFaultKind.Overflow, site.OverflowRow!.Kind);
            Assert.AreEqual(1, site.OverflowRow.EffectIndex); Assert.AreEqual(0u, site.OverflowRow.FaultDescriptor);
        }
        else { Assert.IsNull(site.OverflowRow); }
        foreach (MethodInfo service in site.ArithmeticServices.Prepend(site.SelectorService))
        {
            Assert.AreEqual(typeof(WarpPortableImplicitIntegerArithmeticPlan).Module, service.Module);
            Assert.AreEqual(typeof(uint), service.ReturnType);
            CollectionAssert.AreEqual(Enumerable.Repeat(typeof(uint), site.ResultWords * 2).ToArray(), service.GetParameters().Select(parameter => parameter.ParameterType).ToArray());
        }
    }

    [TestMethod]
    [DataRow("Int32Divide")]
    [DataRow("Int64Remainder")]
    [DataRow("UInt32Remainder")]
    [DataRow("UInt64Divide")]
    public void ForeignEqualSitesAndAlteredOrEqualClonedRowsDoNotBind(string name)
    {
        Inputs input = Capture(name);
        WarpPortableImplicitIntegerArithmeticPlan other = WarpPortableImplicitIntegerArithmeticPlan.Capture(input.Graph, input.Typed, input.Schema, input.Factory);
        Assert.AreEqual(input.Plan.PlanHash, other.PlanHash, StringComparer.Ordinal);
        WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.SelectFault(other.Sites.Single(), 1));
        Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.RequireFaultRow(site, site.DivideByZeroRow with { }));
        Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.RequireFaultRow(site, site.DivideByZeroRow with { FaultDescriptor = 1 }));
        Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.RequireFaultRow(site, site.DivideByZeroRow with { EffectIndex = 1 }));
        Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.RequireFaultRow(site, site.DivideByZeroRow with { ExceptionType = 0 }));
        Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.RequireFaultRow(site, site.DivideByZeroRow with { OpCode = 0 }));
    }

    [TestMethod]
    [DataRow("Int32Divide")]
    [DataRow("UInt64Remainder")]
    public void SelectorNumbersAreNotFactoryDescriptorsOrMachineFaultKinds(string name)
    {
        Inputs input = Capture(name); WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        foreach (uint unknown in new uint[] { 3, 9, uint.MaxValue })
        { Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.SelectFault(site, unknown)); }
        if (!site.Signed) { Assert.ThrowsExactly<WarpVerificationException>(() => input.Plan.SelectFault(site, 2)); }
        Assert.AreEqual(1u, WarpLogicalMachineLayout.StepLimitFault);
        Assert.AreEqual(2u, WarpLogicalMachineLayout.CallDepthFault);
        Assert.AreEqual(0u, input.Plan.SelectFault(site, 1)!.FaultDescriptor);
    }

    [TestMethod]
    [DataRow("Carry32")]
    [DataRow("Carry64")]
    public void GenuineReferenceRootPrefixSurvivesArithmeticGuardAndResultWordStores(string name)
    {
        Inputs input = Capture(typeof(WarpPortableImplicitIntegerRootPrefixSourceKernels).GetMethod(name)!);
        WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        Assert.AreEqual(3, site.Instruction.EntryStack.Length);
        Assert.AreEqual(WarpPortableStackCategory.Reference, site.Instruction.EntryStack[0].Category);
        Assert.AreEqual(3, site.Instruction.EntryStack[0].WordCount);
        Assert.AreEqual(site.Instruction.EntryStack[0], site.Instruction.ExitStack[0]);
        var context = new RecordingContext(input, site);
        var guard = (WarpConditionalBranchTerminator)WarpPortableImplicitIntegerArithmeticEmitter.Emit(input.Plan, site, context, new UnimplementedRootContinuation());
        Assert.AreEqual(0, context.PrivateStores.Count);
        context.EmitDeferred(guard.WhenNonZero.Block);
        CollectionAssert.AreEqual(Enumerable.Range(3, site.ResultWords).ToArray(), context.PrivateStores.Select(store => store.Offset).ToArray());
        Assert.IsTrue(context.PrivateStores.All(store => store.CallsBeforeStore == 1 + site.ResultWords));
        Assert.IsFalse(context.ExecutableOrCompilerSealed);
    }

    [TestMethod]
    [DataRow("WarpCLR.Tests.TestKernels", "Divide")]
    [DataRow("WarpCLR.Tests.Production.CurrentCoverage.WarpCurrentNumericSourceCases", "SignedDivide32")]
    [DataRow("WarpCLR.Tests.Production.CurrentCoverage.WarpCurrentNumericSourceCases", "SignedDivide64")]
    public void TheSameOriginalDivisionsStayDeniedByOrdinaryLowering(string type, string name)
    {
        MethodInfo method = typeof(TestKernels).Assembly.GetType(type, throwOnError: true)!.GetMethod(name)!;
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(method);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpVerificationException failure = Assert.ThrowsExactly<WarpVerificationException>(() => WarpPortableWordLowerer.Lower(graph, typed));
        Assert.AreEqual("WRPCLR2300", failure.Code, StringComparer.Ordinal);
        StringAssert.Contains(failure.Message, "generated fault/EH continuation", StringComparison.Ordinal);
    }

    private sealed record Inputs(WarpPortableMethodGraph Graph, WarpPortableTypedProgram Typed,
        WarpPortableSourceHeapSchema Schema, WarpPortableSourceFaultFactoryContract Factory,
        WarpPortableImplicitIntegerArithmeticPlan Plan);

    private static Inputs Capture(string name)
        => Capture(typeof(WarpPortableCilIntegerDivisionSourceKernels).GetMethod(name)!);

    private static Inputs Capture(MethodInfo method)
    {
        WarpPortableMethodGraph graph = WarpPortableMethodGraph.Discover(method);
        WarpPortableTypedProgram typed = WarpPortableTypedProgram.Verify(graph);
        WarpPortableSourceHeapSchema schema = WarpPortableSourceHeapSchema.Create(graph, typed);
        WarpPortableSourceFaultFactoryContract factory = WarpPortableSourceFaultFactoryContract.CaptureFinite(graph, typed, schema);
        return new(graph, typed, schema, factory, WarpPortableImplicitIntegerArithmeticPlan.Capture(graph, typed, schema, factory));
    }
}
