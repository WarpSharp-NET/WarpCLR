using System.Runtime.CompilerServices;

namespace WarpCLR.Tests.Production;

// Genuine captured CIL: the object is already on the evaluation stack when
// division consumes its two original integer operands. Never replace it with
// a word-helper wrapper or a fabricated reference/root in a runtime proof.
internal static class WarpPortableImplicitIntegerRootPrefixSourceKernels
{
    [MethodImpl(MethodImplOptions.NoInlining)]
    public static (object, int) Carry32(object owner, int left, int right) => (owner, unchecked(left / right));

    [MethodImpl(MethodImplOptions.NoInlining)]
    public static (object, long) Carry64(object owner, long left, long right) => (owner, unchecked(left / right));
}
