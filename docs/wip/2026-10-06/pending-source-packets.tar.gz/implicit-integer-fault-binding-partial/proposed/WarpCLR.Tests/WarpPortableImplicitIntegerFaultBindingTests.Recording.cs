using System.Collections.Immutable;
using System.Reflection;
using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableImplicitIntegerFaultBindingTests
{
    // Structural recording only. It is never a real lowerer context, executable
    // source kernel, compiler seal, guest word bank or Root runtime capability.
    // Fault closures remain deferred and throw if anybody attempts to emit them.
    private sealed class RecordingContext : WarpPortableWordInstructionContext
    {
        private readonly Inputs input;
        private readonly WarpPortableImplicitIntegerArithmeticSite site;
        private readonly WarpPortableGeneratedServiceImporter importer;
        private readonly Dictionary<int, List<WarpIrInstruction>> instructions = [];
        private WarpPortableTypedInstruction typed;
        private int value;
        private int nextFunction;
        private int nextBlock = 100;
        private int block = 1;
        private bool privateProfile = true;

        internal RecordingContext(Inputs input, WarpPortableImplicitIntegerArithmeticSite site)
        {
            this.input = input; this.site = site; typed = site.Instruction;
            importer = new(input.Schema.SchemaHash, _ => { Mutations++; return nextFunction++; },
                (function, metadata) => { Mutations++; StoredFunctions.Add(new(function, metadata)); });
        }

        internal int Mutations { get; private set; }
        internal bool ExecutableOrCompilerSealed { get; }
        internal List<int> RecordedCalls { get; } = [];
        internal List<PrivateStore> PrivateStores { get; } = [];
        internal List<StoredFunction> StoredFunctions { get; } = [];
        internal Dictionary<int, Deferred> Generated { get; } = [];
        internal Import[] Imports => importer.Imports.Select(imported => new Import(imported.Function,
            site.ArithmeticServices.Prepend(site.SelectorService).Single(method => Signature(method) == imported.Signature).Name)).ToArray();

        internal override WarpPortableMethodGraph Graph => input.Graph;
        internal override WarpPortableTypedProgram Program => input.Typed;
        internal override WarpPortableMethodGraphMethod SourceMethod => site.SourceMethod;
        internal override WarpPortableMethodGraphInstruction SourceInstruction => site.SourceInstruction;
        internal override WarpPortableTypedInstruction Instruction => typed;
        internal override WarpPortableWordBody Body => throw new NotSupportedException("Structural fragments have no final compiler source-body map.");
        internal override bool PrivateHelperBoundaries => privateProfile;
        internal override WarpPortableGeneratedServiceImporter Services => importer;
        internal override int Block => block;
        internal override int SourceBlock(int sourceOffset) => input.Typed.Methods.Single(method => method.Identity == site.MethodIdentity)
            .Instructions.Where(instruction => instruction.Reachable).Select((instruction, index) => (instruction.Offset, Block: index + 1)).Single(item => item.Offset == sourceOffset).Block;
        internal override int SourceFunction(string methodIdentity) => throw new NotSupportedException("No final physical function map is fabricated.");
        internal override int Constant(uint word) => Emit(WarpIrOpCode.Constant, immediate: word);
        internal override int Emit(WarpIrOpCode operation, int left = -1, int right = -1, uint immediate = 0, int third = -1)
        {
            Mutations++; int result = value++;
            if (!instructions.TryGetValue(block, out List<WarpIrInstruction>? list)) { list = []; instructions.Add(block, list); }
            list.Add(new(result, operation, left, right, immediate, third)); return result;
        }
        internal override int LoadPrivateWord(int offset) => Emit(WarpManagedFrameOpCode.LoadPrivateWord, immediate: checked((uint)offset));
        internal override void StorePrivateWord(int offset, int result)
        {
            Mutations++; PrivateStores.Add(new(offset, result, RecordedCalls.Count));
        }
        internal override ImmutableArray<int> LoadStackValue(int slot) =>
            Enumerable.Range(StackWordOffset(slot), typed.EntryStack[slot].WordCount).Select(LoadPrivateWord).ToImmutableArray();
        internal override int StackWordOffset(int slot) => typed.EntryStack.Take(slot).Sum(word => word.WordCount);
        internal override ImmutableArray<int> Call(int function, IEnumerable<int> arguments, int resultWords = 1)
        {
            Mutations++; RecordedCalls.Add(function); int result = value; value = checked(value + resultWords);
            if (!instructions.TryGetValue(block, out List<WarpIrInstruction>? list)) { list = []; instructions.Add(block, list); }
            list.Add(new(resultWords == 0 ? -1 : result, function, arguments, resultWords));
            return Enumerable.Range(result, resultWords).ToImmutableArray();
        }
        internal override int ReserveGeneratedBlock() { Mutations++; return nextBlock++; }
        internal override void EmitGeneratedBlock(int generated, Func<WarpPortableWordInstructionContext, WarpBlockTerminator> emitter)
        { Mutations++; Generated.Add(generated, new(0, emitter)); }
        internal override void RecordReturnedRoots(int resultWord, string typeIdentity) => throw new NotSupportedException("No fake reference roots are published.");
        internal override void RequireService(string identity) { ArgumentException.ThrowIfNullOrEmpty(identity); Mutations++; }

        internal void EmitDeferred(int selected)
        {
            int previous = block; block = selected;
            try { Generated[selected].Emitter(this); }
            finally { block = previous; }
        }

        internal void Alter(string alteration)
        {
            typed = alteration switch
            {
                "opcode" => typed with { OpCode = 0 },
                "offset" => typed with { Offset = typed.Offset + 1 },
                "width" => typed with { EntryStack = typed.EntryStack.SetItem(0, typed.EntryStack[0] with { WordCount = 3 }) },
                "category" => typed with { EntryStack = typed.EntryStack.SetItem(0, typed.EntryStack[0] with { Category = WarpPortableStackCategory.Binary32 }) },
                "effect" => typed with { Effects = [] },
                "private-profile" => typed,
                _ => throw new ArgumentOutOfRangeException(nameof(alteration)),
            };
            if (alteration == "private-profile") { privateProfile = false; }
        }

        private static string Signature(MethodInfo method) => WarpPortableSnapshotIdentity.Hash(new
        { WarpPortableGeneratedServiceImporter.Semantics, Method = WarpPortableMethodGraphIdentity.Method(method), BankKind = (int)WarpPortableGeneratedServiceKind.Words });
    }

    private sealed record Import(int Function, string Method);
    private sealed record PrivateStore(int Offset, int Result, int CallsBeforeStore);
    private sealed record StoredFunction(WarpControlFlowFunction Function, WarpLogicalBodyMetadata Metadata);
    private sealed record Deferred(int SourceCharge, Func<WarpPortableWordInstructionContext, WarpBlockTerminator> Emitter);
}
