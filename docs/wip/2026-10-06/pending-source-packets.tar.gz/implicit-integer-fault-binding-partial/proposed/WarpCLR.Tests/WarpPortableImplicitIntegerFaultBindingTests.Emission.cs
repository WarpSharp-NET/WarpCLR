using WarpCLR.Compiler;
using WarpCLR.IR;
using WarpCLR.Verifier;

namespace WarpCLR.Tests.Production;

internal sealed partial class WarpPortableImplicitIntegerFaultBindingTests
{
    [TestMethod]
    [DataRow("Int32Divide")]
    [DataRow("Int64Remainder")]
    public void UnavailableRootContinuationRejectsBeforeAnyCompilerOrBankMutation(string name)
    {
        Inputs input = Capture(name); var context = new RecordingContext(input, input.Plan.Sites.Single());
        Assert.ThrowsExactly<WarpVerificationException>(() => WarpPortableImplicitIntegerArithmeticEmitter.Emit(input.Plan, input.Plan.Sites.Single(), context, null));
        Assert.AreEqual(0, context.Mutations); Assert.AreEqual(0, context.Imports.Length);
        Assert.AreEqual(0, context.PrivateStores.Count); Assert.AreEqual(0, context.Generated.Count);
    }

    [TestMethod]
    [DataRow("Int32Remainder")]
    [DataRow("UInt64Divide")]
    public void SupplyingAnUnpreparedCallbackStillRejectsBeforeEmission(string name)
    {
        Inputs input = Capture(name); WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        var context = new RecordingContext(input, site);
        Assert.ThrowsExactly<WarpVerificationException>(() => WarpPortableImplicitIntegerArithmeticEmitter.Emit(input.Plan, site, context, new UnimplementedRootContinuation(recipePrepared: false)));
        Assert.AreEqual(0, context.Mutations); Assert.AreEqual(0, context.Imports.Length);
        Assert.AreEqual(0, context.PrivateStores.Count); Assert.AreEqual(0, context.Generated.Count);
    }

    [TestMethod]
    [DataRow("Int32Divide", "opcode")]
    [DataRow("Int64Remainder", "offset")]
    [DataRow("Int32Remainder", "width")]
    [DataRow("UInt64Divide", "category")]
    [DataRow("Int64Divide", "effect")]
    [DataRow("UInt32Remainder", "private-profile")]
    public void AlteredOriginalInstructionOrMissingPrivateProfileRejectsBeforeEmission(string name, string alteration)
    {
        Inputs input = Capture(name); WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        var context = new RecordingContext(input, site);
        context.Alter(alteration);
        Assert.ThrowsExactly<WarpVerificationException>(() => WarpPortableImplicitIntegerArithmeticEmitter.Emit(input.Plan, site, context, new UnimplementedRootContinuation()));
        Assert.AreEqual(0, context.Mutations); Assert.AreEqual(0, context.Imports.Length);
        Assert.AreEqual(0, context.PrivateStores.Count);
    }

    [TestMethod]
    [DataRow("Int32Divide")]
    [DataRow("Int32Remainder")]
    [DataRow("UInt32Divide")]
    [DataRow("UInt32Remainder")]
    [DataRow("Int64Divide")]
    [DataRow("Int64Remainder")]
    [DataRow("UInt64Divide")]
    [DataRow("UInt64Remainder")]
    public void DeferredCompilerFragmentGuardsAndFinishesWholeTupleBeforeStores(string name)
    {
        Inputs input = Capture(name); WarpPortableImplicitIntegerArithmeticSite site = input.Plan.Sites.Single();
        var context = new RecordingContext(input, site);
        var guard = (WarpConditionalBranchTerminator)WarpPortableImplicitIntegerArithmeticEmitter.Emit(input.Plan, site, context, new UnimplementedRootContinuation());
        Assert.AreEqual(0, context.PrivateStores.Count);
        Assert.AreEqual(1, context.RecordedCalls.Count);
        Assert.AreEqual(site.SelectorService.Name, context.Imports.Single(service => service.Function == context.RecordedCalls[0]).Method);
        context.EmitDeferred(guard.WhenNonZero.Block);
        Assert.AreEqual(1 + site.ResultWords, context.RecordedCalls.Count);
        Assert.AreEqual(site.ResultWords, context.PrivateStores.Count);
        Assert.IsTrue(context.PrivateStores.All(store => store.CallsBeforeStore == 1 + site.ResultWords));
        CollectionAssert.AreEqual(Enumerable.Range(0, site.ResultWords).ToArray(), context.PrivateStores.Select(store => store.Offset).ToArray());
        Assert.IsTrue(context.StoredFunctions.All(function => function.Metadata.RuntimeHelper && !function.Metadata.CountsSourceDepth && function.Metadata.SourceBlockCosts.All(cost => cost == 0)));
        Assert.IsTrue(context.Generated.Values.All(fragment => fragment.SourceCharge == 0));
        // Never compile or run this incomplete recording as a source program.
        // Every Root fault callback throws, so no synthetic fault success exists.
        Assert.IsFalse(context.ExecutableOrCompilerSealed);
    }

    private sealed class UnimplementedRootContinuation(bool recipePrepared = true) : WarpPortableImplicitIntegerFaultContinuation
    {
        internal override void RequireEmissionPrepared(WarpPortableImplicitIntegerArithmeticPlan plan, WarpPortableImplicitIntegerArithmeticSite site)
        {
            plan.RequireOwnedSite(site);
            if (!recipePrepared) { throw new WarpVerificationException("WRPCLR2300", "Test-only compiler recipe is deliberately unavailable; no runtime permission is involved.", site.SourceOffset); }
        }
        internal override WarpBlockTerminator EmitPreparedFault(WarpPortableWordInstructionContext context, WarpPortableImplicitIntegerArithmeticPlan plan,
            WarpPortableImplicitIntegerArithmeticSite site, WarpPortableSourceFaultFactoryRow exactRow) =>
            throw new NotSupportedException("Test records a compiler fragment only; actual Root fault/private invocation route is unavailable.");
        internal override WarpBlockTerminator EmitRejectedSelector(WarpPortableWordInstructionContext context, WarpPortableImplicitIntegerArithmeticPlan plan,
            WarpPortableImplicitIntegerArithmeticSite site) => throw new NotSupportedException("No synthetic source consistency failure or controller cleanup is emitted.");
    }
}
