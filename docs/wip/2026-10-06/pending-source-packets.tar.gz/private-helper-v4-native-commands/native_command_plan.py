"""Source-only additive device-image plan and receipt audit; never launches tools."""
import argparse
import hashlib
import json
import pathlib
import re
import struct

HERE = pathlib.Path(__file__).resolve().parent
VERSION = "warp.proof.v4/exact-source-serial-native-command-plan/0.1"
CPU_PACKET_SHA = "a5749924f5a90c09e4a15df97fac8796aa815d89108a3d06cbe09dba9e2ad75b"
PROGRAMS = {
    "CapturedUInt32Echo_Service1": (1, 1, False, "022A"),
    "CapturedUInt64Echo_Service2": (2, 2, False, "022A"),
    "CapturedVoidEmpty_Service0": (0, 0, False, "2A"),
    "CapturedUInt32Echo_NestedService4": (1, 4, True, "022A"),
}
TARGETS = {
    "NVPTX": ("nvptx64-nvidia-cuda", "sm_80", ".ptx", "ptx_kernel"),
    "AMDGPU": ("amdgcn-amd-amdhsa", "gfx942", ".hsaco", "amdgpu_kernel"),
    "SPIRV": ("spir64-unknown-unknown", "opencl2.2-spirv1.2", ".spv", "spir_kernel"),
}
ASSEMBLIES = {"WarpCLR.Core", "WarpCLR.IR", "WarpCLR.Compiler", "WarpCLR.Verifier", "WarpCLR.Backend.CoreCLR"}
TOOL_NAMES = {"llvmAs", "llc", "lld", "llvmSpirv", "spirvVal"}
METADATA = "warp.logical-source-frames/private-controller-helper-return-scoped-publication-fence/0.10"


def sha(path):
    with pathlib.Path(path).open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def absolute(path):
    result = pathlib.Path(path)
    require(result.is_absolute(), "Absolute path required: " + str(path))
    return result


def reference(row):
    path = absolute(row["path"])
    require(re.fullmatch("[0-9a-fA-F]{64}", row["sha256"]) is not None, "Real SHA256 required: " + str(path))
    require(sha(path) == row["sha256"].lower(), "Exact input bytes differ: " + str(path))
    return path


def read(path):
    return json.loads(pathlib.Path(path).read_text())


def write_new(path, value):
    path = absolute(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as output:
        output.write(json.dumps(value, indent=2) + "\n")


def source_requirements(source, dialect):
    text = source.read_text()
    triple, _, _, convention = TARGETS[dialect]
    require(text.splitlines().count('target triple = "' + triple + '"') == 1, "Exact device triple required; no retarget")
    require("define " + convention + " void @warp_resume(" in text, "Original kernel convention/entry required")
    require("ptr addrspace(1)" in text and re.search(r"\bi32\b", text) and re.search(r"\bi64\b", text),
            "Original global pointer space and full UInt32/64 physical widths required")
    spaces = sorted({int(value) for value in re.findall(r"addrspace\((\d+)\)", text)})
    require(set(spaces) <= ({1, 5} if dialect == "AMDGPU" else {1}), "Unknown finite-fixture physical address space")
    require(not re.search(r"\b(float|double|half|atomicrmw|cmpxchg)\b|asm sideeffect|\basm\s*\(", text),
            "These four sealed integer-word fixtures contain no floating, vendor assembly or atomic operations")
    return {"triple": triple, "addressSpaces": spaces, "integerWidthsRetained": [32, 64],
            "requiresInt64": True, "requiresInt64Atomics": False, "sourceRewrites": 0}


def tools_checked(config):
    require(config["format"] == "warp.proof.v4/root-native-tools/0.1", "Exact native tool schema required")
    require(set(config["tools"]) == TOOL_NAMES, "All five tool identities required")
    receipt = read(reference(config["prerequisiteReceipt"]))
    require(receipt["format"] == "warp.proof.v4/root-native-prerequisite-receipt/0.1", "Root prerequisite receipt required")
    require(receipt["llvmMajor"] == 19 and {"nvptx64", "amdgcn"} <= set(receipt["registeredTargets"]),
            "LLVM19 native targets required; missing/incompatible tools are blockers")
    require(receipt["translatorMaxSpirVVersion"] == "1.2" and receipt["validatorEnvironment"] == "opencl2.2",
            "Actual translator/validator prerequisites required; no universal fallback")
    binaries = {}
    for name, row in config["tools"].items():
        binaries[name] = str(reference(row))
        identity = receipt["tools"][name]
        require(identity["path"] == binaries[name] and identity["sha256"].lower() == row["sha256"].lower(),
                "Actual prerequisite tool bytes must join the explicit configuration")
        require(identity["reportedVersion"].strip(), "Actual retained version text required")
        reference(identity["versionStdout"])
        reference(identity["versionStderr"])
    require(config["libraries"], "Explicit shared-library byte inventory required")
    for row in config["libraries"]:
        reference(row)
    directories = [str(absolute(path)) for path in config["libraryDirectories"]]
    require(directories and all(pathlib.Path(path).is_dir() for path in directories), "Actual library directories required")
    return binaries, {"LD_LIBRARY_PATH": ":".join(directories)}


def prepare(args):
    root_path, emissions_path, tools_path = map(absolute, (args.root_inputs, args.emissions, args.tools))
    root, emissions, tool_config = map(read, (root_path, emissions_path, tools_path))
    cpu_manifest = reference(read(HERE / "provenance.json")["cpuPacket"])
    require(sha(cpu_manifest) == CPU_PACKET_SHA, "Sealed CPU packet pin differs")
    require(root["format"] == "warp.proof.v4/root-production-inputs/0.1" and root["productionGateLabel"].strip(),
            "Fresh actual Root production identity is mandatory")
    require(set(root["assemblies"]) == ASSEMBLIES, "Exact actual five-assembly production inventory required")
    for row in [root["productionSourceReceipt"], root["productionArtifactReceipt"], *root["assemblies"].values()]:
        reference(row)
    require(emissions["format"] == "warp.proof.v4/root-native-emission-inventory/0.1", "Emission inventory schema differs")
    require(emissions["cpuPacketManifestSha256"] == CPU_PACKET_SHA, "Exact originating source packet required")
    require(emissions["rootInputsSha256"].lower() == sha(root_path), "Emissions must bind actual Root production inputs")
    input_identity = read(reference(emissions["coreInputIdentity"]))
    require(input_identity["inputsSha256"].lower() == sha(root_path) and input_identity["inputs"] == root,
            "Actual Core preparation inputs differ from Root production bytes")
    core = read(reference(emissions["coreResult"]))
    require(core["status"] == "CORE_PREPARATION_COMPLETE_CPU_COMPARISONS_PENDING" and len(core["programs"]) == 4,
            "All four actual captured-CIL preparations must complete; no partial substitution")
    require({row["name"] for row in core["programs"]} == set(PROGRAMS), "Core prepared method inventory differs")
    require(set(emissions["programs"]) == set(PROGRAMS), "Exactly four original source plans required")
    binaries, environment = tools_checked(tool_config)
    output = absolute(args.output_root)
    require(not output.exists(), "Fresh retained native output root required; never overwrite failed boundaries")
    commands, images = [], []

    def add(image, role, argv, inputs, outputs):
        ordinal = len(commands)
        stem = output / "logs" / (str(ordinal).zfill(2) + "-" + image["name"] + "-" + role)
        commands.append({"ordinal": ordinal, "name": image["name"] + "-" + role, "image": image["name"], "role": role,
                         "argv": argv, "cwd": str(output), "environment": environment, "inputs": inputs, "outputs": outputs,
                         "stdoutPath": str(stem) + ".stdout.log", "stderrPath": str(stem) + ".stderr.log",
                         "receiptPath": str(stem) + ".receipt.json", "imageDeadlineSeconds": 120,
                         "usesRemainingImageDeadline": True, "retries": 0, "execute": False})

    for name, (payload, words, nested, cil) in PROGRAMS.items():
        row = emissions["programs"][name]
        identity_path, emitted_path, plan_path = map(reference, (row["programIdentity"], row["emittedIdentity"], row["wordPlan"]))
        identity, emitted = read(identity_path), read(emitted_path)
        require((identity["name"], identity["payloadWords"], identity["serviceWords"], identity["nested"], identity["source"]["cil"])
                == (name, payload, words, nested, cil), "Genuine captured source/UInt64/void/tuple identity differs")
        require(identity["metadataVersion"] == METADATA and identity["scalarCount"] == 1, "Exact opt-in v4 profile required")
        require(len(identity["privateHelperReturnSites"]) == 1 and identity["resultWordCount"] == payload,
                "Complete result tuple contract differs")
        require(identity["privateHelperReturnSites"][0]["resultWordCount"] == words,
                "Exact zero/one/two/four-word helper result tuple required")
        require(identity["source"]["cilSha256"].lower() == hashlib.sha256(bytes.fromhex(cil)).hexdigest(),
                "Actual original CIL descriptor hash differs")
        reference({"path": identity["source"]["modulePath"], "sha256": identity["source"]["moduleSha256"]})
        require(plan_path.read_bytes()[:4] == struct.pack("<I", 0x57425038), "Explicit WBP8 required; no legacy fallback")
        require(emitted["planSha256"].lower() == sha(plan_path) and emitted["irHash"] == identity["irHash"], "Plan/IR join differs")
        require(len(emitted["dialects"]) == 3 and {r["dialect"] for r in emitted["dialects"]} == set(TARGETS), "All native dialects required")
        for dialect in TARGETS:
            source_row = next(r for r in emitted["dialects"] if r["dialect"] == dialect)
            source = reference(source_row)
            require((source_row["irHash"], source_row["graphHash"], source_row["typedHash"], source_row["entryPoint"])
                    == (identity["irHash"], identity["graphHash"], identity["typedHash"], "warp_resume"), "Same source/IR/type/hash join required")
            requirements = source_requirements(source, dialect)
            stem = output / name / dialect
            bitcode, object_file, image_path = str(stem) + ".bc", str(stem) + ".o", str(stem) + TARGETS[dialect][2]
            image = {"name": name + "-" + dialect, "program": name, "dialect": dialect, "path": image_path,
                     "source": source_row, "programIdentity": row["programIdentity"], "emittedIdentity": row["emittedIdentity"],
                     "wordPlan": row["wordPlan"], "irHash": identity["irHash"], "graphHash": identity["graphHash"],
                     "typedHash": identity["typedHash"], "payloadWords": payload, "serviceWords": words,
                     "requirements": requirements, "target": TARGETS[dialect][1], "deadlineSeconds": 120,
                     "gpuExecution": False, "retargetedToCpu": False, "sourceChanges": 0}
            images.append(image)
            add(image, "assemble", [binaries["llvmAs"], str(source), "-o", bitcode], [str(source)], [bitcode])
            if dialect == "NVPTX":
                add(image, "codegen", [binaries["llc"], "-mtriple=nvptx64-nvidia-cuda", "-mcpu=sm_80", "-mattr=+ptx80",
                                       "-filetype=asm", "-O=2", bitcode, "-o", image_path], [bitcode], [image_path])
            elif dialect == "AMDGPU":
                add(image, "codegen", [binaries["llc"], "-mtriple=amdgcn-amd-amdhsa", "-mcpu=gfx942", "-filetype=obj",
                                       "-O=2", bitcode, "-o", object_file], [bitcode], [object_file])
                add(image, "link", [binaries["lld"], "-shared", "--no-undefined", object_file, "-o", image_path], [object_file], [image_path])
            else:
                add(image, "translate", [binaries["llvmSpirv"], "--spirv-max-version=1.2", bitcode, "-o", image_path], [bitcode], [image_path])
                add(image, "validate", [binaries["spirvVal"], "--target-env", "opencl2.2", image_path], [image_path], [])
    require(len(images) == 12 and len(commands) == 32, "Finite four-by-three native matrix differs")
    return {"format": VERSION, "status": "FUTURE_SERIAL_COMMANDS_NOT_EXECUTED", "cpuPacketManifestSha256": CPU_PACKET_SHA,
            "rootInputs": {"path": str(root_path), "sha256": sha(root_path)}, "emissions": {"path": str(emissions_path), "sha256": sha(emissions_path)},
            "tools": {"path": str(tools_path), "sha256": sha(tools_path)}, "plannerSourceSha256": sha(__file__),
            "productionGateLabel": root["productionGateLabel"], "outputRoot": str(output), "images": images, "commands": commands,
            "serial": True, "startImageDeadlineBeforeFirstCommand": True, "nativeImagesPlanned": 12, "cpuImagesPlanned": 0,
            "gpuExecution": False, "privateRpc": False, "sourceAuthority": False, "sourceCopies": 0,
            "productionQuotasUnchanged": {"jit": 120, "quantum": 30, "cleanup": 2},
            "executor": "Root's independently authenticated bounded serial executor; retain actual argv/env/PID/PGID/start identity, logs, all outputs, failure and stop receipts. This source never starts a process."}


def inspect_image(image):
    path = pathlib.Path(image["path"])
    data = path.read_bytes()
    require(data, "Empty native image")
    if image["dialect"] == "NVPTX":
        text = data.decode()
        require(re.search(r"(?m)^\s*\.version\s+8\.0\s*$", text) and re.search(r"(?m)^\s*\.target\s+sm_80(?:\s*,.*)?$", text),
                "Exact PTX8.0/sm_80 required")
        require(re.search(r"(?m)^\s*\.address_size\s+64\s*$", text) and re.search(r"\.entry\s+warp_resume\s*\(", text),
                "Full 64-bit PTX address ABI/kernel entry required")
        return {"format": "PTX", "version": "8.0", "target": "sm_80", "addressBits": 64,
                "validation": "LLVM code generation + narrow text checks; no CUDA driver JIT, ptxas or CUBIN claim"}
    if image["dialect"] == "AMDGPU":
        require(len(data) >= 64 and data[:6] == b"\x7fELF\x02\x01", "ELF64 little-endian HSACO required")
        kind, machine = struct.unpack_from("<HH", data, 16)
        require(kind == 3 and machine == 224, "Linked AMDGPU ET_DYN image required")
        require(b"warp_resume\0" in data, "Actual AMDGPU kernel symbol required")
        return {"format": "HSACO", "elfClass": 64, "elfMachine": machine, "osAbi": data[7], "abiVersion": data[8],
                "validation": "Actual LLVM19 object + no-undefined LLD link + narrow ELF checks; no HSA loader/device execution"}
    require(len(data) >= 20 and len(data) % 4 == 0, "Complete SPIR-V word image required")
    words = struct.unpack("<" + str(len(data) // 4) + "I", data)
    require(words[0] == 0x07230203 and 0x00010000 <= words[1] <= 0x00010200 and words[4] == 0, "SPIR-V1.0..1.2 header required")
    capabilities, integers, models, entries = [], [], [], []
    offset = 5
    while offset < len(words):
        count, opcode = words[offset] >> 16, words[offset] & 65535
        require(count > 0 and offset + count <= len(words), "Malformed SPIR-V instruction length")
        operands = words[offset + 1:offset + count]
        if opcode == 17:
            require(count == 2, "Malformed OpCapability")
            capabilities.append(operands[0])
        elif opcode == 21:
            require(count == 4, "Malformed integer type")
            integers.append(operands[1])
        elif opcode == 14:
            models.append(list(operands))
        elif opcode == 15:
            require(count >= 4, "Malformed entry point")
            name = struct.pack("<" + str(len(operands) - 2) + "I", *operands[2:]).split(b"\0", 1)[0].decode()
            entries.append((operands[0], name))
        offset += count
    require({4, 6, 11} <= set(capabilities) and 1 not in capabilities and 12 not in capabilities,
            "Addresses/Kernel/Int64 required; no Shader or unrequested Int64Atomics substitution")
    require({32, 64} <= set(integers) and models == [[2, 2]] and entries == [(6, "warp_resume")],
            "Full integer widths, Physical64/OpenCL memory model and exact kernel entry required")
    return {"format": "SPIR-V", "versionWord": words[1], "capabilities": capabilities, "integerWidths": sorted(set(integers)),
            "addressingModel": "Physical64", "memoryModel": "OpenCL", "validation": "Actual spirv-val --target-env opencl2.2 receipt required"}


def audit(args):
    plan_path = absolute(args.plan)
    plan = read(plan_path)
    require(plan["format"] == VERSION and len(plan["images"]) == 12 and len(plan["commands"]) == 32, "Exact finite plan required")
    for key in ("rootInputs", "emissions", "tools"):
        reference(plan[key])
    root = read(plan["rootInputs"]["path"])
    for row in [root["productionSourceReceipt"], root["productionArtifactReceipt"], *root["assemblies"].values()]:
        reference(row)
    tools_checked(read(plan["tools"]["path"]))
    result = {"format": "warp.proof.v4/native-receipt-consistency-audit/0.1", "planSha256": sha(plan_path),
              "status": "INCOMPLETE", "commands": [], "images": [], "gpuExecution": False, "authority": False,
              "limit": "Receipt consistency only; Root independently authenticates execution and complete containment. No device feature/runtime support proof."}
    try:
        for command in plan["commands"]:
            receipt_path = pathlib.Path(command["receiptPath"])
            receipt = read(receipt_path)
            require(receipt["format"] == "warp.proof.v4/serial-native-command-receipt/0.1" and receipt["planSha256"] == sha(plan_path), "Actual command receipt binding differs")
            for key in ("ordinal", "name", "argv", "cwd", "environment"):
                require(receipt[key] == command[key], "Actual command differs: " + key)
            require(receipt["exitCode"] == 0 and not receipt["timedOut"] and receipt["remainingImageDeadlineSeconds"] > 0,
                    "Failed or expired command retained; no partial PASS")
            require(0 <= receipt["imageElapsedSeconds"] < 120, "Shared 120s image pipeline deadline required")
            require(receipt["pid"] > 0 and receipt["privatePgid"] == receipt["pid"] and receipt["privatePgid"] != receipt["parentPgid"],
                    "Exact privately owned child process identity required")
            reference(receipt["stopReceipt"])
            require(receipt["observedOwnedProcessesAfterStop"] == [], "Owned descendants must be positively stopped by Root's executor")
            for key, log_path in (("stdout", command["stdoutPath"]), ("stderr", command["stderrPath"])):
                require(str(reference(receipt[key])) == log_path, "Complete stdout/stderr receipt differs")
            for key in ("inputs", "outputs"):
                require([str(reference(row)) for row in receipt[key]] == command[key], "Exact command file inventory differs")
            result["commands"].append({"ordinal": command["ordinal"], "receiptPath": str(receipt_path), "receiptSha256": sha(receipt_path)})
        for image in plan["images"]:
            reference(image["source"])
            for key in ("programIdentity", "emittedIdentity", "wordPlan"):
                reference(image[key])
            description = inspect_image(image)
            result["images"].append({"name": image["name"], "path": image["path"], "sha256": sha(image["path"]),
                                     "sourceSha256": image["source"]["sha256"], "irHash": image["irHash"],
                                     "graphHash": image["graphHash"], "typedHash": image["typedHash"], "inspection": description})
        result["status"] = "TWELVE_LOCAL_OFFLINE_NATIVE_IMAGES_RECEIPTS_CONSISTENT_NO_GPU_EXECUTION"
    except Exception as error:
        result["status"] = "FAILED_RETAIN_COMPLETE_BOUNDARY"
        result["error"] = repr(error)
        write_new(args.result, result)
        raise
    write_new(args.result, result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="action", required=True)
    plan = commands.add_parser("plan")
    for name in ("root-inputs", "emissions", "tools", "output-root", "plan"):
        plan.add_argument("--" + name, required=True)
    check = commands.add_parser("audit")
    check.add_argument("--plan", required=True)
    check.add_argument("--result", required=True)
    args = parser.parse_args()
    if args.action == "audit":
        audit(args)
        return
    try:
        result = prepare(args)
    except Exception as error:
        write_new(args.plan, {"format": VERSION, "status": "BLOCKED_NO_COMMANDS_EXECUTED", "error": repr(error),
                              "rootInputsPath": args.root_inputs, "emissionsPath": args.emissions, "toolsPath": args.tools,
                              "sourceChanges": 0, "gpuExecution": False, "authority": False})
        raise
    write_new(args.plan, result)


if __name__ == "__main__":
    main()
